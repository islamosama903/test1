'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Camera, Music2, PlayCircle, Video } from 'lucide-react';
import AudioPlayer from '@/components/AudioPlayer';
import { getSupportedAudioMimeType } from '@/lib/audio-utils';
import { getDefaultVisibleSections, getWeddingMedia, getVisibleSections, hasVisibleContent, weddingSectionConfig } from '@/lib/wedding-utils';
import { getThemePresetById, getThemePresetOptions } from '@/lib/wedding-theme';

export default function CoupleControlPage(){
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [slug, setSlug] = useState('');
  const [story, setStory] = useState('');
  const [guestMessage, setGuestMessage] = useState('');
  const [guestAudioPreview, setGuestAudioPreview] = useState<string | null>(null);
  const [allowGuestUploads, setAllowGuestUploads] = useState(true);
  const [rsvps, setRsvps] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingRsvps, setLoadingRsvps] = useState(false);
  const [sendingAudio, setSendingAudio] = useState(false);
  const [partnerRole, setPartnerRole] = useState<'groom' | 'bride' | 'couple'>('couple');
  const [groomName, setGroomName] = useState('');
  const [brideName, setBrideName] = useState('');
  const [venueName, setVenueName] = useState('');
  const [address, setAddress] = useState('');
  const [googleMapsUrl, setGoogleMapsUrl] = useState('');
  const [showMapHelp, setShowMapHelp] = useState(false);
  const [mapValidationError, setMapValidationError] = useState('');
  const [weddingDate, setWeddingDate] = useState('');
  const [weddingTime, setWeddingTime] = useState('');
  const [timelineItems, setTimelineItems] = useState<{ title: string; time: string; detail: string }[]>([
    { title: 'استقبال الضيوف', time: '٥:٣٠', detail: 'بداية الاحتفال مع نسماتٍ دافئة وموسيقى هادئة.' },
    { title: 'الخطوبة', time: '٦:٠٠', detail: 'لحظة مميزة تجمع بين العائلة والأحباء تحت أضواءٍ ساحرة.' },
    { title: 'العشاء والتجمع', time: '٧:٣٠', detail: 'أجواءٍ مليئة بالضحك، واللمسات الجميلة، والذكريات.' },
  ]);
  const [saveMessage, setSaveMessage] = useState('');
  const [galleryFiles, setGalleryFiles] = useState<File[]>([]);
  const [videoFiles, setVideoFiles] = useState<File[]>([]);
  const [musicFile, setMusicFile] = useState<File | null>(null);
  const [musicUploading, setMusicUploading] = useState(false);
  const [musicUploadProgress, setMusicUploadProgress] = useState(0);
  const [musicUploadMessage, setMusicUploadMessage] = useState('');
  const [musicFileError, setMusicFileError] = useState('');
  const [recording, setRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordedAudioBlob, setRecordedAudioBlob] = useState<Blob | null>(null);
  const [recordingError, setRecordingError] = useState('');
  const [visibleSections, setVisibleSections] = useState<Record<string, boolean>>(getDefaultVisibleSections());
  const [themeId, setThemeId] = useState('royal-emerald-garden');
  const [selectedPhotoUrls, setSelectedPhotoUrls] = useState<string[]>([]);
  const [selectedVideoUrls, setSelectedVideoUrls] = useState<string[]>([]);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [mediaMessage, setMediaMessage] = useState('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
    router.push('/login');
  };

  useEffect(()=>{
    const parts = window.location.pathname.split('/');
    const s = parts[2] ?? '';
    setSlug(s);
    // unified single interface (no separate groom/bride views)
    setPartnerRole('couple');
    fetch(`/api/weddings/${encodeURIComponent(s)}`, { credentials: 'same-origin' }).then(r=>r.json()).then(d=>{ if (!d?.error) {
        setData(d);
        setStory(d.story || '');
        setGuestMessage(d.guest_message || '');
        setGuestAudioPreview(d.guest_message_audio || null);
          setAllowGuestUploads(d.allow_guest_uploads ?? true);
        setGroomName(d.groom_name || '');
        setBrideName(d.bride_name || '');
        setVenueName(d.venue_name || '');
        setAddress(d.address || '');
        setGoogleMapsUrl(d.google_maps_url || '');
        setWeddingDate(d.wedding_date || '');
        setWeddingTime(d.wedding_time || '');
        setVisibleSections(getVisibleSections(d));
        setThemeId(d.theme || 'royal-emerald-garden');
        setTimelineItems(Array.isArray(d.timeline) && d.timeline.length > 0 ? d.timeline : [
          { title: 'استقبال الضيوف', time: '٥:٣٠', detail: 'بداية الاحتفال مع نسماتٍ دافئة وموسيقى هادئة.' },
          { title: 'الخطوبة', time: '٦:٠٠', detail: 'لحظة مميزة تجمع بين العائلة والأحباء تحت أضواءٍ ساحرة.' },
          { title: 'العشاء والتجمع', time: '٧:٣٠', detail: 'أجواءٍ مليئة بالضحك، واللمسات الجميلة، والذكريات.' },
        ]);
      } }).catch(()=>{});
    loadRsvps(s);
  },[]);

  const media = useMemo(() => getWeddingMedia(data), [data]);
  const availableThemes = useMemo(() => getThemePresetOptions(), []);
  const selectedTheme = useMemo(() => getThemePresetById(themeId), [themeId]);

  const loadRsvps = async (weddingSlug: string) => {
    setLoadingRsvps(true);
    try {
      const res = await fetch(`/api/rsvps?slug=${encodeURIComponent(weddingSlug)}`);
      const rows = await res.json();
      setRsvps(Array.isArray(rows) ? rows : []);
    } catch (e) {
      setRsvps([]);
    } finally {
      setLoadingRsvps(false);
    }
  };

  const handleSave = async () =>{
    setLoading(true);
    setSaveMessage('');
    try{
      setMapValidationError('');
      // validate Google Maps URL if provided
      let finalMaps = googleMapsUrl;
      if (googleMapsUrl && googleMapsUrl.trim()) {
        try {
          const vres = await fetch('/api/maps', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: googleMapsUrl.trim() }) });
          const vb = await vres.json().catch(() => null);
          if (!vb?.ok) {
            setMapValidationError(vb?.error || 'الرابط غير صالح. الرجاء لصق رابط المكان الكامل أو رابط التضمين.');
            setLoading(false);
            return;
          }
          // prefer embedUrl for stable embedding
          finalMaps = vb?.embedUrl || vb?.resolvedUrl || googleMapsUrl.trim();
          setGoogleMapsUrl(finalMaps);
        } catch (e) {
          setMapValidationError('تعذر التحقق من الرابط. حاول مرةً أخرى لاحقًا.');
          setLoading(false);
          return;
        }
      }

      const payload: any = {
        story,
        guest_message: guestMessage,
        guest_message_audio: guestAudioPreview,
        allow_guest_uploads: allowGuestUploads,
        groom_name: groomName,
        bride_name: brideName,
        venue_name: venueName,
        address,
        google_maps_url: finalMaps,
        wedding_date: weddingDate,
        wedding_time: weddingTime,
        timeline: timelineItems,
        visible_sections: visibleSections,
        theme: themeId,
      };
      const res = await fetch(`/api/weddings/${encodeURIComponent(slug)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(payload) });
      const body = await res.json();
      if (!res.ok) throw new Error(body?.error || 'Failed');
      setData(body);
      setSaveMessage('تم حفظ تفاصيل الدعوة بنجاح');
    }catch(err:any){
      setSaveMessage('حصل خطأ: ' + (err.message || String(err)));
    }finally{ setLoading(false); }
  };

  const handleAudioPick = async (file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setGuestAudioPreview(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleMusicPick = (file: File | null) => {
    if (!file) {
      setMusicFile(null);
      setMusicFileError('');
      setMusicUploadProgress(0);
      setMusicUploadMessage('');
      return;
    }

    const allowedTypes = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/x-m4a', 'audio/mp4', 'audio/webm'];
    const maxSize = 30 * 1024 * 1024; // 30MB

    if (!allowedTypes.includes(file.type)) {
      setMusicFile(null);
      setMusicFileError('نوع الملف غير مدعوم. استخدم MP3 أو WAV أو OGG.');
      return;
    }

    if (file.size > maxSize) {
      setMusicFile(null);
      setMusicFileError('حجم الملف كبير جدًا. الحد الأقصى المسموح هو 30 ميجا.');
      return;
    }

    setMusicFile(file);
    setMusicFileError('');
    setMusicUploadProgress(0);
    setMusicUploadMessage('');
  };

  const uploadMusicFile = async () => {
    if (!slug || !musicFile) return;
    if (musicFileError) {
      setMusicUploadMessage(musicFileError);
      return;
    }
    setMusicUploading(true);
    setMusicUploadMessage('');
    setMusicUploadProgress(0);

    try {
      const formData = new FormData();
      formData.append('slug', slug);
      formData.append('file', musicFile);
      const xhr = new XMLHttpRequest();
      const result = await new Promise<any>((resolve, reject) => {
        xhr.open('POST', '/api/uploads/music');
        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            setMusicUploadProgress(Math.round((event.loaded / event.total) * 100));
          }
        };
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              resolve(JSON.parse(xhr.responseText));
            } catch (error) {
              reject(new Error('فشل تحليل استجابة الخادم'));
            }
          } else {
            reject(new Error(xhr.responseText || 'فشل رفع الملف'));
          }
        };
        xhr.onerror = () => reject(new Error('فشل رفع الملف'));
        xhr.send(formData);
      });

      if (!result?.url) throw new Error(result?.error || 'فشل رفع الأغنية');

      const res = await fetch(`/api/weddings/${encodeURIComponent(slug)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ mp3_url: result.url }),
      });
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error(body?.error || 'فشل حفظ رابط الأغنية');

      setData(body);
      setMusicFile(null);
      setMusicUploadMessage('تم رفع الأغنية بنجاح');
    } catch (err: any) {
      setMusicUploadMessage(err?.message || 'تعذر رفع الأغنية');
    } finally {
      setMusicUploading(false);
      setMusicUploadProgress(0);
    }
  };
  

  const readBlobAsDataUrl = (blob: Blob) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('تعذر قراءة التسجيل الصوتي'));
    };
    reader.onerror = () => reject(new Error('تعذر قراءة التسجيل الصوتي'));
    reader.readAsDataURL(blob);
  });

  const startRecording = async () => {
    if (recording) return;
    setRecordingError('');
    if (!navigator.mediaDevices?.getUserMedia) {
      setRecordingError('الميكروفون غير مدعوم في هذا المتصفح.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      recordedChunksRef.current = [];
      const mimeType = getSupportedAudioMimeType(MediaRecorder);
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        const totalSize = recordedChunksRef.current.reduce((sum, chunk) => sum + chunk.size, 0);
        if (totalSize === 0) {
          setRecordingError('لم يتم تسجيل صوت. حاول مرة أخرى.');
          setRecordedAudioBlob(null);
          setRecordedAudioUrl(null);
        } else {
          const blob = new Blob(recordedChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
          setRecordedAudioBlob(blob);
          try {
            const dataUrl = await readBlobAsDataUrl(blob);
            setRecordedAudioUrl(dataUrl);
            setGuestAudioPreview(dataUrl);
          } catch (error) {
            setRecordingError('تعذر تجهيز التسجيل الصوتي.');
          }
        }

        if (mediaStreamRef.current) {
          mediaStreamRef.current.getTracks().forEach((track) => track.stop());
          mediaStreamRef.current = null;
        }
      };

      if (recordedAudioUrl) {
        URL.revokeObjectURL(recordedAudioUrl);
      }

      recorder.start();
      setRecording(true);
      setRecordingDuration(0);
      setRecordedAudioUrl(null);
      setRecordedAudioBlob(null);
      if (recordingTimerRef.current) {
        window.clearInterval(recordingTimerRef.current);
      }
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingDuration((duration) => duration + 1);
      }, 1000);
    } catch (error: any) {
      setRecordingError(error?.message || 'فشل بدء التسجيل.');
    }
  };

  const stopRecording = () => {
    if (!mediaRecorderRef.current) return;
    const recorder = mediaRecorderRef.current;
    setRecording(false);
    if (recordingTimerRef.current) {
      window.clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    try {
      recorder.stop();
      mediaRecorderRef.current = null;
    } catch (error) {
      setRecordingError('فشل إيقاف التسجيل.');
    }
  };

  const handleSendAudio = async () => {
    if (!guestAudioPreview) return;
    setSendingAudio(true);
    try {
      await fetch('/api/rsvps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wedding_slug: slug, guest_name: 'إرسال يدوي', status: 'attending', audio_message: guestAudioPreview })
      });
      alert('تم إرسال الرسالة الصوتية بنجاح');
    } catch (e) {
      alert('تعذر إرسال الرسالة الصوتية');
    } finally {
      setSendingAudio(false);
    }
  };

  const readFileAsDataUrl = (file: File) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('Failed to read file'));
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });

  const handleMediaUpload = async () => {
    if (!slug || (galleryFiles.length === 0 && videoFiles.length === 0)) return;
    setUploadingMedia(true);
    setMediaMessage('');
    try {
      const photoUrls: string[] = [];
      const videoUrls: string[] = [];

      for (const file of galleryFiles) {
        const dataUrl = await readFileAsDataUrl(file);
        const res = await fetch('/api/uploads/image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ slug, fileData: dataUrl, filename: file.name })
        });
        const body = await res.json().catch(() => null);
        if (!res.ok) throw new Error(body?.error || 'Failed to upload image');
        if (body?.url) photoUrls.push(body.url);
      }

      for (const file of videoFiles) {
        const dataUrl = await readFileAsDataUrl(file);
        const res = await fetch('/api/uploads/video', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ slug, fileData: dataUrl, filename: file.name })
        });
        const body = await res.json().catch(() => null);
        if (!res.ok) throw new Error(body?.error || 'Failed to upload video');
        if (body?.url) videoUrls.push(body.url);
      }

      const payload: Record<string, any> = {};
      if (photoUrls.length > 0) payload.gallery_images = [...(Array.isArray(data?.gallery_images) ? data.gallery_images : []), ...photoUrls];
      if (videoUrls.length > 0) payload.videos = [...(Array.isArray(data?.videos) ? data.videos : []), ...videoUrls];

      if (photoUrls.length === 0 && videoUrls.length === 0) {
        throw new Error('No media uploaded');
      }

      const res = await fetch(`/api/weddings/${encodeURIComponent(slug)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(payload)
      });
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error(body?.error || 'Failed to upload media');

      setData(body);
      setGalleryFiles([]);
      setVideoFiles([]);
      setMediaMessage('تم رفع الوسائط بنجاح');
    } catch (err: any) {
      setMediaMessage(err?.message || 'تعذر رفع الوسائط');
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleClearMedia = async (kind: 'photos' | 'videos') => {
    if (!slug) return;
    setUploadingMedia(true);
    setMediaMessage('');
    try {
      const payload = kind === 'photos' ? { gallery_images: [] } : { videos: [] };
      const res = await fetch(`/api/weddings/${encodeURIComponent(slug)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(payload)
      });
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error(body?.error || 'Failed to clear media');
      setData(body);
      if (kind === 'photos') setSelectedPhotoUrls([]);
      if (kind === 'videos') setSelectedVideoUrls([]);
      setMediaMessage(kind === 'photos' ? 'تم حذف جميع الصور' : 'تم حذف جميع الفيديوهات');
    } catch (err: any) {
      setMediaMessage(err?.message || 'تعذر حذف الوسائط');
    } finally {
      setUploadingMedia(false);
    }
  };

  const togglePhotoSelection = (url: string) => {
    setSelectedPhotoUrls((prev) => prev.includes(url) ? prev.filter((item) => item !== url) : [...prev, url]);
  };

  const toggleVideoSelection = (url: string) => {
    setSelectedVideoUrls((prev) => prev.includes(url) ? prev.filter((item) => item !== url) : [...prev, url]);
  };

  const handleDeleteSelectedMedia = async (kind: 'photos' | 'videos') => {
    if (!slug) return;
    const selected = kind === 'photos' ? selectedPhotoUrls : selectedVideoUrls;
    if (selected.length === 0) return;
    setUploadingMedia(true);
    setMediaMessage('');
    try {
      const payload: Record<string, any> = {};

      if (kind === 'photos') {
        const existingGallery = Array.isArray(data?.gallery_images) ? data.gallery_images : [];
        const filteredGallery = existingGallery.filter((url: string) => !selected.includes(url));
        if (filteredGallery.length !== existingGallery.length) payload.gallery_images = filteredGallery;

        if (selected.includes(data?.groom_image_url)) payload.groom_image_url = null;
        if (selected.includes(data?.bride_image_url)) payload.bride_image_url = null;
        if (selected.includes(data?.cover_image_url)) payload.cover_image_url = null;
      } else {
        const existingVideos = Array.isArray(data?.videos) ? data.videos : [];
        payload.videos = existingVideos.filter((url: string) => !selected.includes(url));
      }

      const res = await fetch(`/api/weddings/${encodeURIComponent(slug)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(payload)
      });
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error(body?.error || 'Failed to delete selected media');
      setData(body);
      if (kind === 'photos') setSelectedPhotoUrls([]);
      if (kind === 'videos') setSelectedVideoUrls([]);
      setMediaMessage(kind === 'photos' ? 'تم حذف الصور المحددة' : 'تم حذف الفيديوهات المحددة');
    } catch (err: any) {
      setMediaMessage(err?.message || 'تعذر حذف الوسائط المحددة');
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleDeleteMediaItem = async (kind: 'photos' | 'videos', url: string) => {
    if (!slug) return;
    setUploadingMedia(true);
    setMediaMessage('');
    try {
      const existing = kind === 'photos' ? (Array.isArray(data?.gallery_images) ? data.gallery_images : []) : (Array.isArray(data?.videos) ? data.videos : []);
      const payload = kind === 'photos'
        ? { gallery_images: existing.filter((item: string) => item !== url) }
        : { videos: existing.filter((item: string) => item !== url) };
      const res = await fetch(`/api/weddings/${encodeURIComponent(slug)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(payload)
      });
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error(body?.error || 'Failed to delete media item');
      setData(body);
      setSelectedPhotoUrls((prev) => prev.filter((item) => item !== url));
      setSelectedVideoUrls((prev) => prev.filter((item) => item !== url));
      setMediaMessage(kind === 'photos' ? 'تم حذف الصورة' : 'تم حذف الفيديو');
    } catch (err: any) {
      setMediaMessage(err?.message || 'تعذر حذف الوسائط');
    } finally {
      setUploadingMedia(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 p-6 text-white">
      <div className="mx-auto max-w-5xl space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold">لوحة تحكم العروسين</h1>
            <p className="text-sm text-slate-400">اعرض الحضور، وأرسل رسالة أو ملف صوتي للضيوف من هنا.</p>
          </div>
          <button type="button" onClick={handleLogout} className="rounded-full border border-white/20 bg-slate-900/70 px-4 py-2 text-sm font-semibold transition hover:bg-slate-800">تسجيل خروج</button>
        </div>

        

        <div className={partnerRole === 'groom' ? 'rounded-2xl border border-pink-400/20 bg-pink-500/10 p-4 text-right' : partnerRole === 'bride' ? 'rounded-2xl border border-rose-400/20 bg-rose-500/10 p-4 text-right' : 'rounded-2xl border border-white/10 bg-slate-900/70 p-4 text-right'}>
          <h2 className="text-xl font-semibold">{partnerRole === 'groom' ? 'مرحبًا يا عريسنا' : partnerRole === 'bride' ? 'مرحبًا يا عروسةنا' : 'مرحبًا بكما معًا'}</h2>
          <p className="mt-2 text-sm text-slate-300">{partnerRole === 'groom' ? 'هذه الواجهة مخصصة للعريس لمعرفة الحضور والتواصل مع الضيوف.' : partnerRole === 'bride' ? 'هذه الواجهة مخصصة للعروسة لمتابعة الحضور والرسائل.' : 'هذه الواجهة المشتركة تعرض كل المعلومات الخاصة بالفرح.'}</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-4">
            <h2 className="text-xl font-semibold mb-4">تعديل بيانات الدعوة</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <input value={groomName} onChange={(e) => setGroomName(e.target.value)} placeholder="اسم العريس" className="w-full rounded-xl border border-white/10 bg-slate-950/70 p-3" />
              <input value={brideName} onChange={(e) => setBrideName(e.target.value)} placeholder="اسم العروسة" className="w-full rounded-xl border border-white/10 bg-slate-950/70 p-3" />
              <input value={venueName} onChange={(e) => setVenueName(e.target.value)} placeholder="اسم القاعة" className="w-full rounded-xl border border-white/10 bg-slate-950/70 p-3" />
              <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="العنوان" className="w-full rounded-xl border border-white/10 bg-slate-950/70 p-3" />
              <div className="flex gap-2">
                <input value={googleMapsUrl} onChange={(e) => setGoogleMapsUrl(e.target.value)} placeholder="رابط Google Maps" className="w-full rounded-xl border border-white/10 bg-slate-950/70 p-3" />
                <button type="button" onClick={() => setShowMapHelp(true)} className="rounded-xl border border-white/10 px-3 py-2 text-sm">الحصول على رابط Google Maps</button>
              </div>
              {mapValidationError ? <p className="mt-2 text-sm text-rose-300">{mapValidationError}</p> : null}
              <input type="date" value={weddingDate} onChange={(e) => setWeddingDate(e.target.value)} className="w-full rounded-xl border border-white/10 bg-slate-950/70 p-3" />
              <input type="time" value={weddingTime} onChange={(e) => setWeddingTime(e.target.value)} className="w-full rounded-xl border border-white/10 bg-slate-950/70 p-3" />
            </div>
            <label className="mt-4 block text-sm mb-2">قصة الحب</label>
            <textarea value={story} onChange={(e)=>setStory(e.target.value)} className="w-full min-h-[120px] rounded-xl border border-white/10 bg-slate-950/70 p-3" />
            <label className="mt-4 block text-sm mb-2">رسالة للضيوف</label>
            <textarea value={guestMessage} onChange={(e)=>setGuestMessage(e.target.value)} className="w-full min-h-[100px] rounded-xl border border-white/10 bg-slate-950/70 p-3" />

            <div className="mt-4 rounded-2xl border border-white/10 bg-slate-950/70 p-4">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold text-white">التحكم في الأقسام</p>
                  <p className="text-xs text-slate-400">أوقف أو فعّل أي قسم في صفحة الدعوة من هنا.</p>
                </div>
              </div>
              <div className="mt-4 grid gap-3">
                {weddingSectionConfig.map((section) => (
                  <label key={section.key} className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 text-sm">
                    <span>{section.label}</span>
                    <input
                      type="checkbox"
                      checked={visibleSections[section.key]}
                      onChange={(e) => setVisibleSections((prev) => ({ ...prev, [section.key]: e.target.checked }))}
                      className="h-4 w-4 rounded border-white/20 bg-slate-800"
                    />
                  </label>
                ))}
              </div>
            </div>

            <div className="mt-4 rounded-2xl border border-white/10 bg-slate-950/70 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-white">تغيير الثيم</p>
                  <p className="text-xs text-slate-400">اختر الشكل والألوان الذي سيظهر في الدعوة</p>
                </div>
                <div className="rounded-full bg-pink-500/20 px-3 py-1 text-xs font-semibold text-pink-200">
                  {selectedTheme.name}
                </div>
              </div>
              <div className="mt-4 grid gap-3 md:grid-cols-2">
                {availableThemes.map((themeOption) => {
                  const active = themeId === themeOption.id;
                  return (
                    <button
                      key={themeOption.id}
                      type="button"
                      onClick={() => setThemeId(themeOption.id)}
                      className={`rounded-2xl border p-3 text-right transition ${active ? 'border-pink-400 bg-slate-900/90' : 'border-white/10 bg-slate-900/70'}`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <p className="text-sm font-semibold text-white">{themeOption.name}</p>
                          <p className="mt-1 text-xs text-slate-400">{themeOption.description}</p>
                        </div>
                        <div className="flex gap-1">
                          <span className="h-3 w-3 rounded-full" style={{ backgroundColor: themeOption.colors.primary }} />
                          <span className="h-3 w-3 rounded-full" style={{ backgroundColor: themeOption.colors.accent }} />
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
              <p className="mt-3 text-xs text-slate-400">سيتم تطبيق الثيم بعد الضغط على حفظ التعديلات.</p>
            </div>

            <label className="mt-4 block text-sm mb-2">رسالة صوتية</label>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-3 text-sm">
                <input type="checkbox" checked={allowGuestUploads} onChange={(e) => setAllowGuestUploads(e.target.checked)} className="h-4 w-4" />
                <span>تفعيل الرسائل الصوتية للزوار</span>
              </label>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <label className="flex cursor-pointer items-center justify-between gap-3 rounded-2xl border border-dashed border-white/20 bg-slate-950/70 px-4 py-4 text-sm text-slate-200 transition hover:border-pink-400 hover:text-white">
                <span>اختر ملف صوتي</span>
                <span className="rounded-full bg-pink-500/20 px-3 py-1 text-pink-200">رفع</span>
                <input type="file" accept="audio/*" onChange={(e) => handleAudioPick(e.target.files?.[0] ?? null)} className="hidden" />
              </label>
              {!recording ? (
                <button type="button" onClick={startRecording} className="rounded-2xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-4 text-sm text-emerald-200">تسجيل مباشر</button>
              ) : (
                <button type="button" onClick={stopRecording} className="rounded-2xl border border-rose-400/30 bg-rose-500/10 px-4 py-4 text-sm text-rose-200">إيقاف التسجيل</button>
              )}
            </div>
            {recording ? <p className="mt-2 text-sm text-emerald-200">جارٍ التسجيل... {recordingDuration} ث</p> : null}
            {recordingError ? <p className="mt-2 text-sm text-rose-300">{recordingError}</p> : null}
            {guestAudioPreview ? (
              <div className="mt-3">
                <AudioPlayer src={guestAudioPreview} label="معاينة التسجيل" subtitle="استمع قبل حفظه أو إرساله" />
              </div>
            ) : null}

            

            <div className="mt-4 flex flex-wrap gap-2">
              <button onClick={handleSave} className="rounded bg-pink-500 px-4 py-2" disabled={loading}>{loading ? 'جاري الحفظ...' : 'حفظ التعديلات'}</button>
              <button onClick={handleSendAudio} className="rounded border border-pink-400/30 bg-pink-500/10 px-4 py-2" disabled={sendingAudio || !guestAudioPreview}>{sendingAudio ? 'جاري الإرسال...' : 'إرسال رسالة صوتية الآن'}</button>
              <a href={`/wedding/${slug}`} className="rounded border border-white/10 px-4 py-2">عرض الدعوة</a>
            </div>
            {saveMessage ? <p className="mt-3 text-sm text-pink-200">{saveMessage}</p> : null}
            {showMapHelp ? (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
                <div className="max-w-2xl rounded-2xl bg-white/5 p-6 text-right text-white">
                  <div className="flex justify-between items-start">
                    <h3 className="text-lg font-semibold">كيفية الحصول على رابط Google Maps</h3>
                    <button onClick={() => setShowMapHelp(false)} className="ml-4 rounded-full bg-white/10 px-2 py-1">إغلاق</button>
                  </div>
                  <div className="mt-4 space-y-3 text-sm text-slate-300">
                    <p>اتبع أحد الخطوات التالية للحصول على رابط يعمل كخريطة مضمّنة:</p>
                    <ol className="list-decimal list-inside">
                      <li>افتح الموقع في Google Maps.</li>
                      <li>إذا رأيت زر <strong>مشاركة</strong> (Share)، اضغطه ثم اختَر <strong>تضمين الخريطة</strong> (Embed a map)، ونسخ رابط الـ <strong>src</strong> من الـ iframe.</li>
                      <li>أو انسخ رابط المكان مباشرة من شريط العنوان (مثل روابط التي تحتوي على <code>/place/</code> أو إحداثيات <code>@lat,long</code>).</li>
                      <li>ألصق الرابط هنا وسيقوم النظام بمحاولة تحويله تلقائيًا.</li>
                    </ol>
                    <p className="text-amber-200">ملاحظة: إذا ألصقت رابطًا مختصرًا (maps.app.goo.gl) وسيظهر تحذير، حاول فتح الرابط في المتصفح ونسخ رابط المكان الكامل أو رابط التضمين.</p>
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-4">
            <h2 className="text-lg font-semibold">الصور والفيديوهات</h2>
            <p className="mt-1 text-sm text-slate-400">أضف صورًا أو فيديوهات من هنا، وستظهر تلقائيًا في صفحة الدعوة عند وجود محتوى.</p>

            <label className="mt-4 flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-white/10 bg-slate-950/70 p-4 text-sm">
              <Camera className="h-5 w-5 text-pink-400" />
              <span className="mt-2">اختر صورًا للمعرض</span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => setGalleryFiles(Array.from(e.target.files ?? []))} />
            </label>

            <label className="mt-3 flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-white/10 bg-slate-950/70 p-4 text-sm">
              <Video className="h-5 w-5 text-pink-400" />
              <span className="mt-2">اختر فيديوهات</span>
              <input type="file" accept="video/*" multiple className="hidden" onChange={(e) => setVideoFiles(Array.from(e.target.files ?? []))} />
            </label>

            <label className="mt-3 flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-white/10 bg-slate-950/70 p-4 text-sm">
              <Music2 className="h-5 w-5 text-pink-400" />
              <span className="mt-2">اختر أغنية الدعوة</span>
              <input type="file" accept="audio/*" className="hidden" onChange={(e) => handleMusicPick(e.target.files?.[0] ?? null)} />
            </label>
            {musicFileError ? <p className="mt-3 text-sm text-amber-300">{musicFileError}</p> : null}

            {musicFile ? (
              <div className="mt-3 rounded-2xl border border-white/10 bg-slate-950/70 p-4 text-sm text-slate-300">
                <p>الملف المختار: {musicFile.name}</p>
                <button type="button" onClick={uploadMusicFile} disabled={musicUploading} className="mt-3 rounded-xl bg-pink-500 px-4 py-2 text-white">
                  {musicUploading ? 'جارٍ رفع الأغنية...' : 'رفع الأغنية'}
                </button>
                {musicUploading ? (
                  <div className="mt-3 rounded-full bg-slate-800 p-1">
                    <div className="h-2 rounded-full bg-pink-500 transition-all" style={{ width: `${musicUploadProgress}%` }} />
                  </div>
                ) : null}
                {musicUploadMessage ? <p className="mt-2 text-sm text-pink-200">{musicUploadMessage}</p> : null}
              </div>
            ) : null}

            <div className="mt-4 flex flex-wrap gap-2">
              <button onClick={handleMediaUpload} className="rounded bg-pink-500 px-4 py-2" disabled={uploadingMedia || (galleryFiles.length === 0 && videoFiles.length === 0)}>{uploadingMedia ? 'جارٍ الرفع...' : 'رفع الوسائط'}</button>
              {(galleryFiles.length > 0 || videoFiles.length > 0) ? <span className="rounded bg-slate-800 px-3 py-2 text-sm text-slate-300">{galleryFiles.length} صورة • {videoFiles.length} فيديو</span> : null}
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              <button onClick={() => handleClearMedia('photos')} className="rounded border border-white/10 px-3 py-2 text-sm" disabled={uploadingMedia || !hasVisibleContent(media.photos)}>حذف جميع الصور</button>
              <button onClick={() => handleClearMedia('videos')} className="rounded border border-white/10 px-3 py-2 text-sm" disabled={uploadingMedia || !hasVisibleContent(media.videos)}>حذف جميع الفيديوهات</button>
              <button onClick={() => handleDeleteSelectedMedia('photos')} className="rounded border border-pink-400/30 px-3 py-2 text-sm" disabled={uploadingMedia || selectedPhotoUrls.length === 0}>حذف الصور المحددة ({selectedPhotoUrls.length})</button>
              <button onClick={() => handleDeleteSelectedMedia('videos')} className="rounded border border-pink-400/30 px-3 py-2 text-sm" disabled={uploadingMedia || selectedVideoUrls.length === 0}>حذف الفيديوهات المحددة ({selectedVideoUrls.length})</button>
            </div>

            {mediaMessage ? <p className="mt-3 text-sm text-pink-200">{mediaMessage}</p> : null}
            {data?.mp3_url ? (
              <div className="mt-4">
                <AudioPlayer src={data.mp3_url} label="أغنية الدعوة الحالية" subtitle="تشغيل الموسيقى المتاحة للدعوة" />
              </div>
            ) : null}

            <div className="mt-4 space-y-3">
              {hasVisibleContent(media.photos) ? (
                <div>
                  <p className="text-sm text-slate-300">الصور الحالية</p>
                  <div className="mt-2 grid gap-2 sm:grid-cols-2">
                    {media.photos.map((src, index) => (
                      <button
                        key={`${src}-${index}`}
                        type="button"
                        onClick={() => togglePhotoSelection(src)}
                        className={`relative h-24 overflow-hidden rounded-xl border p-0 transition ${selectedPhotoUrls.includes(src) ? 'border-pink-400 bg-pink-500/10' : 'border-white/10 bg-slate-950/70'}`}
                      >
                        <img src={src} alt={`صورة ${index + 1}`} className="h-full w-full object-cover" />
                        <div className={`absolute inset-0 bg-black/20 transition ${selectedPhotoUrls.includes(src) ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`} />
                        <span className="absolute right-2 top-2 rounded-full border border-white/20 bg-slate-950/70 px-2 py-1 text-[11px] text-slate-200">{selectedPhotoUrls.includes(src) ? 'محدد' : 'اضغط للتحديد'}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}
              {hasVisibleContent(media.videos) ? (
                <div>
                  <p className="text-sm text-slate-300">الفيديوهات الحالية</p>
                  <div className="mt-2 space-y-2">
                    {media.videos.map((src: string, index: number) => (
                      <button
                        key={`${src}-${index}`}
                        type="button"
                        onClick={() => toggleVideoSelection(src)}
                        className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left transition ${selectedVideoUrls.includes(src) ? 'border-pink-400 bg-pink-500/10' : 'border-white/10 bg-slate-950/70'}`}
                      >
                        <PlayCircle className="h-5 w-5 text-pink-400" />
                        <span className="truncate text-sm">{src}</span>
                        <span className="ml-auto text-xs text-slate-400">{selectedVideoUrls.includes(src) ? 'محدد' : 'اضغط للتحديد'}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">الحضور</h2>
              <span className="text-sm text-slate-400">{rsvps.length} ضيف</span>
            </div>
            {loadingRsvps ? <p className="mt-4 text-sm text-slate-400">جارٍ تحميل الحضور...</p> : null}
            <div className="mt-4 space-y-4">
              {rsvps.length === 0 ? (
                <div className="rounded-3xl border border-white/10 bg-slate-950/70 p-4 text-center text-sm text-slate-400">لا يوجد حضور بعد.</div>
              ) : (
                <div className="space-y-4">
                  {rsvps.map((item) => (
                    <div key={item.id || `${item.guest_name}-${item.created_at}` } className="rounded-3xl border border-white/10 bg-slate-950/70 p-4 shadow-[0_10px_40px_rgba(0,0,0,0.25)]">
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                        <div className="space-y-2 text-right">
                          <p className="text-base font-semibold text-white">{item.guest_name || 'ضيف'}</p>
                          <p className="text-sm text-slate-400">{item.created_at ? new Date(item.created_at).toLocaleString('ar-EG') : ''}</p>
                        </div>
                        <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${item.status === 'attending' ? 'bg-emerald-500/20 text-emerald-200' : 'bg-amber-500/20 text-amber-200'}`}>
                          {item.status === 'attending' ? 'سيتواجد' : item.status || 'في الانتظار'}
                        </span>
                      </div>

                      <div className="mt-3 grid gap-4 sm:grid-cols-2">
                        <div className="rounded-3xl border border-white/10 bg-slate-900/80 p-4">
                          <p className="text-sm text-slate-400">الرسالة</p>
                          <p className="mt-2 min-h-[64px] whitespace-pre-wrap text-sm leading-6 text-slate-200">{item.message || item.guest_message || 'لا توجد رسالة نصية'}</p>
                        </div>
                        <div className="rounded-[2rem] border border-pink-500/20 bg-gradient-to-br from-slate-950/95 to-slate-900/80 p-4 shadow-[0_16px_45px_rgba(0,0,0,0.25)]">
                          <div className="flex items-center justify-between gap-3">
                            <div>
                              <p className="text-sm uppercase tracking-[0.2em] text-pink-300">التسجيل الصوتي</p>
                              <p className="mt-1 text-base font-semibold text-white">رسالة صوتية من الضيف</p>
                            </div>
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-pink-500/15 text-pink-300">
                              <PlayCircle className="h-6 w-6" />
                            </div>
                          </div>
                          {item.audio_message ? (
                            <div className="mt-4">
                              <AudioPlayer src={item.audio_message} label="رسالة صوتية" subtitle="استمع لتسجيل الضيف" />
                            </div>
                          ) : (
                            <p className="mt-4 text-sm text-slate-500">لا يوجد تسجيل صوتي</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
