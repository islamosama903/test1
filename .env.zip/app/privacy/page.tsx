export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-slate-950 p-8 text-white">
      <div className="mx-auto max-w-4xl rounded-3xl border border-white/10 bg-slate-900/70 p-8">
        <h1 className="text-3xl font-semibold">سياسة الخصوصية</h1>
        <p className="mt-4 text-slate-300">تُستخدم هذه المنصة لتخزين وإدارة بيانات الدعوات والذكريات بطريقة آمنة وشفافة، مع الالتزام بالحد الأدنى من البيانات اللازمة.</p>
      </div>
    </main>
  );
}
