import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { isStorageConfigured } from '@/lib/storage-service';

export async function GET() {
  const configured = isStorageConfigured();
  if (!configured) {
    return NextResponse.json(
      { configured: false, error: 'Supabase storage is not configured. Check NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY or NEXT_PUBLIC_SUPABASE_ANON_KEY, and SUPABASE_SERVICE_ROLE_KEY.' },
      { status: 503 }
    );
  }

  const bucketNames = ['images', 'videos', 'music'];
  const { data: buckets, error } = await supabaseAdmin.storage.listBuckets();
  if (error) {
    return NextResponse.json({ configured: true, buckets: [], error: error.message || 'Failed to list storage buckets' }, { status: 500 });
  }

  const existingBucketNames = Array.isArray(buckets) ? buckets.map((bucket) => bucket.name) : [];
  const missingBuckets = bucketNames.filter((name) => !existingBucketNames.includes(name));
  return NextResponse.json({ configured: true, expectedBuckets: bucketNames, existingBucketNames, missingBuckets }, { status: 200 });
}
