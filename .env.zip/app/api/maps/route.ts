import { NextResponse } from 'next/server';

function looksLikeGoogleMaps(u: string) {
  if (!u) return false;
  return /google\.com\/maps|maps\.app\.goo\.gl|goo\.gl\/maps|www\.google\.com\/maps/i.test(u) || /\/maps\/(place|search|dir|@)/i.test(u) || /@[-0-9.,]+/.test(u) || /\bq=/.test(u);
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    let input = String(body?.url || '').trim();
    // If user pasted full iframe HTML, extract the src attribute
    try {
      const iframeMatch = input.match(/<iframe[^>]+src=["']([^"']+)["']/i);
      if (iframeMatch && iframeMatch[1]) input = iframeMatch[1];
    } catch (e) {}
    if (!input) return NextResponse.json({ ok: false, error: 'Missing url' }, { status: 400 });

    let finalUrl = input;
    try {
      const res = await fetch(input, { method: 'GET', redirect: 'follow' });
      finalUrl = res.url || input;
      // if finalUrl still looks generic, try to parse HTML for canonical or og:url
      if (!/\/maps\/(place|search)\//i.test(finalUrl) && !/@[-0-9.,]+/.test(finalUrl) && !/\bq=/.test(finalUrl)) {
        try {
          const text = await res.text();
          const canMatch = text.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i);
          const ogMatch = text.match(/<meta[^>]+property=["']og:url["'][^>]+content=["']([^"']+)["']/i);
          const href = (canMatch && canMatch[1]) || (ogMatch && ogMatch[1]);
          if (href && /^https?:\/\//i.test(href)) {
            finalUrl = href;
          }
        } catch (e) {
          // ignore HTML parse errors
        }
      }
    } catch (e) {
      // couldn't fetch — keep original
      finalUrl = input;
    }

    const isMaps = looksLikeGoogleMaps(finalUrl);

    // If it's a Google Maps link
    if (isMaps) {
      // If finalUrl already contains embed or output=embed, use as-is
      if (/\/maps\/(embed)|output=embed/i.test(finalUrl)) {
        return NextResponse.json({ ok: true, resolvedUrl: finalUrl, embedUrl: finalUrl });
      }

      // If finalUrl contains a specific place or coordinates, construct an embed-friendly URL
      const hasPlace = /\/maps\/place\//i.test(finalUrl) || /\/maps\/search\//i.test(finalUrl) || /@[-0-9.,]+/.test(finalUrl) || /\bq=/.test(finalUrl);
      if (hasPlace) {
        const embedUrl = `https://www.google.com/maps?q=${encodeURIComponent(finalUrl)}&output=embed`;
        return NextResponse.json({ ok: true, resolvedUrl: finalUrl, embedUrl });
      }

      // ambiguous Google Maps link
      return NextResponse.json({ ok: false, resolvedUrl: finalUrl, error: 'الرابط غير واضح كوجهة؛ الرجاء استخدام رابط المكان الكامل أو رابط التضمين (Embed).' }, { status: 200 });
    }

    // Not a Google Maps link — try to extract coordinates or canonical URL from arbitrary map pages (e.g., Apple Maps)
    try {
      const r = await fetch(finalUrl, { method: 'GET' });
      const html = await r.text().catch(() => '');
      // try common patterns for coordinates: @lat,lng
      const atMatch = html.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
      if (atMatch) {
        const lat = atMatch[1];
        const lng = atMatch[2];
        const embedUrl = `https://www.google.com/maps?q=${lat},${lng}&output=embed`;
        return NextResponse.json({ ok: true, resolvedUrl: finalUrl, embedUrl });
      }

      // try JSON-LD latitude/longitude
      const latMatch = html.match(/"latitude"\s*[:"]\s*([\d.-]+)/i) || html.match(/"lat"\s*[:"]\s*([\d.-]+)/i);
      const lngMatch = html.match(/"longitude"\s*[:"]\s*([\d.-]+)/i) || html.match(/"lng"\s*[:"]\s*([\d.-]+)/i);
      if (latMatch && lngMatch) {
        const lat = latMatch[1];
        const lng = lngMatch[1];
        const embedUrl = `https://www.google.com/maps?q=${lat},${lng}&output=embed`;
        return NextResponse.json({ ok: true, resolvedUrl: finalUrl, embedUrl });
      }

      // try meta tags (og:url or canonical) that might point to a Google Maps place
      const canMatch = html.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i);
      const ogMatch = html.match(/<meta[^>]+property=["']og:url["'][^>]+content=["']([^"']+)["']/i);
      const href = (canMatch && canMatch[1]) || (ogMatch && ogMatch[1]);
      if (href && /google\.com\/maps/i.test(href)) {
        const embedUrl = `https://www.google.com/maps?q=${encodeURIComponent(href)}&output=embed`;
        return NextResponse.json({ ok: true, resolvedUrl: finalUrl, embedUrl, canonical: href });
      }
    } catch (e) {
      // ignore
    }

    return NextResponse.json({ ok: false, resolvedUrl: finalUrl, error: 'تعذر استخراج إحداثيات أو رابط مكان من هذا الرابط. الرجاء استخدام رابط المكان الكامل أو رابط التضمين.' }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Failed to resolve' }, { status: 500 });
  }
}

export const GET = () => NextResponse.json({ ok: true });
