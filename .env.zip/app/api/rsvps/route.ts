import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const weddingIdOrSlug = searchParams.get('wedding_id') || searchParams.get('slug');
    if (!weddingIdOrSlug) return NextResponse.json([]);
    const data = await store.listRsvpsForWedding(weddingIdOrSlug);
    return NextResponse.json(data);
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as any;
    const data = await store.insertRsvp(payload);

    if (payload.status === 'attending' && payload.wedding_slug) {
      try {
        const wedding = await store.getWeddingBySlug(payload.wedding_slug);
        if (wedding?.guest_message_audio) {
          const audioUrl = wedding.guest_message_audio;
          const response = await fetch('https://example.com/notify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ guest_name: payload.guest_name, audio_url: audioUrl, wedding_slug: payload.wedding_slug })
          }).catch(() => null);
          if (!response?.ok) {
            // Silent fallback; the message is stored locally for the couple to review.
          }
        }
      } catch (e) {
        // ignore
      }
    }

    return NextResponse.json(data, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}
