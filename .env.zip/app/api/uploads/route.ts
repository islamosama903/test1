import { NextResponse } from 'next/server';

export async function POST() {
  return NextResponse.json({ error: 'Use /api/uploads/image, /api/uploads/video, or /api/uploads/music' }, { status: 404 });
}
