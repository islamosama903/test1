import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';
import { uploadBuffer, StorageNotConfiguredError } from '@/lib/storage-service';

const uploadConfig = {
  image: { accept: /^image\//, folder: 'images', bucket: 'images' },
  video: { accept: /^video\//, folder: 'videos', bucket: 'videos' },
  music: { accept: /^audio\//, folder: 'music', bucket: 'music' },
} as const;

type UploadType = keyof typeof uploadConfig;

function getUploadType(type: string): UploadType | null {
  if (type === 'image' || type === 'video' || type === 'music') return type;
  return null;
}

async function parseUploadRequest(request: Request) {
  const contentTypeHeader = request.headers.get('content-type') || '';
  let slug: string | null = null;
  let filename: string | null = null;
  let buffer: Buffer | null = null;
  let fileContentType: string | null = null;

  if (contentTypeHeader.includes('multipart/form-data')) {
    const formData = await request.formData();
    slug = String(formData.get('slug') || formData.get('wedding_slug') || '').trim() || null;
    const file = formData.get('file') as any;
    if (!slug || !file || typeof file.arrayBuffer !== 'function') {
      return { slug, filename, buffer, fileContentType };
    }

    filename = String(file.name || 'upload.bin').trim().slice(0, 200);
    fileContentType = file.type || 'application/octet-stream';
    const arrayBuffer = await file.arrayBuffer();
    buffer = Buffer.from(arrayBuffer);
  } else {
    const body = await request.json().catch(() => null);
    if (!body) return { slug, filename, buffer, fileContentType };

    slug = String(body.slug || body.wedding_slug || '').trim() || null;
    filename = String(body.filename || 'upload.bin').trim().slice(0, 200);
    const dataUrl = String(body.fileData || '');
    const match = dataUrl.match(/^data:(.+);base64,(.+)$/);
    if (!slug || !match) return { slug, filename, buffer, fileContentType };

    fileContentType = match[1];
    const base64 = match[2];
    buffer = Buffer.from(base64, 'base64');
  }

  return { slug, filename, buffer, fileContentType };
}

export async function POST(request: Request, { params }: { params: { type: string } }) {
  const uploadType = getUploadType(params.type);
  if (!uploadType) {
    return NextResponse.json({ error: 'Unsupported upload type' }, { status: 404 });
  }

  try {
    const { slug, filename, buffer, fileContentType } = await parseUploadRequest(request);
    if (!slug || !filename || !buffer || !fileContentType) {
      return NextResponse.json({ error: 'Missing upload parameters' }, { status: 400 });
    }

    const config = uploadConfig[uploadType];
    if (!config.accept.test(fileContentType)) {
      return NextResponse.json({ error: `Invalid ${uploadType} file type` }, { status: 400 });
    }

    const user = await store.getUserFromRequest(request);
    const wedding = await store.getWeddingBySlug(slug);

    if (wedding) {
      const allowGuest = wedding.allow_guest_uploads === undefined ? true : Boolean(wedding.allow_guest_uploads);
      if (!user) {
        if (!allowGuest) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      } else if (user.role === 'super_admin') {
        // ok
      } else if (user.role === 'couple') {
        if (String(user.wedding_id) !== String(wedding.id) && user.wedding_id != null) {
          return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
        }
      } else {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      }
    } else if (user && user.role !== 'super_admin') {
      return NextResponse.json({ error: 'Wedding not found' }, { status: 404 });
    }

    const url = await uploadBuffer({ slug, buffer, contentType: fileContentType, filename, folder: config.folder, bucket: config.bucket });
    return NextResponse.json({ url }, { status: 201 });
  } catch (e: any) {
    const message = e?.message || 'Failed';
    const status = message.includes('Storage is not configured') ? 503 : 500;
    console.error('Upload failed:', message, e?.stack ? e.stack : 'no stack');
    return NextResponse.json({ error: message }, { status });
  }
}
