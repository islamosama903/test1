import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';
import { getContactSettings, updateContactSettings } from '@/lib/settings-store';

export async function GET() {
  try {
    return NextResponse.json(getContactSettings());
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Failed' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await store.getUserFromRequest(request);
    if (!user || user.role !== 'super_admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await request.json();
    return NextResponse.json(updateContactSettings(payload));
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Failed' }, { status: 500 });
  }
}
