import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';

export async function GET() {
  try {
    const data = await store.listWeddings();
    return NextResponse.json(data);
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await store.getUserFromRequest(request);
    if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = (await request.json()) as any;
    const data = await store.createWedding(payload);

    const createdAccounts: any[] = [];
    try {
      const slug = String(data?.slug || payload.slug || `wedding-${Date.now()}`);
      const safeSlug = slug.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'couple';

      const accounts = [
        payload.groom_account ? { ...payload.groom_account, role: 'couple' } : null,
        payload.bride_account ? { ...payload.bride_account, role: 'couple' } : null
      ].filter(Boolean) as Array<{ username?: string; password?: string; role: string }>;

      if (accounts.length === 0) {
        const fallbackUsername = `${safeSlug}-account`;
        const fallbackPassword = 'wedding123';
        const fallbackEmail = `${safeSlug}@wedding.local`;
        const user = await store.createUser({ email: fallbackEmail, username: fallbackUsername, password: fallbackPassword, role: 'couple', wedding_id: data?.id || null });
        createdAccounts.push({ email: user.email, username: user.username, password: fallbackPassword, role: 'couple' });
      } else {
        for (const entry of accounts) {
          const username = entry.username?.trim() || `${safeSlug}-${entry.role === 'couple' ? 'couple' : 'account'}`;
          const password = entry.password?.trim() || 'wedding123';
          const email = `${username.replace(/[^a-z0-9]+/gi, '.').toLowerCase()}@wedding.local`;
          const user = await store.createUser({ email, username, password, role: 'couple', wedding_id: data?.id || null });
          createdAccounts.push({ email: user.email, username: user.username, password, role: 'couple' });
        }
      }
    } catch (accountError) {
      // Continue even if account creation fails so the wedding itself is still created.
    }

    return NextResponse.json({ ...data, couple_accounts: createdAccounts }, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}
