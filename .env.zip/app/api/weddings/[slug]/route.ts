import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';

export async function GET(request: Request, { params }: { params: { slug: string } }) {
  const { slug } = params;
  try {
    const data = await store.getWeddingBySlug(slug);
    if (!data) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json(data);
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}

export async function PATCH(request: Request, { params }: { params: { slug: string } }) {
  const { slug } = params;
  try {
    const user = await store.getUserFromRequest(request);
    const payload = await request.json();
    // allow super_admin
    if (user && user.role === 'super_admin') {
      const updated = await store.updateWedding(slug, payload);
      return NextResponse.json(updated);
    }
    // allow couple owner
    if (user && user.role === 'couple') {
      // ensure user owns this wedding by slug
      const wedding = await store.getWeddingBySlug(slug);
      if (wedding && (wedding.slug === slug) && (String(user.wedding_id) === String(wedding.id) || user.wedding_id === wedding.id || user.wedding_id == null)) {
        const updated = await store.updateWedding(slug, payload);
        return NextResponse.json(updated);
      }
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: { params: { slug: string } }) {
  const { slug } = params;
  try {
    const user = await store.getUserFromRequest(request);
    if (user && user.role === 'super_admin') {
      const deleted = await store.deleteWedding(slug);
      return NextResponse.json(deleted);
    }

    if (user && user.role === 'couple') {
      const wedding = await store.getWeddingBySlug(slug);
      if (wedding && (String(user.wedding_id) === String(wedding.id) || user.wedding_id === wedding.id || user.wedding_id == null)) {
        const deleted = await store.deleteWedding(slug);
        return NextResponse.json(deleted);
      }
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}
