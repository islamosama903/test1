import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const res = NextResponse.json({ ok: true });
  const forwardedProto = request.headers.get('x-forwarded-proto') || '';
  const isHttps = process.env.NODE_ENV === 'production' || forwardedProto.toLowerCase().includes('https');
  const cookieOptions = {
    httpOnly: true,
    path: '/',
    sameSite: 'lax' as const,
    secure: isHttps
  };
  res.cookies.set('session_user', '', { ...cookieOptions, maxAge: 0 });
  res.cookies.set('session_role', '', { ...cookieOptions, maxAge: 0 });
  res.cookies.set('session_wedding', '', { ...cookieOptions, maxAge: 0 });
  return res;
}
