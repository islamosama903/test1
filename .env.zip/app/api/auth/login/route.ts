import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';

function buildCookieOptions(request: Request) {
  const forwardedProto = request.headers.get('x-forwarded-proto') || '';
  const isHttps = process.env.NODE_ENV === 'production' || forwardedProto.toLowerCase().includes('https');

  return {
    httpOnly: true,
    path: '/',
    sameSite: 'lax' as const,
    secure: isHttps,
    maxAge: 60 * 60 * 24 * 7
  };
}

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    // Debug: log which required environment variables are missing (no secret values)
    try {
      const required = ['NEXT_PUBLIC_SUPABASE_URL', 'NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY', 'NEXT_PUBLIC_SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'AUTH_SECRET', 'NEXTAUTH_SECRET', 'JWT_SECRET', 'ADMIN_EMAIL', 'ADMIN_PASSWORD'];
      const missing = required.filter((k) => !process.env[k]);
      if (missing.length) console.error('[auth/login] missing env:', missing.join(', '));
      else console.error('[auth/login] all expected auth env vars present');
    } catch (e) {
      console.error('[auth/login] env-check-failed');
    }

    const body = await request.json().catch(() => ({}));
    const identifier = typeof body?.identifier === 'string' ? body.identifier.trim() : '';
    const password = typeof body?.password === 'string' ? body.password : '';
    const cookieOptions = buildCookieOptions(request);

    if (!identifier || !password) {
      return NextResponse.json({ ok: false, error: 'Please provide both identifier and password' }, { status: 400 });
    }

    const user = await store.verifyUserCredentials({ identifier, password });
    if (!user) {
      // do not reveal whether identifier exists
      return NextResponse.json({ ok: false, error: 'Invalid credentials' }, { status: 401 });
    }

    const wedding = user.wedding_id ? await store.getWeddingById(user.wedding_id) : null;
    const weddingSlug = wedding?.slug || (user.role === 'couple' ? 'demo-wedding' : null);
    const token = store.createSessionToken(user);
    const res = NextResponse.json(
      { ok: true, user: { id: user.id, email: user.email, username: user.username, role: user.role, wedding_id: user.wedding_id, wedding_slug: weddingSlug } },
      { headers: { 'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate' } }
    );

    // set cookies with explicit maxAge and secure attributes
    res.cookies.set('session_user', token, cookieOptions);
    res.cookies.set('session_role', user.role || 'couple', cookieOptions);
    if (user.role === 'couple' && weddingSlug) {
      res.cookies.set('session_wedding', String(weddingSlug), cookieOptions);
    } else {
      res.cookies.set('session_wedding', '', { ...cookieOptions, maxAge: 0 });
    }

    return res;
  } catch (error: any) {
    return NextResponse.json({ ok: false, error: error?.message || 'Login failed' }, { status: 500 });
  }
}
