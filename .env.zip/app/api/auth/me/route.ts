import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const user = await store.getUserFromRequest(request);
    if (!user) return NextResponse.json({ user: null }, { status: 401, headers: { 'Cache-Control': 'no-store' } });
    return NextResponse.json({ user: { id: user.id, email: user.email, username: user.username, role: user.role, wedding_id: user.wedding_id } }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error: any) {
    return NextResponse.json({ user: null, error: error?.message || 'Failed to load session' }, { status: 500 });
  }
}
