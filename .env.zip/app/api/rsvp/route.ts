import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as any;
    const data = await store.insertRsvp(payload);
    return NextResponse.json(data, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}
