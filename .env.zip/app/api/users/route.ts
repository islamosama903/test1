import { NextResponse } from 'next/server';
import * as store from '@/lib/data-store';

export async function GET(request: Request) {
  try {
    // protect: only super_admin can list users
    // note: store.getUserFromRequest checks session cookie
    const user = await store.getUserFromRequest(request);
    if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const users = await store.listUsers();
    return NextResponse.json(users);
  } catch (e:any) {
    return NextResponse.json({ error: e.message||'Failed'},{status:500});
  }
}

export async function POST(request: Request) {
  try {
    const payload = await request.json().catch(() => ({}));
    const requestedRole = typeof payload?.role === 'string' ? payload.role : 'couple';
    const user = await store.getUserFromRequest(request);

    if (user?.role === 'super_admin') {
      const created = await store.createUser(payload);
      return NextResponse.json(created, { status: 201 });
    }

    if (requestedRole === 'couple' && payload?.email && payload?.username && payload?.password) {
      const created = await store.createUser({ ...payload, role: 'couple' });
      return NextResponse.json(created, { status: 201 });
    }

    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  } catch (e:any) {
    return NextResponse.json({ error: e.message||'Failed' }, { status: 500 });
  }
}
