"use client";

import Link from 'next/link';
import { useState } from 'react';
import { getPostLoginTarget } from '@/lib/auth-routing';

export default function LoginPage() {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const login = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setMessage('جاري تسجيل الدخول...');
    setIsSubmitting(true);
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 8000);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ identifier, password }),
        signal: controller.signal,
        credentials: 'same-origin',
        cache: 'no-store'
      });
      const payload = await res.json().catch(() => ({}));
      if (res.ok && payload?.user) {
        const role = payload.user.role;
        const weddingSlug = payload.user.wedding_slug || payload.user.wedding_id;
        window.location.assign(getPostLoginTarget(role, weddingSlug));
        return;
      }
      setMessage(typeof payload?.error === 'string' && payload.error ? payload.error : 'بيانات الدخول غير صحيحة.');
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        setMessage('انتهت المهلة أثناء محاولة تسجيل الدخول. تحقق من اتصال الإنترنت وحاول مرة أخرى.');
      } else {
        setMessage('فشل الاتصال بالخادم، يرجى إعادة المحاولة');
      }
    } finally {
      window.clearTimeout(timeout);
      setIsSubmitting(false);
    }
  };

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[radial-gradient(circle_at_top_left,_rgba(244,114,182,0.22),_transparent_35%),radial-gradient(circle_at_bottom_right,_rgba(45,212,191,0.2),_transparent_30%),linear-gradient(135deg,_#111827_0%,_#1f2937_45%,_#0f172a_100%)] px-4 py-10 text-slate-100">
      <div className="absolute inset-0 bg-[linear-gradient(120deg,_rgba(255,255,255,0.04)_0%,_transparent_30%,_rgba(255,255,255,0.03)_100%)]" />
      <div className="relative w-full max-w-5xl overflow-hidden rounded-[2rem] border border-white/10 bg-slate-950/80 shadow-[0_30px_120px_rgba(0,0,0,0.45)] backdrop-blur-xl">
        <div className="grid lg:grid-cols-[1.05fr_0.95fr]">
          <section className="relative overflow-hidden bg-gradient-to-br from-rose-500 via-pink-500 to-orange-400 p-8 sm:p-10 lg:p-12">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(255,255,255,0.28),_transparent_35%)]" />
            <div className="relative h-full flex flex-col justify-between">
              <div>
                <span className="inline-flex rounded-full border border-white/25 bg-white/15 px-3 py-1 text-xs font-semibold tracking-[0.3em] text-white/90">منصة العروسين</span>
                <h1 className="mt-6 text-3xl font-semibold leading-tight sm:text-4xl">مرحبًا بك في صفحة تسجيل الدخول الموحدة</h1>
                <p className="mt-4 max-w-md text-sm leading-7 text-white/85 sm:text-base">أدخل بياناتك في صفحة واحدة، وسيتم توجيهك تلقائيًا إلى لوحة التحكم المناسبة حسب نوع الحساب.</p>
              </div>

              <div className="mt-8 rounded-[1.5rem] border border-white/20 bg-white/10 p-4 text-sm backdrop-blur">
                <p className="font-semibold">فقط أدخل بياناتك</p>
                <ul className="mt-3 space-y-2 text-white/80">
                  <li>• التوجيه التلقائي إلى لوحة الإدارة أو العروسين</li>
                  <li>• وصول سريع إلى دعوة الزفاف وإدارتها</li>
                  <li>• تجربة دخول موحدة وسهلة</li>
                </ul>
              </div>
            </div>
          </section>

          <section className="p-6 sm:p-8 lg:p-10">
            <form onSubmit={login} className="rounded-[1.75rem] border border-white/10 bg-slate-900/70 p-6 shadow-inner shadow-black/20" aria-labelledby="couple-login-heading">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-rose-300">تسجيل دخول العروسين</p>
                  <h2 id="couple-login-heading" className="mt-1 text-2xl font-semibold text-white">سجّل دخولك</h2>
                </div>
                <div className="rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-200">مميز</div>
              </div>

              <div className="mt-6 space-y-4">
                <div>
                  <label className="mb-2 block text-sm text-slate-400" htmlFor="identifier">البريد أو اسم المستخدم</label>
                  <input id="identifier" name="identifier" type="text" autoComplete="username" required disabled={isSubmitting} className="auth-input" placeholder="اكتب البريد أو اسم المستخدم" value={identifier} onChange={(e) => setIdentifier(e.target.value)} />
                </div>
                <div>
                  <label className="mb-2 block text-sm text-slate-400" htmlFor="password">كلمة المرور</label>
                  <input id="password" name="password" type="password" autoComplete="current-password" required disabled={isSubmitting} className="auth-input" placeholder="أدخل كلمة المرور" value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <button disabled={isSubmitting} className="auth-button">{isSubmitting ? 'جاري تسجيل الدخول...' : 'دخول'}</button>
              </div>

              {message ? <p className="mt-4 text-sm text-rose-200" aria-live="polite">{message}</p> : null}
            </form>
          </section>
        </div>
      </div>
    </main>
  );
}
