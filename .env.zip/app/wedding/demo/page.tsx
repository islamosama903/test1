'use client';

import { useEffect, useState } from 'react';
import { CalendarDays, Clock3, MapPin, Music2, Heart, Camera, Video, MessageCircleHeart, PlayCircle, Sparkles, PartyPopper } from 'lucide-react';
import { motion } from 'framer-motion';

const gallery = [1, 2, 3, 4];

function getTimeLeft(targetDate: Date) {
  const difference = targetDate.getTime() - Date.now();
  if (difference <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0 };
  }
  return {
    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((difference / (1000 * 60)) % 60),
    seconds: Math.floor((difference / 1000) % 60)
  };
}

export default function WeddingInvitationPage() {
  const [form, setForm] = useState({ guest_name: '', is_attending: true, guest_count: 1, message: '' });
  const [status, setStatus] = useState('');
  const [isOpened, setIsOpened] = useState(false);
  const [timeLeft, setTimeLeft] = useState(() => getTimeLeft(new Date('2026-08-15T19:30:00')));

  useEffect(() => {
    const timer = window.setInterval(() => {
      setTimeLeft(getTimeLeft(new Date('2026-08-15T19:30:00')));
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('جاري الإرسال...');

    const response = await fetch('/api/rsvps', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wedding_id: 'demo-wedding', ...form, guest_count: Number(form.guest_count) })
    });

    if (response.ok) {
      setStatus('تمت الإضافة بنجاح');
      setForm({ guest_name: '', is_attending: true, guest_count: 1, message: '' });
    } else {
      setStatus('حدث خطأ أثناء الإرسال');
    }
  };

  if (!isOpened) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[radial-gradient(circle_at_top,_rgba(236,72,153,0.25),_transparent_30%),linear-gradient(135deg,#0f172a_0%,#111827_100%)] px-4 py-10 text-white">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="w-full max-w-xl rounded-[2rem] border border-pink-400/20 bg-white/10 p-8 text-center shadow-2xl shadow-pink-950/30 backdrop-blur-xl">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-pink-500/20 text-pink-300">
            <Sparkles className="h-10 w-10" />
          </div>
          <p className="mt-5 text-sm uppercase tracking-[0.3em] text-pink-200">دعوة زفاف رقمية</p>
          <h1 className="mt-3 text-3xl font-bold sm:text-4xl">محمود & أمنية</h1>
          <p className="mt-4 text-slate-300">رسالة مغلقة، وعندما تفتحها تبدأ رحلة الحب والذكريات.</p>
          <button onClick={() => setIsOpened(true)} className="mt-8 rounded-full bg-pink-500 px-6 py-3 font-semibold transition hover:bg-pink-600">افتح الدعوة</button>
        </motion.div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(236,72,153,0.2),_transparent_30%),linear-gradient(135deg,#111827_0%,#1f2937_100%)] px-4 py-6 text-white sm:px-6 lg:px-8">
      <section className="mx-auto max-w-6xl space-y-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="rounded-[2rem] border border-white/10 bg-white/10 p-8 text-center shadow-2xl shadow-pink-950/20 backdrop-blur-xl">
          <p className="text-sm uppercase tracking-[0.3em] text-pink-200">دعوة زفاف</p>
          <h1 className="mt-3 text-4xl font-bold sm:text-5xl">محمود & أمنية</h1>
          <p className="mx-auto mt-3 max-w-2xl text-lg text-slate-300">سنحتفل معاً في يومٍ مميز سيبقى في الذاكرة للأبد، ويومٍ يبدأ فيه فصل جديد من الحب.</p>

          <div className="mt-8 grid gap-4 rounded-[1.7rem] border border-pink-400/20 bg-pink-500/10 p-6 text-right sm:grid-cols-2">
            <div className="flex items-center gap-3"><CalendarDays className="h-5 w-5 text-pink-300" /><div><p className="text-sm text-slate-400">التاريخ</p><p>١٥ أغسطس ٢٠٢٦</p></div></div>
            <div className="flex items-center gap-3"><Clock3 className="h-5 w-5 text-pink-300" /><div><p className="text-sm text-slate-400">الوقت</p><p>٧:٣٠ مساءً</p></div></div>
            <div className="flex items-center gap-3"><MapPin className="h-5 w-5 text-pink-300" /><div><p className="text-sm text-slate-400">اسم القاعة</p><p>قاعة الورد</p></div></div>
            <div className="flex items-center gap-3"><Music2 className="h-5 w-5 text-pink-300" /><div><p className="text-sm text-slate-400">الموسيقى</p><p>تشغيل/إيقاف</p></div></div>
          </div>

          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <button className="rounded-full bg-pink-500 px-6 py-3 font-semibold transition hover:bg-pink-600">افتح الدعوة</button>
            <button className="rounded-full border border-white/20 px-6 py-3 transition hover:bg-white/10">فتح في خرائط Google</button>
          </div>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-[2rem] border border-white/10 bg-white/10 p-6 backdrop-blur-xl">
            <div className="flex items-center gap-3 text-pink-300"><Heart className="h-5 w-5" /><h2 className="text-2xl font-semibold">قصة الحب</h2></div>
            <p className="mt-4 text-slate-300">بدأت القصة من لقائنا الأول، ثم تطورت إلى قصة تجمع بين الحب والوفاء والاحتفال بكل ما يربطنا معاً. اليوم نحتفل بأن كل خطوة كانت تستحق الانتظار.</p>
          </div>

          <div className="rounded-[2rem] border border-white/10 bg-white/10 p-6 backdrop-blur-xl">
            <div className="flex items-center gap-3 text-pink-300"><PartyPopper className="h-5 w-5" /><h2 className="text-2xl font-semibold">العد التنازلي</h2></div>
            <div className="mt-5 grid grid-cols-4 gap-3 text-center">
              {[
                ['الأيام', timeLeft.days],
                ['الساعات', timeLeft.hours],
                ['الدقائق', timeLeft.minutes],
                ['الثواني', timeLeft.seconds]
              ].map(([label, value]) => (
                <div key={label} className="rounded-2xl border border-white/10 bg-slate-900/70 p-3">
                  <p className="text-2xl font-bold">{String(value).padStart(2, '0')}</p>
                  <p className="mt-1 text-xs text-slate-400">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1fr_0.8fr]">
          <div className="rounded-[2rem] border border-white/10 bg-white/10 p-6 backdrop-blur-xl">
            <div className="flex items-center gap-3 text-pink-300"><Camera className="h-5 w-5" /><h2 className="text-2xl font-semibold">معرض الصور</h2></div>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {gallery.map((item) => (
                <div key={item} className="h-40 rounded-2xl border border-white/10 bg-[linear-gradient(135deg,#1f2937_0%,#334155_100%)]" />
              ))}
            </div>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/10 p-6 backdrop-blur-xl">
            <div className="flex items-center gap-3 text-pink-300"><Video className="h-5 w-5" /><h2 className="text-2xl font-semibold">الفيديو</h2></div>
            <div className="mt-6 flex h-48 items-center justify-center rounded-2xl border border-dashed border-white/20 bg-slate-900/70">
              <PlayCircle className="h-16 w-16 text-pink-400" />
            </div>
          </div>
        </div>

        <div className="rounded-[2rem] border border-white/10 bg-white/10 p-6 backdrop-blur-xl">
          <div className="flex items-center gap-3 text-pink-300"><MessageCircleHeart className="h-5 w-5" /><h2 className="text-2xl font-semibold">RSVP</h2></div>
          <form onSubmit={handleSubmit} className="mt-6 grid gap-4 md:grid-cols-2">
            <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="الاسم" value={form.guest_name} onChange={(e) => setForm({ ...form, guest_name: e.target.value })} required />
            <select className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" value={form.is_attending ? 'true' : 'false'} onChange={(e) => setForm({ ...form, is_attending: e.target.value === 'true' })}>
              <option value="true">سأحضر</option>
              <option value="false">لن أحضر</option>
            </select>
            <input type="number" min="1" className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="عدد الأفراد" value={form.guest_count} onChange={(e) => setForm({ ...form, guest_count: Number(e.target.value) })} />
            <textarea className="md:col-span-2 rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="رسالة قصيرة" rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
            <button className="md:col-span-2 rounded-2xl bg-pink-500 px-4 py-3 font-semibold transition hover:bg-pink-600">إرسال</button>
            {status ? <p className="md:col-span-2 text-sm text-pink-200">{status}</p> : null}
          </form>
        </div>
      </section>
    </main>
  );
}
