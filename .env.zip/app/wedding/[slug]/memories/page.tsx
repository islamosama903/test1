'use client';

import { useEffect, useState } from 'react';

export default function MemoriesPage() {
  const [files, setFiles] = useState<FileList | null>(null);
  const [images, setImages] = useState<string[]>([]);
  const [slug, setSlug] = useState('');

  useEffect(() => {
    // attempt to get slug from URL
    const parts = window.location.pathname.split('/');
    const s = parts[2] ?? '';
    setSlug(s);
    // load existing uploads if any
    fetch(`/api/weddings/${encodeURIComponent(s)}`).then(r => r.json()).then((d) => {
      if (d && d.cover_image_url) setImages((prev) => [...prev, d.cover_image_url]);
    }).catch(()=>{});
  }, []);

  const handleUpload = async () => {
    if (!files || !slug) return;
    const f = files[0];
    const formData = new FormData();
    formData.append('slug', slug);
    formData.append('file', f);

    const uploadType = f.type.startsWith('video/') ? 'video' : 'image';
    const res = await fetch(`/api/uploads/${uploadType}`, {
      method: 'POST',
      body: formData,
    });
    const body = await res.json();
    if (body.url) setImages(prev => [body.url, ...prev]);
  };

  return (
    <main className="min-h-screen bg-slate-950 p-6 text-white">
      <div className="mx-auto max-w-4xl space-y-6">
        <h1 className="text-2xl font-semibold">ذكريات بعد الفرح</h1>
        <p className="text-sm text-slate-400">حمل صورك وفيديوهاتك؛ ستُخزن في Bucket الدعوة أو محليًا إذا لم تُعد Supabase.</p>

        <div className="flex gap-3">
          <input type="file" accept="image/*,video/*" onChange={(e) => setFiles(e.target.files)} />
          <button onClick={handleUpload} className="rounded bg-pink-500 px-4 py-2">رفع</button>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-4">
          {images.map((src, i) => (
            <div key={i} className="h-40 overflow-hidden rounded">
              {/* naive render: if src ends with video ext, show video */}
              {src.endsWith('.mp4') || src.endsWith('.webm') ? (
                <video src={src} controls className="h-full w-full object-cover" />
              ) : (
                <img src={src} alt={`mem-${i}`} className="h-full w-full object-cover" />
              )}
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
