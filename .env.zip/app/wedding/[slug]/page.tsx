"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { useParams } from 'next/navigation';
import { AnimatePresence, motion } from 'framer-motion';
import { CalendarDays, Clock3, MapPin, Music2, Heart, Camera, Video, MessageCircleHeart, PlayCircle, Pause, PartyPopper, Copy, Send, Sparkles, ChevronRight, X, Mail } from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';
import AudioPlayer from '@/components/AudioPlayer';
import { formatArabicDate, formatArabicTime, getCountdownParts, getWeddingMedia, getVisibleSections, hasVisibleContent, parseWeddingDateTime } from '@/lib/wedding-utils';
import { getButtonStyle, getCardStyle, getThemeStyle, resolveWeddingTheme } from '@/lib/wedding-theme';

type TimelineItem = {
  title: string;
  time: string;
  detail: string;
};

const defaultTimelineItems: TimelineItem[] = [
  { title: 'استقبال الضيوف', time: '٥:٣٠', detail: 'بداية الاحتفال مع نسماتٍ دافئة وموسيقى هادئة.' },
  { title: 'الخطوبة', time: '٦:٠٠', detail: 'لحظة مميزة تجمع بين العائلة والأحباء تحت أضواءٍ ساحرة.' },
  { title: 'العشاء والتجمع', time: '٧:٣٠', detail: 'أجواءٍ مليئة بالضحك، واللمسات الجميلة، والذكريات.' },
];

const defaultVisibleSections: Record<string, boolean> = {
  hero: true,
  countdown: true,
  dateTime: true,
  venue: true,
  timeline: true,
  gallery: true,
  video: true,
  music: true,
  rsvp: true,
  messages: true,
};

type SectionProps = {
  children: React.ReactNode;
  className?: string;
  delay?: number;
};

function Section({ children, className = '' }: SectionProps) {
  return <section className={className}>{children}</section>;
}

export default function WeddingSlugPage() {
  const params = useParams();
  const slug = params?.slug as string;
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [revealed, setRevealed] = useState(false);
  const [countdown, setCountdown] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true });
  const [rsvpName, setRsvpName] = useState('');
  const [rsvpStatus, setRsvpStatus] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [guestMessageText, setGuestMessageText] = useState('');
  const [messageName, setMessageName] = useState('');
  const [messageStatus, setMessageStatus] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordedAudioBlob, setRecordedAudioBlob] = useState<Blob | null>(null);
  const [recordingError, setRecordingError] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [resolvedMapUrl, setResolvedMapUrl] = useState<string | null>(null);
  const [mapInvalidMessage, setMapInvalidMessage] = useState<string | null>(null);
  const [contactSettings, setContactSettings] = useState<any>(null);
  const theme = useMemo(() => resolveWeddingTheme(data?.theme), [data?.theme]);
  const themeStyle = useMemo(() => getThemeStyle(theme), [theme]);
  const coverPanelClassName = theme.id === 'midnight-bloom'
    ? 'relative z-10 flex w-full max-w-xl flex-col items-center rounded-[2.8rem] border border-[var(--theme-border)] bg-[linear-gradient(135deg,rgba(15,23,42,0.96),rgba(20,35,59,0.96))] p-8 text-center shadow-[0_30px_120px_rgba(2,8,23,0.35)] backdrop-blur-xl'
    : 'relative z-10 flex w-full max-w-xl flex-col items-center rounded-[2.8rem] border border-[var(--theme-border)] bg-[linear-gradient(135deg,rgba(255,255,255,0.96),rgba(248,246,241,0.96))] p-8 text-center shadow-[0_30px_120px_rgba(0,0,0,0.12)] backdrop-blur-xl';
  const heroPanelClassName = theme.id === 'midnight-bloom'
    ? 'relative z-10 w-full overflow-hidden px-6 py-6 shadow-[0_24px_70px_rgba(2,8,23,0.28)]'
    : 'relative z-10 w-full overflow-hidden px-6 py-6 shadow-[0_24px_70px_rgba(15,23,42,0.08)]';
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);

  useEffect(() => {
    if (!slug) return;

    const loadSettings = async () => {
      try {
        const res = await fetch('/api/settings');
        if (res.ok) {
          const settings = await res.json();
          setContactSettings(settings);
        }
      } catch (e) {}
    };

    const loadWedding = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/weddings/${encodeURIComponent(slug)}`);
        if (!res.ok) throw res;
        const d = await res.json();
        setData(d);
      } catch (err) {
        setData(null);
      } finally {
        setLoading(false);
      }
    };

    loadSettings();
    loadWedding();
  }, [slug]);

  useEffect(() => {
    const u = data?.google_maps_url?.trim();
    if (!u) return;
    // attempt to resolve short/redirecting map links server-side
    if (u) {
      (async () => {
        try {
          const res = await fetch('/api/maps', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: u }) });
          const body = await res.json().catch(() => null);
          if (body?.ok) {
            setResolvedMapUrl(body.embedUrl || body.resolvedUrl || null);
            setMapInvalidMessage(null);
          } else {
            setResolvedMapUrl(null);
            setMapInvalidMessage(body?.error || 'الرابط غير مدعوم لعرض الخريطة');
          }
        } catch (e) {
          setResolvedMapUrl(null);
          setMapInvalidMessage('تعذر التحقق من رابط الخريطة');
        }
      })();
    }
  }, [data?.google_maps_url]);

  useEffect(() => {
    if (!data?.wedding_date) return;
    const target = parseWeddingDateTime(data.wedding_date, data.wedding_time);
    if (!target) return;
    const tick = () => setCountdown(getCountdownParts(target.toISOString()));
    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, [data?.wedding_date, data?.wedding_time]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleEnded = () => setIsPlaying(false);

    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [data?.mp3_url]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.play().catch(() => setIsPlaying(false));
    } else {
      audio.pause();
    }
  }, [isPlaying, data?.mp3_url]);

  const title = data ? `${data.groom_name} & ${data.bride_name}`.toUpperCase() : 'محمود & أمنية';
  const envelopeLabel = data ? `${data.groom_name} ❤️ ${data.bride_name}` : 'محمود ❤️ أمنية';
  const date = formatArabicDate(data?.wedding_date) ?? '١٥ أغسطس ٢٠٢٦';
  const time = formatArabicTime(data?.wedding_time) ?? '٧:٣٠ مساءً';
  const venue = data?.venue_name ?? 'قاعة الورد';
  const media = useMemo(() => getWeddingMedia(data), [data]);
  const visibleSections = useMemo(() => getVisibleSections(data), [data]);
  const timelineItems: TimelineItem[] = Array.isArray(data?.timeline) && data.timeline.length > 0 ? data.timeline as TimelineItem[] : defaultTimelineItems;
  const coupleGreetingText = data?.guest_message || null;
  const coupleGreetingAudioUrl = data?.guest_message_audio || null;
  const musicLabel = data?.mp3_url ? (isPlaying ? 'إيقاف' : 'تشغيل') : 'لا توجد موسيقى';
  const hasPhotos = hasVisibleContent(media.photos);
  const hasVideos = hasVisibleContent(media.videos);
  const contactEnabled = Boolean(contactSettings?.enabled);
  const contactName = contactSettings?.name || 'Islam Osama';
  const contactPhone = contactSettings?.phone || '01050759399';
  const contactWhatsapp = contactSettings?.whatsapp || 'https://wa.me/201050759399';

  const handleRsvp = async (e: FormEvent) => {
    e.preventDefault();
    if (!rsvpName.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/rsvps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wedding_id: data?.id ?? slug, wedding_slug: slug, guest_name: rsvpName, status: 'attending' })
      });
      const result = await res.json().catch(() => null);
      if (!res.ok) throw new Error(result?.error || 'Failed to submit RSVP');
      setRsvpStatus('تم تسجيل حضورك بنجاح.');
      setRsvpName('');
    } catch (error: any) {
      setRsvpStatus(error?.message ? `حدث خطأ: ${error.message}` : 'حدث خطأ أثناء حفظ تأكيد الحضور.');
    } finally {
      setSubmitting(false);
    }
  };

  const getSupportedAudioMimeType = () => {
    if (typeof MediaRecorder === 'undefined') return '';
    if (MediaRecorder.isTypeSupported?.('audio/webm;codecs=opus')) return 'audio/webm;codecs=opus';
    if (MediaRecorder.isTypeSupported?.('audio/webm')) return 'audio/webm';
    if (MediaRecorder.isTypeSupported?.('audio/ogg;codecs=opus')) return 'audio/ogg;codecs=opus';
    if (MediaRecorder.isTypeSupported?.('audio/ogg')) return 'audio/ogg';
    return '';
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const readBlobAsDataUrl = (blob: Blob) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('Failed to read audio data'));
    };
    reader.onerror = () => reject(new Error('Failed to read audio data'));
    reader.readAsDataURL(blob);
  });

  // Small calendar renderer (mobile-first compact calendar)
  const renderMiniCalendar = (isoDate?: string) => {
    try {
      const d = isoDate ? new Date(isoDate) : new Date();
      const year = d.getFullYear();
      const month = d.getMonth();
      const first = new Date(year, month, 1);
      const startDay = first.getDay(); // 0..6 (Sun..Sat)
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const weeks: Array<Array<number | null>> = [];
      let week: Array<number | null> = Array(startDay).fill(null);
      for (let day = 1; day <= daysInMonth; day++) {
        week.push(day);
        if (week.length === 7) { weeks.push(week); week = []; }
      }
      if (week.length) {
        while (week.length < 7) week.push(null);
        weeks.push(week);
      }
      return { weeks, month, year, day: d.getDate() };
    } catch (e) {
      return null;
    }
  };

  const miniCal = renderMiniCalendar(data?.wedding_date);
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const handleGuestAudioPick = (file: File | null) => {
    if (!file) return;
    try {
      if (recordedAudioUrl) URL.revokeObjectURL(recordedAudioUrl);
    } catch (e) {}
    setRecordedAudioBlob(file);
    setRecordedAudioUrl(URL.createObjectURL(file));
  };

  const startRecording = async () => {
    if (recording) return;
    setRecordingError('');
    if (!navigator.mediaDevices?.getUserMedia) {
      setRecordingError('الميكروفون غير مدعوم في هذا المتصفح.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      recordedChunksRef.current = [];
      const mimeType = getSupportedAudioMimeType();
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        const totalSize = recordedChunksRef.current.reduce((sum, chunk) => sum + chunk.size, 0);
        if (totalSize === 0) {
          setRecordingError('لم يتم تسجيل صوت. حاول مرة أخرى.');
          setRecordedAudioBlob(null);
          setRecordedAudioUrl(null);
        } else {
          const blob = new Blob(recordedChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
          setRecordedAudioBlob(blob);
          setRecordedAudioUrl(URL.createObjectURL(blob));
        }

        if (mediaStreamRef.current) {
          mediaStreamRef.current.getTracks().forEach((track) => track.stop());
          mediaStreamRef.current = null;
        }
      };

      if (recordedAudioUrl) {
        URL.revokeObjectURL(recordedAudioUrl);
      }

      recorder.start();
      setRecording(true);
      setRecordingDuration(0);
      setRecordedAudioUrl(null);
      setRecordedAudioBlob(null);
      if (recordingTimerRef.current) {
        window.clearInterval(recordingTimerRef.current);
      }
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingDuration((duration) => duration + 1);
      }, 1000);
    } catch (error: any) {
      setRecordingError(error?.message || 'فشل بدء التسجيل.');
    }
  };

  const stopRecording = () => {
    if (!mediaRecorderRef.current) return;
    const recorder = mediaRecorderRef.current;
    setRecording(false);
    if (recordingTimerRef.current) {
      window.clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    try {
      recorder.stop();
      mediaRecorderRef.current = null;
    } catch (error) {
      setRecordingError('فشل إيقاف التسجيل.');
    }
  };

  const handleSendGuestMessage = async () => {
    const trimmedMessage = guestMessageText.trim();
    const trimmedName = messageName.trim();

    if (!trimmedMessage && !recordedAudioBlob) {
      setMessageStatus('يرجى كتابة رسالة أو تسجيل صوتي قبل الإرسال.');
      return;
    }

    setSendingMessage(true);
    setMessageStatus('');

    try {
      const payload: any = {
        wedding_slug: slug,
        guest_name: trimmedName || 'ضيف',
        status: 'message',
      };

      if (trimmedMessage) payload.message = trimmedMessage;
      if (recordedAudioBlob) payload.audio_message = await readBlobAsDataUrl(recordedAudioBlob);

      const res = await fetch('/api/rsvps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await res.json().catch(() => null);
      if (!res.ok) throw new Error(result?.error || 'Failed to send message');

      setMessageStatus('تم إرسال رسالتك بنجاح. شكراً لك!');
      setGuestMessageText('');
      setMessageName('');
      setRecordedAudioUrl(null);
      setRecordedAudioBlob(null);
      setRecordingError('');
    } catch (error: any) {
      setMessageStatus(error?.message ? `حدث خطأ: ${error.message}` : 'تعذر إرسال الرسالة.');
    } finally {
      setSendingMessage(false);
    }
  };

  return (
    <main style={themeStyle} className="relative min-h-screen overflow-x-hidden bg-[var(--theme-background)] text-[var(--theme-text)]">
      <AnimatePresence mode="wait">
        {!revealed ? (
          <motion.div
            key="cover"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.04 }}
            transition={{ duration: 0.7 }}
            className="relative flex min-h-screen items-center justify-center overflow-hidden px-4"
          >
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(197,168,106,0.18),_transparent_40%),linear-gradient(135deg,rgba(255,255,255,0.7),transparent)]" />
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className={coverPanelClassName}>
              <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6 }} className="mb-6 rounded-full border border-[var(--theme-border)] bg-[var(--theme-background)] p-6 shadow-sm">
                <Mail className="h-14 w-14" style={{ color: 'var(--theme-accent)' }} />
              </motion.div>
              <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="text-sm uppercase tracking-[0.35em]" style={{ color: 'var(--theme-secondary)' }}>دعوة رقمية فاخرة</motion.p>
              <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.28 }} className="mt-3 text-4xl font-semibold sm:text-5xl" style={{ fontFamily: theme.fonts.heading, color: 'var(--theme-primary)' }}>{title}</motion.h1>
              <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.36 }} className="mt-4 max-w-md text-sm leading-8 sm:text-base" style={{ color: 'var(--theme-muted)' }}>
                {loading ? 'جارٍ تحضير تجربة دعوةٍ مميزة...' : 'انقر لفتح المغلف الفاخر وادخل إلى دعوتك الخاصة.'}
              </motion.p>
              <motion.button
                whileHover={{ scale: 1.04, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setRevealed(true);
                  setIsPlaying(true);
                }}
                className="mt-8 rounded-full border border-white/0 px-6 py-3 font-semibold"
                style={{ ...getButtonStyle(theme), color: 'var(--theme-text)' }}
              >
                افتح الدعوة
              </motion.button>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.45 }} className="mt-6 flex items-center gap-2 rounded-full border border-[var(--theme-border)] bg-[var(--theme-background)] px-4 py-2 text-sm" style={{ color: 'var(--theme-muted)' }}>
                <Sparkles className="h-4 w-4" style={{ color: 'var(--theme-accent)' }} />
                <span>تجربة بلمسة فاخرة ومؤثرة</span>
              </motion.div>
            </motion.div>

            {/* envelope animation removed per user request */}
          </motion.div>
        ) : (
          <motion.div
            key="invitation"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.75 }}
            className="relative"
          >
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute left-0 top-0 h-60 w-60 -translate-x-1/3 -translate-y-1/3 rounded-full bg-[var(--theme-accent)]/15 blur-[32px]" />
            </div>

            <div className="relative mx-auto flex min-h-screen w-full max-w-6xl flex-col px-4 py-6 sm:px-6 lg:px-8">
              {/* Header card (compact mobile-first) */}
              {visibleSections.hero ? (
                <motion.header initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className={heroPanelClassName} style={getCardStyle(theme)}>
                  <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                    <div className="max-w-xl">
                      <p className="text-xs uppercase tracking-[0.32em]" style={{ color: 'var(--theme-secondary)' }}>Wedding Invitation</p>
                      <h1 className="mt-3 text-4xl font-semibold tracking-[0.06em] sm:text-5xl" style={{ fontFamily: theme.fonts.heading, letterSpacing: '0.08em', color: 'var(--theme-primary)' }}>{title}</h1>
                      <p className="mt-3 max-w-2xl text-sm leading-7" style={{ color: 'var(--theme-muted)' }}>{data?.story ?? 'A beautiful love story brought together by family, friends, and unforgettable moments.'}</p>
                    </div>

                  {(coupleGreetingText || coupleGreetingAudioUrl) ? (
                    <div className="mt-6 rounded-[1.75rem] border border-[var(--theme-border)] bg-[var(--theme-surface)] p-5 shadow-sm">
                      <div className="flex items-center gap-3">
                        <MessageCircleHeart className="h-5 w-5" style={{ color: 'var(--theme-primary)' }} />
                        <h2 className="text-2xl font-semibold" style={{ color: 'var(--theme-primary)' }}>تحية العروسين</h2>
                      </div>
                      <div className="mt-4 space-y-4">
                        {coupleGreetingText ? (
                          <p className="text-sm leading-7" style={{ color: 'var(--theme-muted)' }}>{coupleGreetingText}</p>
                        ) : null}
                        {coupleGreetingAudioUrl ? (
                          <AudioPlayer src={coupleGreetingAudioUrl} label="رسالة صوتية من العروسين" subtitle="استمع لتحية العروسين" />
                        ) : null}
                      </div>
                    </div>
                  ) : null}

                  {visibleSections.countdown ? (
                    <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
                      {['Days','Hours','Minutes','Seconds'].map((label, i) => (
                        <div key={label} className="rounded-3xl bg-[var(--theme-background)] p-4 text-center shadow-sm ring-1 ring-[var(--theme-border)]">
                          <p className="text-2xl font-semibold" style={{ color: 'var(--theme-primary)' }}>{i===0?countdown.days:i===1?countdown.hours:i===2?countdown.minutes:countdown.seconds}</p>
                          <p className="mt-2 text-xs uppercase tracking-[0.24em]" style={{ color: 'var(--theme-secondary)' }}>{label}</p>
                        </div>
                      ))}
                    </div>
                  ) : null}
                  </div>
                </motion.header>
              ) : null}



              {/* Wedding day luxury calendar */}
              {visibleSections.venue ? (
                <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.06 }} className="mt-4 w-full">
                  <div className="relative overflow-hidden rounded-[2.5rem] border border-[var(--theme-border)] bg-[var(--theme-background)] p-6 shadow-[0_30px_90px_rgba(15,23,42,0.14)]" style={{ backgroundImage: 'radial-gradient(circle at top left, rgba(255,255,255,0.75), transparent 28%), radial-gradient(circle at bottom right, rgba(255,255,255,0.30), transparent 24%)' }}>
                    <div className="pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full bg-[var(--theme-accent)]/12 blur-3xl" />
                    <div className="pointer-events-none absolute -right-10 -bottom-10 h-40 w-40 rounded-full bg-[var(--theme-primary)]/12 blur-3xl" />

                    <div className="relative z-10 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
                      <div className="flex flex-col items-center justify-center rounded-[2rem] border border-[var(--theme-border)] bg-[var(--theme-surface)] p-7 text-center shadow-[0_18px_50px_rgba(15,23,42,0.08)]">
                        <p className="text-sm uppercase tracking-[0.32em]" style={{ color: 'var(--theme-muted)' }}>Wedding Day</p>
                        <p className="mt-4 text-[4rem] font-semibold leading-none" style={{ fontFamily: theme.fonts.heading, color: 'var(--theme-primary)' }}>{miniCal?.day ?? '-'}</p>
                        <p className="mt-3 text-sm uppercase tracking-[0.32em]" style={{ color: 'var(--theme-secondary)' }}>{miniCal ? monthNames[miniCal.month] : ''} {miniCal ? miniCal.year : ''}</p>
                        <div className="mt-6 flex items-center justify-center rounded-full border border-[var(--theme-accent)] bg-[var(--theme-primary)]/90 px-4 py-2 shadow-[0_12px_30px_rgba(85,107,47,0.18)]">
                          <span className="text-sm font-semibold" style={{ color: 'var(--theme-text)' }}>Wedding Date</span>
                        </div>
                      </div>

                      <div className="rounded-[2rem] border border-[var(--theme-border)] bg-[var(--theme-surface)] p-6 shadow-[0_18px_50px_rgba(15,23,42,0.08)]">
                        <div className="grid grid-cols-7 gap-3 text-[0.65rem] uppercase tracking-[0.28em]" style={{ color: 'var(--theme-muted)' }}>
                          {dayNames.map((h) => <div key={h} className="text-center font-semibold">{h}</div>)}
                        </div>
                        <div className="mt-4 grid grid-cols-7 gap-3">
                          {miniCal?.weeks.map((week, weekIndex) => (
                            <div key={weekIndex} className="contents">
                              {week.map((d, idx) => {
                                const isWeddingDay = d === miniCal.day;
                                if (!d) {
                                  return <div key={idx} className="h-12 w-full" />;
                                }

                                return (
                                  <button
                                    key={idx}
                                    type="button"
                                    className={`flex h-12 w-full items-center justify-center gap-1 rounded-full transition duration-300 ${isWeddingDay ? 'border-[var(--theme-accent)] bg-[var(--theme-primary)] text-white shadow-[0_12px_30px_rgba(85,107,47,0.25)]' : 'border border-[var(--theme-border)] bg-[var(--theme-background)] text-[var(--theme-text)] hover:border-[var(--theme-accent)] hover:bg-[var(--theme-surface)]'}`}
                                    style={isWeddingDay ? { boxShadow: '0 24px 60px rgba(200, 169, 106, 0.18)' } : undefined}
                                  >
                                    <span className="text-base font-semibold">{d}</span>
                                    {isWeddingDay && <Heart className="h-4 w-4 fill-red-500 text-red-500" />}
                                  </button>
                                );
                              })}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="relative z-10 mt-6 h-px bg-[var(--theme-accent)]/20" />

                    <div className="relative z-10 mt-6 grid gap-4 sm:grid-cols-2">
                      {[{
                        icon: MapPin,
                        label: 'Venue',
                        value: data?.venue_name ?? venue,
                      }, {
                        icon: Clock3,
                        label: 'Time',
                        value: time,
                      }].map((item) => {
                        const Icon = item.icon;
                        return (
                          <div key={item.label} className="rounded-[1.75rem] border border-[var(--theme-border)] bg-[var(--theme-background)] p-5 shadow-[0_18px_40px_rgba(15,23,42,0.06)] transition duration-300 hover:-translate-y-1">
                            <div className="flex items-center gap-3">
                              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--theme-accent)]/12 text-[var(--theme-primary)]">
                                <Icon className="h-5 w-5" />
                              </div>
                              <div>
                                <p className="text-xs uppercase tracking-[0.28em]" style={{ color: 'var(--theme-muted)' }}>{item.label}</p>
                                <p className="mt-1 text-sm font-semibold" style={{ color: 'var(--theme-text)' }}>{item.value}</p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </motion.section>
              ) : null}

              {/* Map */}
              {(data?.google_maps_url || data?.address) ? (
                <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }} className="mt-4 w-full">
                  <h2 className="text-lg font-semibold" style={{ color: 'var(--theme-primary)' }}>مكان القاعة</h2>
                  <p className="text-sm" style={{ color: 'var(--theme-muted)' }}>{data?.venue_name ?? venue}</p>
                  <div className="mt-3 overflow-hidden rounded-[1.5rem] border border-[var(--theme-border)] bg-[var(--theme-background)]/70 shadow-sm">
                    {mapInvalidMessage ? (
                      <div className="p-4 text-right text-slate-200">
                        <p className="text-sm font-semibold text-rose-300">لا يمكن عرض الخريطة</p>
                        <p className="mt-1 text-sm">{mapInvalidMessage}</p>
                      </div>
                    ) : (
                      <iframe title="wedding-map" src={(() => {
                        const prefer = resolvedMapUrl || data?.google_maps_url?.trim();
                        const v = prefer;
                        try {
                          if (v && /^https?:\/\//i.test(v)) {
                            if (v.includes('/embed') || v.includes('output=embed')) return v;
                            return `https://www.google.com/maps?q=${encodeURIComponent(v)}&output=embed`;
                          }
                        } catch (e) {}
                        const fallback = data?.address || venue || '';
                        return `https://www.google.com/maps?q=${encodeURIComponent(fallback)}&output=embed`;
                      })()} width="100%" height="220" loading="lazy" className="block w-full h-[220px] border-0" />
                    )}
                  </div>
                </motion.section>
              ) : null}

              {/* Gallery */}
              {visibleSections.gallery && hasPhotos ? (
                <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.16 }} className="mt-4 w-full">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold" style={{ color: 'var(--theme-primary)' }}>معرض الصور</h2>
                    <div className="text-sm" style={{ color: 'var(--theme-muted)' }}>{media.photos.length} صورة</div>
                  </div>
                  <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
                    {media.photos.slice(0,4).map((src, i) => (
                      <button key={i} onClick={() => setSelectedImage(src)} className="overflow-hidden rounded-xl border border-white/6">
                        <img src={src} className="h-36 w-full object-cover" />
                      </button>
                    ))}
                  </div>
                </motion.section>
              ) : null}

              {/* Videos */}
              {visibleSections.video && hasVideos ? (
                <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.16 }} className="mt-4 w-full">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold">الفيديو</h2>
                    <div className="text-sm text-slate-400">{media.videos.length} فيديو</div>
                  </div>
                  <div className="mt-3 overflow-hidden rounded-xl border border-white/8 bg-black/20">
                    <video src={media.videos[0]} controls className="w-full h-56 object-cover" />
                  </div>
                </motion.section>
              ) : null}

              {/* Timeline */}
              {visibleSections.timeline ? (
                <Section className="mt-6">
                  <div className="flex items-center gap-3" style={{ color: 'var(--theme-primary)' }}><Clock3 className="h-5 w-5" /><h2 className="text-2xl font-semibold">الجدول الزمني</h2></div>
                <div className="mt-4 space-y-4">
                  {timelineItems.map((item, index) => (
                    <motion.div key={item.title} initial={{ opacity: 0, x: index % 2 === 0 ? -12 : 12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.5, delay: index * 0.06 }} className="flex flex-col gap-3 rounded-[1.4rem] border border-[var(--theme-border)] bg-[var(--theme-surface)] p-4 shadow-sm">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-lg font-semibold" style={{ color: 'var(--theme-primary)' }}>{item.title}</p>
                          <p className="mt-1 text-sm" style={{ color: 'var(--theme-muted)' }}>{item.detail}</p>
                        </div>
                        <div className="rounded-full px-3 py-1 text-sm" style={{ backgroundColor: 'var(--theme-background)', color: 'var(--theme-secondary)' }}>{item.time}</div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </Section>
              ) : null}

              {/* RSVP form (full) */}
              {visibleSections.rsvp ? (
                <Section className="mt-6">
                  <div className="flex items-center gap-3" style={{ color: 'var(--theme-primary)' }}><MessageCircleHeart className="h-5 w-5" /><h2 className="text-2xl font-semibold">RSVP</h2></div>
                <form onSubmit={handleRsvp} className="mt-4 grid gap-3 rounded-[1.5rem] border border-[var(--theme-border)] bg-[var(--theme-surface)] p-4 shadow-sm">
                  <input value={rsvpName} onChange={(e) => setRsvpName(e.target.value)} placeholder="اسمك الكامل" className="rounded-2xl border border-[var(--theme-border)] bg-[var(--theme-background)] px-4 py-3 text-right outline-none ring-0 transition focus:border-[var(--theme-accent)]" />
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <button type="submit" disabled={submitting} className="w-full rounded-full px-4 py-3 font-semibold text-white sm:w-auto" style={getButtonStyle(theme)}>{submitting ? 'جارٍ الإرسال...' : 'تأكيد الحضور'}</button>
                    <button type="button" onClick={() => { navigator.clipboard.writeText(typeof window !== 'undefined' ? window.location.href : ''); }} className="w-full rounded-full border border-[var(--theme-border)] bg-[var(--theme-background)] px-4 py-3 text-center text-[var(--theme-muted)] sm:w-auto" style={{ color: 'var(--theme-muted)' }}>نسخ الرابط</button>
                  </div>
                  {rsvpStatus ? <p className="mt-2 text-sm" style={{ color: 'var(--theme-muted)' }}>{rsvpStatus}</p> : null}
                </form>
              </Section>
              ) : null}

              {/* Messages / RSVP form and guest audio message */}
              {visibleSections.messages ? (
                <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-4 w-full rounded-[1.75rem] border border-[var(--theme-border)] bg-[var(--theme-surface)] p-5 shadow-sm">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-semibold" style={{ color: 'var(--theme-primary)' }}>أرسل رسالة للعروسين</h2>
                    <p className="mt-1 text-sm" style={{ color: 'var(--theme-muted)' }}>يمكنك إرسال رسالة نصية أو تسجيل صوتي.</p>
                  </div>
                </div>

                <div className="mt-4 grid gap-3">
                  <input value={messageName} onChange={(e) => setMessageName(e.target.value)} placeholder="اسمك" className="w-full rounded-2xl border border-[var(--theme-border)] bg-[var(--theme-background)] px-4 py-3 text-right outline-none" />
                  <textarea value={guestMessageText} onChange={(e) => setGuestMessageText(e.target.value)} placeholder="اكتب رسالتك" className="w-full min-h-[120px] rounded-2xl border border-[var(--theme-border)] bg-[var(--theme-background)] px-4 py-3 text-right outline-none" />

                  <div className="rounded-3xl border border-dashed border-[var(--theme-border)] bg-[var(--theme-background)]/80 p-4">
                    <p className="text-sm leading-6 text-[var(--theme-text)]">
                      اضغط هنا لتسجيل رسالة صوتية خاصة للعروسين. بعد التسجيل، يمكنك إرسالها مع رسالتك ليتمكنوا من الاستماع إليها.
                    </p>
                    <div className="mt-4 flex flex-wrap items-center gap-3">
                      <button type="button" onClick={recording ? stopRecording : startRecording} className="rounded-2xl px-4 py-3 text-sm font-semibold text-white shadow-md transition" style={getButtonStyle(theme)}>
                        {recording ? 'إيقاف التسجيل' : 'تسجيل صوتي'}
                      </button>
                    </div>
                    {recording ? <p className="mt-3 text-sm" style={{ color: 'var(--theme-muted)' }}>جاري التسجيل... المدة {formatDuration(recordingDuration)}</p> : null}
                    {recordingError ? <p className="mt-3 text-sm text-rose-500">{recordingError}</p> : null}
                  </div>

                  {recordedAudioUrl ? (
                    <div className="rounded-3xl border border-[var(--theme-border)] bg-[var(--theme-background)] p-4 shadow-sm">
                      <AudioPlayer src={recordedAudioUrl} label="معاينة التسجيل" subtitle="استمع قبل الإرسال" />
                    </div>
                  ) : null}

                  <div className="flex flex-wrap items-center gap-3">
                    <button onClick={handleSendGuestMessage} className="rounded-full px-5 py-3 text-sm font-semibold text-white shadow-md transition" style={getButtonStyle(theme)}>
                      {sendingMessage ? 'جارٍ الإرسال...' : 'إرسال الرسالة'}
                    </button>
                    {messageStatus ? <p className="text-sm" style={{ color: 'var(--theme-muted)' }}>{messageStatus}</p> : null}
                  </div>
                </div>
              </motion.section>
              ) : null}

              <div style={{ height: 120 }} />
            </div>
            <AnimatePresence>
              {selectedImage ? (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-xl">
                  <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }} className="relative max-w-4xl rounded-[1.5rem] border border-white/10 bg-slate-900/90 p-3 shadow-2xl">
                    <button onClick={() => setSelectedImage(null)} className="absolute right-3 top-3 rounded-full border border-white/10 bg-slate-950/60 p-2">
                      <X className="h-5 w-5" />
                    </button>
                    <img src={selectedImage} alt="معرض الصورة" className="max-h-[80vh] w-full rounded-[1rem] object-contain" />
                  </motion.div>
                </motion.div>
              ) : null}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

              <motion.footer initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="mt-6 rounded-[2rem] border border-[var(--theme-border)] bg-[var(--theme-surface)] p-6 text-center shadow-[0_24px_60px_rgba(15,23,42,0.09)]">
                <div className="mx-auto flex max-w-3xl flex-col gap-5 rounded-[1.75rem] border border-[var(--theme-border)] bg-[var(--theme-background)]/80 p-6 shadow-sm">
                  <div className="space-y-3">
                    <p className="text-lg font-semibold tracking-[0.02em]" style={{ color: 'var(--theme-primary)' }}>شكرًا لوجودكم في هذه اللحظة الخاصة</p>
                    <p className="mx-auto max-w-2xl text-sm leading-7" style={{ color: 'var(--theme-muted)' }}>تُقدَّم لكم هذه الدعوة بعناية لتكون ذكرى جميلة تجمع الأحباب في أجواء من الفخامة والدفء.</p>
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-3">
                    <button onClick={() => { navigator.clipboard.writeText(typeof window !== 'undefined' ? window.location.href : ''); }} className="rounded-full px-6 py-3 text-sm font-semibold text-white shadow-lg transition" style={getButtonStyle(theme)}>نسخ الرابط</button>
                    <a className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-white shadow-lg transition" style={getButtonStyle(theme)} href={`https://wa.me/?text=${encodeURIComponent(typeof window !== 'undefined' ? window.location.href : '')}`} target="_blank" rel="noreferrer">مشاركة واتساب <ChevronRight className="h-4 w-4" /></a>
                  </div>
                </div>

                {contactEnabled ? (
                  <div className="mx-auto mt-6 max-w-3xl rounded-[1.75rem] border border-[var(--theme-border)] bg-[var(--theme-background)]/70 p-5 text-right shadow-sm">
                    <p className="text-sm uppercase tracking-[0.28em]" style={{ color: 'var(--theme-secondary)' }}>هل تريد نفس التصميم؟</p>
                    <p className="mt-2 text-sm" style={{ color: 'var(--theme-muted)' }}>اتصل بـ {contactName} عبر الواتساب للحجز.</p>
                    <div className="mt-4 flex flex-wrap justify-center gap-3">
                      <a href={`${contactWhatsapp}?text=${encodeURIComponent("Hi, I saw your invitation and I'd like one like this")}`} className="rounded-full px-5 py-2 text-sm font-semibold text-white shadow-sm transition" style={getButtonStyle(theme)}>💬 تواصل</a>
                      <a href={`tel:${contactPhone}`} className="rounded-full border border-[var(--theme-border)] bg-[var(--theme-surface)] px-5 py-2 text-sm shadow-sm transition" style={{ color: 'var(--theme-muted)' }}>📞 اتصل الآن</a>
                    </div>
                  </div>
                ) : null}
              </motion.footer>

      <div className="pointer-events-none fixed bottom-4 left-4 z-20 rounded-full border border-[var(--theme-border)] bg-[var(--theme-surface)]/90 px-4 py-2 text-sm shadow-lg backdrop-blur" style={{ color: 'var(--theme-muted)' }}>
        {loading ? 'جارٍ التحضير...' : 'استمتع بالدعوة'}
      </div>

      {visibleSections.music && data?.mp3_url ? (
        <button
          type="button"
          onClick={() => setIsPlaying((prev) => !prev)}
          className={`fixed right-4 bottom-24 z-30 flex h-14 w-14 items-center justify-center overflow-hidden rounded-full border transition-all duration-200 ${isPlaying ? 'border-[var(--theme-border)] bg-[var(--theme-surface)] text-[var(--theme-primary)] shadow-[0_16px_40px_rgba(15,23,42,0.12)]' : 'border-[var(--theme-border)] bg-[var(--theme-surface)] text-[var(--theme-primary)] shadow-[0_14px_30px_rgba(15,23,42,0.12)] hover:shadow-[0_16px_40px_rgba(15,23,42,0.16)]'}`}
          aria-label={isPlaying ? 'إيقاف الموسيقى' : 'تشغيل الموسيقى'}
        >
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/20 via-transparent to-white/8" />
          <span className={`audio-pulse ${isPlaying ? 'active' : ''}`} />
          <div className="relative flex h-full w-full items-center justify-center">
            {isPlaying ? (
              <div className="audio-eq playing text-slate-900">
                <span />
                <span />
                <span />
              </div>
            ) : (
              <Music2 className="h-7 w-7 text-slate-900" />
            )}
          </div>
        </button>
      ) : null}

      {data?.mp3_url ? (
        <audio ref={audioRef} src={data.mp3_url} loop />
      ) : null}
    </main>
  );
}
