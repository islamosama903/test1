'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { BarChart3, Copy, Pencil, QrCode, Search, ShieldCheck, Trash2, Users2 } from 'lucide-react';

type WeddingItem = {
  id?: string;
  slug?: string;
  groom_name?: string;
  bride_name?: string;
  venue_name?: string;
  address?: string;
  google_maps_url?: string;
  wedding_date?: string;
  wedding_time?: string;
  story?: string;
  is_active?: boolean;
  is_published?: boolean;
  created_at?: string;
};

export default function AdminDashboardPage() {
  const router = useRouter();
  const [copied, setCopied] = useState('');
  const [mounted, setMounted] = useState(false);
  const [weddings, setWeddings] = useState<WeddingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editingWedding, setEditingWedding] = useState<WeddingItem | null>(null);
  const [saving, setSaving] = useState(false);
  const [deletingSlug, setDeletingSlug] = useState<string | null>(null);
  const [settings, setSettings] = useState({ enabled: true, name: 'Islam Osama', phone: '01050759399', whatsapp: 'https://wa.me/201050759399' });
  const [savingSettings, setSavingSettings] = useState(false);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
    router.push('/login');
  };

  useEffect(() => {
    setMounted(true);
    const load = async () => {
      try {
        const res = await fetch('/api/settings', { credentials: 'same-origin' });
        if (res.ok) {
          const data = await res.json();
          setSettings({
            enabled: data?.enabled ?? true,
            name: data?.name || 'Islam Osama',
            phone: data?.phone || '01050759399',
            whatsapp: data?.whatsapp || 'https://wa.me/201050759399'
          });
        }
      } catch (err) {}

      try {
        const res = await fetch('/api/weddings', { credentials: 'same-origin' });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || 'تعذر تحميل الدعوات');
        setWeddings(Array.isArray(data) ? data : []);
      } catch (err: any) {
        setError(err?.message || 'تعذر تحميل الدعوات');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const cards = [
    { label: 'عدد الدعوات', value: weddings.length.toString() },
    { label: 'دعوات نشطة', value: weddings.filter((w) => w.is_active).length.toString() },
    { label: 'دعوات منشورة', value: weddings.filter((w) => w.is_published).length.toString() }
  ];

  const copyText = async (text: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(text);
    setTimeout(() => setCopied(''), 1500);
  };

  const handleDelete = async (slug?: string) => {
    if (!slug) return;
    const confirmed = window.confirm('هل تريد حذف هذه الدعوة فعلاً؟');
    if (!confirmed) return;

    setDeletingSlug(slug);
    try {
      const res = await fetch(`/api/weddings/${encodeURIComponent(slug)}`, { method: 'DELETE', credentials: 'same-origin' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || 'تعذر حذف الدعوة');
      setWeddings((prev) => prev.filter((item) => (item.slug || item.id) !== slug));
    } catch (err: any) {
      setError(err?.message || 'تعذر حذف الدعوة');
    } finally {
      setDeletingSlug(null);
    }
  };

  const handleSaveSettings = async () => {
    setSavingSettings(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(settings)
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || 'تعذر حفظ الإعدادات');
      setSettings({
        enabled: data?.enabled ?? true,
        name: data?.name || 'Islam Osama',
        phone: data?.phone || '01050759399',
        whatsapp: data?.whatsapp || 'https://wa.me/201050759399'
      });
      setError('');
    } catch (err: any) {
      setError(err?.message || 'تعذر حفظ الإعدادات');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleSaveEdit = async () => {
    if (!editingWedding?.slug) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/weddings/${encodeURIComponent(editingWedding.slug)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          groom_name: editingWedding.groom_name,
          bride_name: editingWedding.bride_name,
          venue_name: editingWedding.venue_name,
          address: editingWedding.address,
          google_maps_url: editingWedding.google_maps_url,
          wedding_date: editingWedding.wedding_date,
          wedding_time: editingWedding.wedding_time,
          story: editingWedding.story,
          is_active: editingWedding.is_active,
          is_published: editingWedding.is_published
        })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || 'تعذر حفظ التعديلات');
      setWeddings((prev) => prev.map((item) => (item.slug === editingWedding.slug ? { ...item, ...data } : item)));
      setEditingWedding(null);
    } catch (err: any) {
      setError(err?.message || 'تعذر حفظ التعديلات');
    } finally {
      setSaving(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 p-6 text-white">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-white/10 bg-white/10 p-6 backdrop-blur">
          <div>
            <p className="text-sm text-pink-300">لوحة التحكم</p>
            <h1 className="text-3xl font-semibold">مرحباً بك في إدارة الدعوات</h1>
          </div>
          <div className="flex gap-3">
            <Link href="/admin/create" className="rounded-full bg-pink-500 px-4 py-2 font-semibold transition hover:bg-pink-600">إنشاء دعوة جديدة</Link>
            <button type="button" onClick={handleLogout} className="rounded-full border border-white/20 bg-slate-900/70 px-4 py-2 font-semibold transition hover:bg-slate-800">تسجيل خروج</button>
            <Link href="/" className="rounded-full border border-white/20 px-4 py-2 transition hover:bg-white/10">العودة للرئيسية</Link>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          {cards.map((card) => (
            <div key={card.label} className="rounded-3xl border border-white/10 bg-slate-900/70 p-5">
              <div className="flex items-center justify-between">
                <p className="text-sm text-slate-400">{card.label}</p>
                <BarChart3 className="h-5 w-5 text-pink-400" />
              </div>
              <p className="mt-3 text-3xl font-bold">{card.value}</p>
            </div>
          ))}
        </div>

        <div className="rounded-3xl border border-white/10 bg-slate-900/70 p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-semibold">إعدادات التوقيع</h2>
              <p className="text-sm text-slate-400">تحكم في ظهور القسم الرفيع في جميع دعوات الموقع</p>
            </div>
            <button onClick={handleSaveSettings} disabled={savingSettings} className="rounded-full bg-pink-500 px-4 py-2 font-semibold disabled:opacity-60">{savingSettings ? 'جارٍ الحفظ...' : 'حفظ الإعدادات'}</button>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <label className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3">
              <span>إظهار القسم في جميع الدعوات</span>
              <input type="checkbox" checked={!!settings.enabled} onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })} />
            </label>
            <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="اسم الناشر" value={settings.name} onChange={(e) => setSettings({ ...settings, name: e.target.value })} />
            <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="رقم الهاتف" value={settings.phone} onChange={(e) => setSettings({ ...settings, phone: e.target.value })} />
            <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="رابط واتساب" value={settings.whatsapp} onChange={(e) => setSettings({ ...settings, whatsapp: e.target.value })} />
          </div>
        </div>

        <div className="rounded-3xl border border-white/10 bg-slate-900/70 p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-semibold">إدارة الدعوات</h2>
              <p className="text-sm text-slate-400">أدر الروابط والصفحات مباشرة من هنا</p>
            </div>
            <div className="flex items-center gap-2 rounded-full border border-white/10 bg-slate-950 px-4 py-2">
              <Search className="h-4 w-4 text-slate-400" />
              <input className="bg-transparent outline-none" placeholder="ابحث عن عريس أو عروسة" />
            </div>
          </div>

          {loading ? (
            <p className="mt-6 text-sm text-slate-400">جارٍ تحميل الدعوات...</p>
          ) : error ? (
            <p className="mt-6 text-sm text-pink-200">{error}</p>
          ) : (
            <div className="mt-6 space-y-4">
              {weddings.map((item) => {
                const title = [item.groom_name, item.bride_name].filter(Boolean).join(' & ') || 'دعوة جديدة';
                const slug = item.slug || 'demo';
                const inviteLink = mounted ? `${window.location.origin}/wedding/${slug}` : `/wedding/${slug}`;
                const coupleLink = mounted ? `${window.location.origin}/couple/${slug}` : `/couple/${slug}`;
                return (
                  <div key={item.id || slug} className="flex flex-wrap items-center justify-between rounded-2xl border border-white/10 bg-slate-950/70 p-4">
                    <div className="flex items-center gap-3">
                      <div className="rounded-full bg-pink-500/20 p-3 text-pink-300">
                        <Users2 className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-semibold">{title}</p>
                        <p className="text-sm text-slate-400">{item.venue_name || 'بدون عنوان'} • {item.wedding_date || 'قريباً'}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button onClick={() => copyText(inviteLink)} className="rounded-full border border-white/10 px-3 py-2 text-sm transition hover:bg-white/10"><Copy className="ml-1 inline h-4 w-4" />{copied === inviteLink ? 'تم النسخ' : 'نسخ الرابط'}</button>
                      <button onClick={() => copyText(coupleLink)} className="rounded-full border border-white/10 px-3 py-2 text-sm transition hover:bg-white/10"><QrCode className="ml-1 inline h-4 w-4" />لوحة العروسين</button>
                      <button onClick={() => setEditingWedding(item)} className="rounded-full border border-white/10 px-3 py-2 text-sm transition hover:bg-white/10"><Pencil className="ml-1 inline h-4 w-4" />تعديل</button>
                      <button onClick={() => handleDelete(slug)} className="rounded-full border border-red-400/30 px-3 py-2 text-sm text-red-200 transition hover:bg-red-500/10" disabled={deletingSlug === slug}><Trash2 className="ml-1 inline h-4 w-4" />{deletingSlug === slug ? 'جارٍ الحذف...' : 'حذف'}</button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {editingWedding ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4">
          <div className="w-full max-w-2xl rounded-3xl border border-white/10 bg-slate-900 p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold">تعديل الدعوة</h3>
              <button onClick={() => setEditingWedding(null)} className="rounded-full border border-white/10 px-3 py-2 text-sm">إغلاق</button>
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="اسم العريس" value={editingWedding.groom_name || ''} onChange={(e) => setEditingWedding({ ...editingWedding, groom_name: e.target.value })} />
              <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="اسم العروسة" value={editingWedding.bride_name || ''} onChange={(e) => setEditingWedding({ ...editingWedding, bride_name: e.target.value })} />
              <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="اسم القاعة" value={editingWedding.venue_name || ''} onChange={(e) => setEditingWedding({ ...editingWedding, venue_name: e.target.value })} />
              <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="العنوان" value={editingWedding.address || ''} onChange={(e) => setEditingWedding({ ...editingWedding, address: e.target.value })} />
              <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="رابط Google Maps" value={editingWedding.google_maps_url || ''} onChange={(e) => setEditingWedding({ ...editingWedding, google_maps_url: e.target.value })} />
              <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="التاريخ" value={editingWedding.wedding_date || ''} onChange={(e) => setEditingWedding({ ...editingWedding, wedding_date: e.target.value })} />
              <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="الوقت" value={editingWedding.wedding_time || ''} onChange={(e) => setEditingWedding({ ...editingWedding, wedding_time: e.target.value })} />
              <label className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-950 px-4 py-3">
                <span>نشطة</span>
                <input type="checkbox" checked={!!editingWedding.is_active} onChange={(e) => setEditingWedding({ ...editingWedding, is_active: e.target.checked })} />
              </label>
              <label className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-950 px-4 py-3">
                <span>منشورة</span>
                <input type="checkbox" checked={!!editingWedding.is_published} onChange={(e) => setEditingWedding({ ...editingWedding, is_published: e.target.checked })} />
              </label>
            </div>

            <textarea className="mt-4 w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" rows={4} placeholder="قصة الحب" value={editingWedding.story || ''} onChange={(e) => setEditingWedding({ ...editingWedding, story: e.target.value })} />

            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setEditingWedding(null)} className="rounded-full border border-white/10 px-4 py-2">إلغاء</button>
              <button onClick={handleSaveEdit} disabled={saving} className="rounded-full bg-pink-500 px-4 py-2 font-semibold disabled:opacity-60">{saving ? 'جارٍ الحفظ...' : 'حفظ التعديلات'}</button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}
