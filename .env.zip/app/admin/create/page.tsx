'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { Camera, Music2, Palette, Sparkles, Users2, PlayCircle } from 'lucide-react';
import AudioPlayer from '@/components/AudioPlayer';
import { getDefaultVisibleSections, weddingSectionConfig } from '@/lib/wedding-utils';
import { getThemePresetById, getThemePresetOptions } from '@/lib/wedding-theme';
import { MAX_AUDIO_DURATION_SECONDS, validateAudioDuration } from '@/lib/audio-utils';

const readFileAsDataUrl = (file: File, onProgress?: (percent: number) => void) => new Promise<string>((resolve, reject) => {
  const reader = new FileReader();
  reader.onprogress = (event) => {
    if (event.lengthComputable && onProgress) {
      onProgress(Math.round((event.loaded / event.total) * 100));
    }
  };
  reader.onload = () => {
    if (typeof reader.result === 'string') resolve(reader.result);
    else reject(new Error('تعذر قراءة الملف'));
  };
  reader.onerror = () => reject(new Error('تعذر قراءة الملف'));
  reader.readAsDataURL(file);
});

export default function CreateWeddingPage() {
  const [form, setForm] = useState({
    groom_name: '',
    bride_name: '',
    venue_name: '',
    address: '',
    google_maps_url: '',
    wedding_date: '',
    wedding_time: '',
    slug: ''
  });
  const [message, setMessage] = useState('');
  const [mounted, setMounted] = useState(false);

  const [visibleSections, setVisibleSections] = useState<Record<string, boolean>>(getDefaultVisibleSections());
  const [groomImage, setGroomImage] = useState<File | null>(null);
  const [brideImage, setBrideImage] = useState<File | null>(null);
  const [coverImage, setCoverImage] = useState<File | null>(null);
  const [musicFile, setMusicFile] = useState<File | null>(null);
  const [groomPreview, setGroomPreview] = useState<string | null>(null);
  const [bridePreview, setBridePreview] = useState<string | null>(null);
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [musicPreview, setMusicPreview] = useState<string | null>(null);
  const [coupleAudioPreview, setCoupleAudioPreview] = useState<string | null>(null);
  const [coupleRecording, setCoupleRecording] = useState(false);
  const [coupleRecordingDuration, setCoupleRecordingDuration] = useState(0);
  const [coupleRecordedAudioUrl, setCoupleRecordedAudioUrl] = useState<string | null>(null);
  const [coupleRecordedAudioBlob, setCoupleRecordedAudioBlob] = useState<Blob | null>(null);
  const [coupleRecordingError, setCoupleRecordingError] = useState('');
  const [musicUploading, setMusicUploading] = useState(false);
  const [musicUploadProgress, setMusicUploadProgress] = useState(0);
  const [musicUploadMessage, setMusicUploadMessage] = useState('');
  const [musicUploadUrl, setMusicUploadUrl] = useState<string | null>(null);
  const [musicFileError, setMusicFileError] = useState('');
  const [musicDurationSeconds, setMusicDurationSeconds] = useState<number | null>(null);
  const [groomAccount, setGroomAccount] = useState({ username: '', password: '' });
  const [brideAccount, setBrideAccount] = useState({ username: '', password: '' });
  const [guestMessage, setGuestMessage] = useState('');
  const [selectedThemeId, setSelectedThemeId] = useState('royal-emerald-garden');
  const coupleMediaRecorderRef = useRef<MediaRecorder | null>(null);
  const coupleMediaStreamRef = useRef<MediaStream | null>(null);
  const coupleRecordedChunksRef = useRef<Blob[]>([]);
  const coupleRecordingTimerRef = useRef<number | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleImagePick = async (file: File | null, target: 'groom' | 'bride' | 'cover') => {
    if (!file) {
      if (target === 'groom') setGroomImage(null);
      if (target === 'bride') setBrideImage(null);
      if (target === 'cover') setCoverImage(null);
      return;
    }

    try {
      const preview = await readFileAsDataUrl(file);
      if (target === 'groom') {
        setGroomImage(file);
        setGroomPreview(preview);
      }
      if (target === 'bride') {
        setBrideImage(file);
        setBridePreview(preview);
      }
      if (target === 'cover') {
        setCoverImage(file);
        setCoverPreview(preview);
      }
    } catch (e) {
      setMessage('تعذر قراءة الصورة، حاول مرة أخرى');
    }
  };

  const handleMusicPick = async (file: File | null) => {
    if (!file) {
      setMusicFile(null);
      setMusicPreview(null);
      setMusicDurationSeconds(null);
      setMusicUploadUrl(null);
      setMusicUploadMessage('');
      setMusicFileError('');
      setMusicUploading(false);
      setMusicUploadProgress(0);
      return;
    }

    setMusicFile(file);
    setMusicFileError('');
    setMusicUploadUrl(null);
    setMusicUploadMessage('');
    setMusicUploading(true);
    setMusicUploadProgress(0);

    try {
      const duration = await new Promise<number>((resolve, reject) => {
        const audioUrl = URL.createObjectURL(file);
        const audio = new Audio(audioUrl);
        audio.preload = 'metadata';
        audio.onloadedmetadata = () => {
          resolve(Math.floor(audio.duration || 0));
          URL.revokeObjectURL(audioUrl);
        };
        audio.onerror = () => {
          URL.revokeObjectURL(audioUrl);
          reject(new Error('تعذر قراءة مدة الملف الصوتي'));
        };
      });

      const durationError = validateAudioDuration(duration);
      if (durationError) {
        setMusicFile(null);
        setMusicPreview(null);
        setMusicDurationSeconds(null);
        setMusicFileError(durationError);
        return;
      }

      setMusicDurationSeconds(duration);
      const preview = await readFileAsDataUrl(file, setMusicUploadProgress);
      setMusicPreview(preview);
    } catch (e) {
      setMusicFile(null);
      setMusicPreview(null);
      setMusicDurationSeconds(null);
      setMessage('تعذر قراءة الملف الصوتي، حاول مرة أخرى');
    } finally {
      setMusicUploading(false);
      setMusicUploadProgress(0);
    }
  };

  const uploadMusicFile = async () => {
    if (!musicFile) {
      setMusicUploadMessage('اختر ملف صوتي أولًا');
      return null;
    }

    const generatedSlug = (form.slug || `${form.groom_name || 'wedding'}-${form.bride_name || 'invite'}`.toLowerCase().replace(/\s+/g, '-')).trim();
    const slug = generatedSlug || 'wedding-invite';

    setMusicUploading(true);
    setMusicUploadProgress(0);
    setMusicUploadMessage('');

    return await new Promise<string | null>((resolve) => {
      const formData = new FormData();
      formData.append('slug', slug);
      formData.append('file', musicFile);

      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/uploads/music');
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded / event.total) * 100);
          setMusicUploadProgress(percent);
        }
      };
      xhr.onload = () => {
        try {
          const body = xhr.responseText ? JSON.parse(xhr.responseText) : null;
          if (xhr.status >= 200 && xhr.status < 300 && body?.url) {
            setMusicUploadUrl(body.url);
            setMusicUploadMessage('تم رفع الأغنية بنجاح');
            setMusicUploadProgress(100);
            resolve(body.url);
            return;
          }
          setMusicUploadMessage(body?.error || 'فشل رفع الأغنية');
          resolve(null);
        } catch (e) {
          setMusicUploadMessage('فشل رفع الأغنية');
          resolve(null);
        } finally {
          setMusicUploading(false);
        }
      };
      xhr.onerror = () => {
        setMusicUploadMessage('تعذر الاتصال بالرفع');
        resolve(null);
        setMusicUploading(false);
      };
      xhr.send(formData);
    });
  };

  const getSupportedAudioMimeType = () => {
    if (typeof MediaRecorder === 'undefined') return '';
    if (MediaRecorder.isTypeSupported?.('audio/webm;codecs=opus')) return 'audio/webm;codecs=opus';
    if (MediaRecorder.isTypeSupported?.('audio/webm')) return 'audio/webm';
    if (MediaRecorder.isTypeSupported?.('audio/ogg;codecs=opus')) return 'audio/ogg;codecs=opus';
    if (MediaRecorder.isTypeSupported?.('audio/ogg')) return 'audio/ogg';
    return '';
  };

  const readBlobAsDataUrl = (blob: Blob) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('تعذر قراءة البيانات'));
    };
    reader.onerror = () => reject(new Error('تعذر قراءة البيانات'));
    reader.readAsDataURL(blob);
  });

  const startCoupleRecording = async () => {
    if (coupleRecording) return;
    setCoupleRecordingError('');
    if (!navigator.mediaDevices?.getUserMedia) {
      setCoupleRecordingError('الميكروفون غير مدعوم في هذا المتصفح.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      coupleMediaStreamRef.current = stream;
      coupleRecordedChunksRef.current = [];
      const mimeType = getSupportedAudioMimeType();
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      coupleMediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          coupleRecordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        const totalSize = coupleRecordedChunksRef.current.reduce((sum, chunk) => sum + chunk.size, 0);
        if (totalSize === 0) {
          setCoupleRecordingError('لم يتم تسجيل صوت. حاول مرة أخرى.');
          setCoupleRecordedAudioBlob(null);
          setCoupleRecordedAudioUrl(null);
        } else {
          const blob = new Blob(coupleRecordedChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
          setCoupleRecordedAudioBlob(blob);
          setCoupleRecordedAudioUrl(URL.createObjectURL(blob));
          setCoupleAudioPreview(URL.createObjectURL(blob));
        }

        if (coupleMediaStreamRef.current) {
          coupleMediaStreamRef.current.getTracks().forEach((track) => track.stop());
          coupleMediaStreamRef.current = null;
        }
      };

      if (coupleRecordedAudioUrl) {
        URL.revokeObjectURL(coupleRecordedAudioUrl);
      }

      recorder.start();
      setCoupleRecording(true);
      setCoupleRecordingDuration(0);
      setCoupleRecordedAudioUrl(null);
      setCoupleRecordedAudioBlob(null);
      if (coupleRecordingTimerRef.current) {
        window.clearInterval(coupleRecordingTimerRef.current);
      }
      coupleRecordingTimerRef.current = window.setInterval(() => {
        setCoupleRecordingDuration((duration) => duration + 1);
      }, 1000);
    } catch (error: any) {
      setCoupleRecordingError(error?.message || 'فشل بدء التسجيل.');
    }
  };

  const stopCoupleRecording = () => {
    if (!coupleMediaRecorderRef.current) return;
    const recorder = coupleMediaRecorderRef.current;
    setCoupleRecording(false);
    if (coupleRecordingTimerRef.current) {
      window.clearInterval(coupleRecordingTimerRef.current);
      coupleRecordingTimerRef.current = null;
    }
    try {
      recorder.stop();
      coupleMediaRecorderRef.current = null;
    } catch (error) {
      setCoupleRecordingError('فشل إيقاف التسجيل.');
    }
  };

  const availableThemes = useMemo(() => getThemePresetOptions(), []);
  const selectedTheme = useMemo(() => getThemePresetById(selectedThemeId), [selectedThemeId]);

  const generatedLink = useMemo(() => {
    const slug = form.slug || `${form.groom_name || 'wedding'}-${form.bride_name || 'invite'}`.toLowerCase().replace(/\s+/g, '-');
    if (!mounted) return `/wedding/${slug}`;
    return `${window.location.origin}/wedding/${slug}`;
  }, [form.bride_name, form.groom_name, form.slug, mounted]);

  const handleCreate = async () => {
    if (!form.groom_name || !form.bride_name) {
      setMessage('يرجى إدخال اسم العريس والعروسة أولًا');
      return;
    }

    const uploadFile = async (file: File, type: 'image' | 'video' | 'music'): Promise<string | null> => {
      if (!file) return null;
      const formData = new FormData();
      formData.append('slug', form.slug || `${form.groom_name}-${form.bride_name}`.toLowerCase().replace(/\s+/g, '-') || 'wedding');
      formData.append('file', file);
      const response = await fetch(`/api/uploads/${type}`, {
        method: 'POST',
        body: formData,
      });
      const body = await response.json().catch(() => null);
      if (!response.ok) {
        throw new Error(body?.error || `Failed to upload ${type}`);
      }
      return body?.url ?? null;
    };

    const safeSlug = form.slug || `${form.groom_name}-${form.bride_name}`.toLowerCase().replace(/\s+/g, '-') || 'wedding';
    const groom_image_url = groomImage ? await uploadFile(groomImage, 'image') : null;
    const bride_image_url = brideImage ? await uploadFile(brideImage, 'image') : null;
    const cover_image_url = coverImage ? await uploadFile(coverImage, 'image') : null;
    const guest_message_audio = coupleRecordedAudioBlob ? await uploadFile(new File([coupleRecordedAudioBlob], `guest-message.${coupleRecordedAudioBlob.type.split('/').pop() || 'webm'}`, { type: coupleRecordedAudioBlob.type || 'audio/webm' }), 'music') : null;

    const payload: any = {
      slug: safeSlug,
      groom_name: form.groom_name,
      bride_name: form.bride_name,
      venue_name: form.venue_name,
      address: form.address,
      google_maps_url: form.google_maps_url,
      wedding_date: form.wedding_date,
      wedding_time: form.wedding_time,
      groom_image_url,
      bride_image_url,
      cover_image_url,
      guest_message: guestMessage,
      guest_message_audio,
      visible_sections: visibleSections,
      theme: selectedThemeId,
      groom_account: groomAccount,
      bride_account: brideAccount,
    };

    try {
      if (musicFile) {
        if (!musicUploadUrl) {
          setMessage('يرجى رفع الأغنية أولًا ثم إنشاء الدعوة.');
          return;
        }
        payload.mp3_url = musicUploadUrl;
      }

      const response = await fetch('/api/weddings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const body = await response.json().catch(() => null);
      if (response.ok) {
        const accountsText = body?.couple_accounts?.length
          ? `\nبيانات الدخول: ${body.couple_accounts.map((item: any) => `${item.username} / ${item.password}`).join(' | ')}`
          : '';
        setMessage(`تم إنشاء الدعوة بنجاح. الرابط: ${generatedLink}${accountsText}`);
        if (typeof window !== 'undefined') {
          window.open(generatedLink, '_blank');
        }
        return;
      }

      if (body && body.error) setMessage(`خطأ من الخادم: ${body.error}`);
      else setMessage('فشل إنشاء الدعوة على الخادم. يرجى المحاولة مرة أخرى.');
    } catch (err: any) {
      setMessage(`فشل الاتصال بالخادم: ${err?.message ?? String(err)}`);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 p-6 text-white">
      <div className="mx-auto max-w-6xl space-y-8">
        <div className="rounded-3xl border border-white/10 bg-white/10 p-8 backdrop-blur">
          <h1 className="text-3xl font-semibold">إنشاء دعوة جديدة</h1>
          <p className="mt-2 text-slate-300">صفحة موحدة تجمع كافة البيانات والخيارات في مكان واحد.</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <section className="space-y-6 rounded-3xl border border-white/10 bg-slate-900/70 p-6">
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">بيانات العروسين</h2>
              <div className="grid gap-4 md:grid-cols-2">
                <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="اسم العريس" value={form.groom_name} onChange={(e) => setForm({ ...form, groom_name: e.target.value })} />
                <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="اسم العروسة" value={form.bride_name} onChange={(e) => setForm({ ...form, bride_name: e.target.value })} />
                <label className="flex items-center gap-3 rounded-2xl border border-dashed border-white/20 bg-slate-950/60 px-4 py-3 cursor-pointer">
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImagePick(e.target.files?.[0] ?? null, 'groom')} />
                  {groomPreview ? (
                    <img src={groomPreview} alt="groom" className="h-12 w-12 rounded-full object-cover" />
                  ) : (
                    <Camera className="h-5 w-5 text-pink-400" />
                  )}
                  <span>صورة العريس</span>
                </label>

                <label className="flex items-center gap-3 rounded-2xl border border-dashed border-white/20 bg-slate-950/60 px-4 py-3 cursor-pointer">
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImagePick(e.target.files?.[0] ?? null, 'bride')} />
                  {bridePreview ? (
                    <img src={bridePreview} alt="bride" className="h-12 w-12 rounded-full object-cover" />
                  ) : (
                    <Camera className="h-5 w-5 text-pink-400" />
                  )}
                  <span>صورة العروسة</span>
                </label>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-semibold">بيانات المناسبة</h2>
              <div className="grid gap-4 md:grid-cols-2">
                <input type="date" className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" value={form.wedding_date} onChange={(e) => setForm({ ...form, wedding_date: e.target.value })} />
                <input type="time" className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" value={form.wedding_time} onChange={(e) => setForm({ ...form, wedding_time: e.target.value })} />
                <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="اسم القاعة" value={form.venue_name} onChange={(e) => setForm({ ...form, venue_name: e.target.value })} />
                <input className="rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="العنوان" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              </div>
              <input className="w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="رابط Google Maps" value={form.google_maps_url} onChange={(e) => setForm({ ...form, google_maps_url: e.target.value })} />
              <input className="w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="اسم الرابط (اختياري)" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-semibold">تصميم الموقع</h2>
              <div className="grid gap-3 md:grid-cols-2">
                {availableThemes.map((themeOption) => {
                  const active = selectedThemeId === themeOption.id;
                  return (
                    <button key={themeOption.id} type="button" onClick={() => setSelectedThemeId(themeOption.id)} className={`rounded-2xl border p-3 text-right transition ${active ? 'border-emerald-400 bg-slate-950/95' : 'border-white/10 bg-slate-950/70'}`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-semibold text-white">{themeOption.name}</p>
                          <p className="mt-1 text-xs text-slate-400">{themeOption.description}</p>
                        </div>
                        <div className="flex gap-1">
                          <span className="h-3 w-3 rounded-full" style={{ backgroundColor: themeOption.colors.primary }} />
                          <span className="h-3 w-3 rounded-full" style={{ backgroundColor: themeOption.colors.accent }} />
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
              <div className="rounded-2xl border border-white/10 bg-slate-950/70 p-4" style={{ borderColor: selectedTheme.colors.border }}>
                <p className="text-sm font-semibold" style={{ color: selectedTheme.colors.primary }}>{selectedTheme.name}</p>
                <p className="mt-1 text-sm text-slate-300">الألوان الأساسية: {selectedTheme.colors.primary} و {selectedTheme.colors.accent}</p>
              </div>
            </div>
          </section>

          <section className="space-y-6 rounded-3xl border border-white/10 bg-slate-900/70 p-6">
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">حسابات العريس والعروسة</h2>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-slate-950/70 p-4">
                  <p className="mb-2 font-semibold text-pink-300">حساب العريس</p>
                  <input className="mb-2 w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="username" value={groomAccount.username} onChange={(e) => setGroomAccount({ ...groomAccount, username: e.target.value })} />
                  <input type="password" className="w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="كلمة المرور" value={groomAccount.password} onChange={(e) => setGroomAccount({ ...groomAccount, password: e.target.value })} />
                </div>
                <div className="rounded-2xl border border-white/10 bg-slate-950/70 p-4">
                  <p className="mb-2 font-semibold text-pink-300">حساب العروسة</p>
                  <input className="mb-2 w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="username" value={brideAccount.username} onChange={(e) => setBrideAccount({ ...brideAccount, username: e.target.value })} />
                  <input type="password" className="w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" placeholder="كلمة المرور" value={brideAccount.password} onChange={(e) => setBrideAccount({ ...brideAccount, password: e.target.value })} />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-semibold">رسالة للضيوف</h2>
              <textarea value={guestMessage} onChange={(e) => setGuestMessage(e.target.value)} placeholder="اكتب رسالة أو تحية للضيوف" className="min-h-[120px] w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 outline-none" />
              <div className="rounded-3xl border border-white/10 bg-slate-950/70 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm uppercase tracking-[0.2em] text-pink-300">رسالة صوتية العروسين</p>
                    <p className="mt-1 text-sm text-slate-300">سجّل تحية مباشرة من العريس والعروسة.</p>
                  </div>
                  <button
                    type="button"
                    onClick={coupleRecording ? stopCoupleRecording : startCoupleRecording}
                    className="rounded-full bg-gradient-to-r from-pink-500 to-rose-500 px-5 py-3 text-sm font-semibold text-white shadow-xl shadow-pink-500/25 transition duration-200 hover:-translate-y-0.5 active:scale-[0.98]"
                  >
                    {coupleRecording ? 'إيقاف التسجيل' : 'بدء التسجيل'}
                  </button>
                </div>
                {coupleRecording ? <p className="mt-3 text-sm text-amber-200">جاري التسجيل... المدة {Math.floor(coupleRecordingDuration / 60)}:{(coupleRecordingDuration % 60).toString().padStart(2, '0')}</p> : null}
                {coupleRecordingError ? <p className="mt-3 text-sm text-amber-300">{coupleRecordingError}</p> : null}
                {coupleRecordedAudioUrl ? (
                  <div className="mt-4 rounded-[1.5rem] border border-white/10 bg-slate-900/80 p-3">
                    <AudioPlayer src={coupleRecordedAudioUrl} label="معاينة تسجيل العروسين" subtitle="استمع للتحية قبل حفظها" />
                  </div>
                ) : null}
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-semibold">إعدادات إضافية</h2>
              <label className="flex items-center gap-3 rounded-2xl border border-dashed border-white/20 bg-slate-950/60 px-4 py-3 cursor-pointer">
                <input type="file" accept="audio/*" className="hidden" onChange={(e) => handleMusicPick(e.target.files?.[0] ?? null)} />
                <Music2 className="h-5 w-5 text-pink-400" />
                <span>اختيار ملف MP3</span>
              </label>
              <div className="flex flex-wrap items-center gap-3">
                <button type="button" onClick={() => uploadMusicFile()} disabled={!musicFile || musicUploading} className="rounded-2xl bg-pink-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-pink-600 disabled:cursor-not-allowed disabled:opacity-60">
                  {musicUploading ? 'جارٍ الرفع...' : 'رفع الأغنية'}
                </button>
                <p className="text-xs text-slate-400">الحد الأقصى {Math.floor(MAX_AUDIO_DURATION_SECONDS / 60)} دقائق. بعد انتهاء الرفع يمكنك الضغط على “إنشاء الدعوة”.</p>
              </div>
              {musicUploading ? (
                <div className="rounded-2xl border border-pink-400/20 bg-slate-950/70 p-3">
                  <div className="mb-2 flex items-center justify-between text-sm text-slate-300">
                    <span>جارٍ رفع الأغنية...</span>
                    <span>{musicUploadProgress}%</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-slate-800">
                    <div className="h-full rounded-full bg-pink-500 transition-all" style={{ width: `${musicUploadProgress}%` }} />
                  </div>
                </div>
              ) : null}
              {musicUploadMessage ? <p className="text-sm text-pink-200">{musicUploadMessage}</p> : null}
              {musicFileError ? <p className="text-sm text-amber-300">{musicFileError}</p> : null}
              {musicFile ? <p className="text-sm text-slate-400">الملف المختار: {musicFile.name}</p> : null}
              {musicDurationSeconds !== null ? <p className="text-sm text-slate-400">المدة: {Math.floor(musicDurationSeconds / 60)}:{(musicDurationSeconds % 60).toString().padStart(2, '0')}</p> : null}
              {musicPreview ? (
                <div className="mt-3">
                  <AudioPlayer src={musicPreview} label="معاينة الأغنية" subtitle="استمع لأغنية الدعوة قبل رفعها" />
                </div>
              ) : null}

              <label className="flex items-center gap-3 rounded-2xl border border-dashed border-white/20 bg-slate-950/60 px-4 py-3 cursor-pointer">
                <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImagePick(e.target.files?.[0] ?? null, 'cover')} />
                <Palette className="h-5 w-5 text-pink-400" />
                <span>صورة الغلاف</span>
              </label>
              {coverPreview ? <img src={coverPreview} alt="cover" className="w-full mt-2 rounded-md object-cover" /> : null}
            </div>

            <div className="rounded-2xl border border-white/10 bg-slate-950/70 p-4">
              <h3 className="font-semibold">التحكم في الأقسام</h3>
              <div className="mt-4 grid gap-2">
                {weddingSectionConfig.map((section) => (
                  <label key={section.key} className="flex items-center justify-between rounded-xl border border-white/10 bg-slate-900 px-3 py-2">
                    <span>{section.label}</span>
                    <input
                      type="checkbox"
                      checked={visibleSections[section.key]}
                      onChange={(e) => setVisibleSections((prev) => ({ ...prev, [section.key]: e.target.checked }))}
                      className="h-4 w-4 rounded border-white/20 bg-pink-500"
                    />
                  </label>
                ))}
              </div>
            </div>

            <button onClick={handleCreate} className="w-full rounded-2xl bg-pink-500 px-4 py-3 font-semibold transition hover:bg-pink-600">
              إنشاء الدعوة وتوليد الحسابات
            </button>
            <div className="rounded-2xl border border-pink-400/20 bg-pink-500/10 p-4 text-sm text-pink-100">
              <p className="font-semibold">الرابط الناتج</p>
              <p className="mt-2 break-all">{generatedLink}</p>
            </div>
            {message ? <p className="text-sm text-slate-300">{message}</p> : null}
          </section>
        </div>
      </div>
    </main>
  );
}
