export interface WeddingRecord {
  id?: string;
  slug: string;
  groom_name: string;
  bride_name: string;
  cover_image_url?: string | null;
  story?: string | null;
  wedding_date?: string | null;
  wedding_time?: string | null;
  venue_name?: string | null;
  address?: string | null;
  google_maps_url?: string | null;
  guest_message_audio?: string | null;
  theme?: string | null;
  primary_color?: string | null;
  accent_color?: string | null;
  text_color?: string | null;
  background_color?: string | null;
  is_active?: boolean;
  is_published?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface RsvpRecord {
  id?: string;
  wedding_id?: string;
  guest_name: string;
  is_attending: boolean;
  guest_count: number;
  message?: string | null;
  created_at?: string;
}
