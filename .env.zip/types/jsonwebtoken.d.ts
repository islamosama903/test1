declare module 'jsonwebtoken' {
  export function sign(payload: object | string, secretOrPrivateKey: string, options?: any): string;
  export function verify(token: string, secretOrPrivateKey: string, options?: any): any;
}
