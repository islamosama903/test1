export function getPostLoginTarget(role?: string | null, weddingSlug?: string | null) {
  if (role === 'super_admin') {
    return '/admin';
  }

  if (role === 'couple' && weddingSlug) {
    return `/couple/${encodeURIComponent(weddingSlug)}`;
  }

  return '/';
}
