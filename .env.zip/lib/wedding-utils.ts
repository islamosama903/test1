export function formatArabicDate(dateString?: string | null) {
  if (!dateString) return null;
  const date = new Date(dateString);
  if (Number.isNaN(date.getTime())) return dateString;

  return new Intl.DateTimeFormat('ar-EG', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(date);
}

export function formatArabicTime(timeString?: string | null) {
  if (!timeString) return null;
  if (!/^\d{1,2}:\d{2}$/.test(timeString)) return timeString;

  const [hours, minutes] = timeString.split(':').map(Number);
  const date = new Date();
  date.setHours(hours, minutes, 0, 0);

  return new Intl.DateTimeFormat('ar-EG', {
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

function parseLocalDateTime(value?: string | null) {
  if (!value) return null;
  const trimmed = value.trim();

  const withTime = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (withTime) {
    const [, year, month, day, hours, minutes, seconds] = withTime;
    return new Date(Number(year), Number(month) - 1, Number(day), Number(hours), Number(minutes), Number(seconds || '0'), 0);
  }

  const dateOnly = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (dateOnly) {
    const [, year, month, day] = dateOnly;
    return new Date(Number(year), Number(month) - 1, Number(day), 0, 0, 0, 0);
  }

  const parsed = new Date(trimmed);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export function parseWeddingDateTime(dateString?: string | null, timeString?: string | null) {
  if (!dateString) return null;
  if (timeString) {
    const value = `${dateString}T${timeString}`;
    return parseLocalDateTime(value);
  }
  return parseLocalDateTime(dateString);
}

export function getCountdownParts(targetDateTime?: string | Date | null, now: Date = new Date()) {
  if (!targetDateTime) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true };
  }

  const target = targetDateTime instanceof Date ? targetDateTime : parseLocalDateTime(targetDateTime);
  if (!target) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true };
  }

  const diffMs = target.getTime() - now.getTime();
  const isPast = diffMs <= 0;

  const totalSeconds = Math.max(0, Math.floor(diffMs / 1000));
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return { days, hours, minutes, seconds, isPast };
}

export function hasVisibleContent(value?: string | string[] | null) {
  if (Array.isArray(value)) {
    return value.some((item: unknown) => typeof item === 'string' && item.trim().length > 0);
  }

  if (typeof value === 'string') {
    return value.trim().length > 0;
  }

  return false;
}

export function getWeddingMedia(wedding: any) {
  const rawPhotos = [
    wedding?.groom_image_url,
    wedding?.bride_image_url,
    wedding?.cover_image_url,
    ...(Array.isArray(wedding?.gallery_images) ? wedding.gallery_images : []),
  ].filter((item: unknown): item is string => typeof item === 'string' && item.trim().length > 0);

  const rawVideos = (Array.isArray(wedding?.videos) ? wedding.videos : []).filter(
    (item: unknown): item is string => typeof item === 'string' && item.trim().length > 0
  );

  return {
    photos: rawPhotos,
    videos: rawVideos,
  };
}

export const weddingSectionConfig = [
  { key: 'hero', label: 'البداية وقصة الدعوة', default: true },
  { key: 'countdown', label: 'العد التنازلي', default: true },
  { key: 'dateTime', label: 'التاريخ والوقت', default: true },
  { key: 'venue', label: 'مكان الفرح والخريطة', default: true },
  { key: 'timeline', label: 'الجدول الزمني', default: true },
  { key: 'gallery', label: 'معرض الصور', default: true },
  { key: 'video', label: 'الفيديو', default: true },
  { key: 'music', label: 'الأغنية والموسيقى', default: true },
  { key: 'rsvp', label: 'نموذج تأكيد الحضور', default: true },
  { key: 'messages', label: 'رسائل الزوار', default: true },
];

export function getDefaultVisibleSections() {
  return weddingSectionConfig.reduce((acc, section) => {
    acc[section.key] = section.default;
    return acc;
  }, {} as Record<string, boolean>);
}

export function getVisibleSections(wedding: any) {
  return { ...getDefaultVisibleSections(), ...(wedding?.visible_sections ?? {}) };
}
