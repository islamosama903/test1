import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import * as jwt from 'jsonwebtoken';
import * as bcryptjs from 'bcryptjs';
import { supabaseAdmin } from './supabase-admin';
import { uploadBuffer, uploadDataUrl, isStorageConfigured, StorageNotConfiguredError } from './storage-service';

const AUTH_LOOKUP_TIMEOUT_MS = 1500;
const isVercelRuntime = Boolean(process.env.VERCEL || process.env.NEXT_PUBLIC_VERCEL_ENV || process.env.NODE_ENV === 'production');
const MEMORY_STORE = new Map<string, unknown>();
const LOCAL_DATA_DIR = process.env.WEDDING_DATA_DIR ? path.resolve(process.env.WEDDING_DATA_DIR) : (isVercelRuntime ? '/tmp/wedding-data' : path.join(process.cwd(), 'data'));

function isSupabaseConfigured() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim();
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();
  const looksLikeSupabaseUrl = Boolean(supabaseUrl && /^https:\/\/[-a-z0-9]+\.supabase\.co(?:\/)??$/i.test(supabaseUrl));
  const looksLikeServiceRoleKey = Boolean(serviceRoleKey && serviceRoleKey.length > 20);
  return looksLikeSupabaseUrl && looksLikeServiceRoleKey;
}
function shouldUseFileStorage() {
  return !isVercelRuntime;
}
async function withAuthLookupTimeout<T>(operation: () => Promise<T>, fallback: T): Promise<T> {
  if (!isSupabaseConfigured()) return fallback;

  return Promise.race([
    operation().catch(() => fallback),
    new Promise<T>((resolve) => setTimeout(() => resolve(fallback), AUTH_LOOKUP_TIMEOUT_MS))
  ]);
}

function getSessionSecret() {
  return process.env.AUTH_SECRET || process.env.NEXTAUTH_SECRET || process.env.JWT_SECRET || process.env.SUPABASE_SERVICE_ROLE_KEY || 'change-me-in-production';
}

function getEnvAdminUser() {
  const adminEmail = process.env.ADMIN_EMAIL?.trim() || 'admin@example.com';
  const adminPassword = process.env.ADMIN_PASSWORD?.trim() || 'change-me-in-production';
  return { adminEmail, adminPassword };
}

function getEnvDemoUser() {
  const demoUsername = process.env.DEMO_COUPLE_USERNAME || 'ahmed-sara-account';
  const demoPassword = process.env.DEMO_COUPLE_PASSWORD || 'wedding123';
  return { demoUsername, demoPassword };
}

function getEnvRegularUser() {
  const regularUsername = process.env.DEMO_USER_USERNAME || 'demo-user';
  const regularPassword = process.env.DEMO_USER_PASSWORD || 'demo-password';
  return { regularUsername, regularPassword };
}

function getLocalFilePath(name: string) {
  return path.join(LOCAL_DATA_DIR, `${name}.json`);
}

function ensureLocalDataFile(name: string, fallback: unknown) {
  if (!shouldUseFileStorage()) {
    if (!MEMORY_STORE.has(name)) MEMORY_STORE.set(name, fallback);
    return '';
  }

  const filePath = getLocalFilePath(name);
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, JSON.stringify(fallback, null, 2), 'utf8');
  return filePath;
}

function readLocalJsonFile<T>(name: string, fallback: T): T {
  if (!shouldUseFileStorage()) {
    const stored = MEMORY_STORE.get(name);
    if (stored !== undefined) return stored as T;
    MEMORY_STORE.set(name, fallback);
    return fallback;
  }

  try {
    ensureLocalDataFile(name, fallback);
    return JSON.parse(fs.readFileSync(getLocalFilePath(name), 'utf8')) as T;
  } catch {
    return fallback;
  }
}

function writeLocalJsonFile(name: string, value: unknown) {
  if (!shouldUseFileStorage()) {
    MEMORY_STORE.set(name, value);
    return '';
  }

  const filePath = ensureLocalDataFile(name, value);
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2), 'utf8');
  return filePath;
}

function getLocalUsers() {
  return readLocalJsonFile<Array<any>>('users', []);
}

function setLocalUsers(users: Array<any>) {
  writeLocalJsonFile('users', users);
}

function getLocalWeddings() {
  return readLocalJsonFile<Array<any>>('weddings', []);
}

function setLocalWeddings(weddings: Array<any>) {
  writeLocalJsonFile('weddings', weddings);
}

function getLocalRsvps() {
  return readLocalJsonFile<Array<any>>('rsvps', []);
}

function setLocalRsvps(rsvps: Array<any>) {
  writeLocalJsonFile('rsvps', rsvps);
}

function sanitizePathSegment(input: string) {
  return String(input || '').toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/(^-|-$)/g, '') || 'upload';
}

function createHash(password: string) {
  try {
    return bcryptjs.hashSync(password, 8);
  } catch {
    // fall back to SHA-256 if bcryptjs fails
    return crypto.createHash('sha256').update(password).digest('hex');
  }
}

function comparePassword(candidate: string, stored: string | null) {
  if (!stored) return false;
  try {
    return bcryptjs.compareSync(candidate, stored);
  } catch {
    // fall back to SHA-256 if bcryptjs fails
    return createHash(candidate) === stored;
  }
}

export function createSessionToken(user: { id: string; role: string; wedding_id?: string | null }) {
  const payload = {
    sub: user.id,
    role: user.role,
    wedding_id: user.wedding_id ?? null
  };

  return jwt.sign(payload, getSessionSecret(), { expiresIn: '7d' });
}

export function verifySessionToken(token: string | null) {
  if (!token) return null;
  try {
    const payload = jwt.verify(token, getSessionSecret()) as any;
    return payload;
  } catch {
    return null;
  }
}

export async function createWedding(payload: any) {
  if (!isSupabaseConfigured()) {
    const weddings = getLocalWeddings();
    const slug = String(payload.slug || `wedding-${Date.now()}`).trim();
    const row: any = {
      id: payload.id || `local-wedding-${Date.now()}`,
      slug,
      groom_name: payload.groom_name ?? null,
      bride_name: payload.bride_name ?? null,
      venue_name: payload.venue_name ?? null,
      address: payload.address ?? null,
      google_maps_url: payload.google_maps_url ?? null,
      wedding_date: payload.wedding_date ?? null,
      wedding_time: payload.wedding_time ?? null,
      story: payload.story ?? null,
      guest_message_audio: payload.guest_message_audio ?? null,
      mp3_url: payload.mp3_url ?? null,
      visible_sections: payload.visible_sections ?? {},
      theme: payload.theme ?? null,
      is_active: true,
      is_published: true,
      allow_guest_uploads: payload.allow_guest_uploads ?? true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    weddings.unshift(row);
    setLocalWeddings(weddings);
    return row;
  }

  const slug = payload.slug || `wedding-${Date.now()}`;
  let groom_image_url = payload.groom_image_url ?? null;
  let bride_image_url = payload.bride_image_url ?? null;
  let cover_image_url = payload.cover_image_url ?? null;
  let mp3_url = payload.mp3_url ?? null;

  if (payload.groom_image) {
    groom_image_url = await uploadDataUrl(payload.groom_image, `${slug}/groom-${Date.now()}`, 'images');
  }
  if (payload.bride_image) {
    bride_image_url = await uploadDataUrl(payload.bride_image, `${slug}/bride-${Date.now()}`, 'images');
  }
  if (payload.cover_image) {
    cover_image_url = await uploadDataUrl(payload.cover_image, `${slug}/cover-${Date.now()}`, 'images');
  }
  if (!mp3_url && payload.mp3_data) {
    mp3_url = await uploadDataUrl(payload.mp3_data, `${slug}/music-${Date.now()}`, 'music');
  }

  const dbRow: any = {
    slug,
    groom_name: payload.groom_name ?? null,
    bride_name: payload.bride_name ?? null,
    venue_name: payload.venue_name ?? null,
    address: payload.address ?? null,
    google_maps_url: payload.google_maps_url ?? null,
    wedding_date: payload.wedding_date ?? null,
    wedding_time: payload.wedding_time ?? null,
    groom_image_url,
    bride_image_url,
    cover_image_url,
    guest_message_audio: payload.guest_message_audio ?? null,
    mp3_url,
    visible_sections: payload.visible_sections ?? {},
    theme: payload.theme ?? null,
    is_active: true,
    is_published: true,
    allow_guest_uploads: payload.allow_guest_uploads ?? true
  };

  const { data, error } = await supabaseAdmin.from('weddings').insert([dbRow]).select().single();
  if (error) throw new Error(error.message);
  return data;
}

export async function createUser({ email, username, password, role = 'couple', wedding_id = null }: { email?: string; username?: string; password?: string; role?: string; wedding_id?: string | null }) {
  if (!isSupabaseConfigured()) {
    const users = getLocalUsers();
    const row: any = {
      id: `local-user-${Date.now()}`,
      email: email ?? null,
      username: username ?? null,
      password_hash: password ? createHash(password) : null,
      role,
      wedding_id,
      created_at: new Date().toISOString()
    };
    users.push(row);
    setLocalUsers(users);
    return row;
  }

  const hash = password ? createHash(password) : null;
  const { data, error } = await supabaseAdmin.from('users').insert([{ email, username, password_hash: hash, role, wedding_id }]).select().single();
  if (error) throw new Error(error.message);
  return data;
}

export async function getUserById(id: string) {
  if (id === 'env-admin') {
    const { adminEmail } = getEnvAdminUser();
    return { id: 'env-admin', email: adminEmail, username: 'super-admin', role: 'super_admin', wedding_id: null };
  }

  if (id === 'env-demo-couple') {
    const { demoUsername } = getEnvDemoUser();
    return { id: 'env-demo-couple', email: `${demoUsername}@wedding.local`, username: demoUsername, role: 'couple', wedding_id: null };
  }

  if (id === 'env-demo-user') {
    const { regularUsername } = getEnvRegularUser();
    return { id: 'env-demo-user', email: `${regularUsername}@wedding.local`, username: regularUsername, role: 'user', wedding_id: null };
  }

  if (!isSupabaseConfigured()) {
    return getLocalUsers().find((user) => String(user.id) === String(id)) ?? null;
  }

  const result = await withAuthLookupTimeout(async () => {
    const { data, error } = await supabaseAdmin.from('users').select('*').eq('id', id).maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  }, null);

  return result;
}

export async function getUserByEmail(email: string) {
  const { adminEmail } = getEnvAdminUser();
  if (email?.trim().toLowerCase() === adminEmail.trim().toLowerCase()) {
    return { id: 'env-admin', email: adminEmail, username: 'super-admin', role: 'super_admin', wedding_id: null };
  }

  if (!isSupabaseConfigured()) {
    return getLocalUsers().find((user) => String(user.email || '').trim().toLowerCase() === String(email || '').trim().toLowerCase()) ?? null;
  }

  return withAuthLookupTimeout(async () => {
    const { data, error } = await supabaseAdmin.from('users').select('*').eq('email', email).maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  }, null);
}

export async function getUserByUsername(username: string) {
  const { demoUsername } = getEnvDemoUser();
  const { regularUsername } = getEnvRegularUser();
  if (username?.trim().toLowerCase() === demoUsername.trim().toLowerCase()) {
    return { id: 'env-demo-couple', email: `${demoUsername}@wedding.local`, username: demoUsername, role: 'couple', wedding_id: null };
  }

  if (username?.trim().toLowerCase() === regularUsername.trim().toLowerCase()) {
    return { id: 'env-demo-user', email: `${regularUsername}@wedding.local`, username: regularUsername, role: 'user', wedding_id: null };
  }

  if (!isSupabaseConfigured()) {
    return getLocalUsers().find((user) => String(user.username || '').trim().toLowerCase() === String(username || '').trim().toLowerCase()) ?? null;
  }

  return withAuthLookupTimeout(async () => {
    const { data, error } = await supabaseAdmin.from('users').select('*').eq('username', username).maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  }, null);
}

export async function verifyUserCredentials({ identifier, password }: { identifier: string; password: string }) {
  const { adminEmail, adminPassword } = getEnvAdminUser();
  const { demoUsername, demoPassword } = getEnvDemoUser();
  const { regularUsername, regularPassword } = getEnvRegularUser();

  if (identifier?.trim().toLowerCase() === adminEmail.trim().toLowerCase() && password === adminPassword) {
    return { id: 'env-admin', email: adminEmail, username: 'super-admin', role: 'super_admin', wedding_id: null };
  }

  if (identifier?.trim().toLowerCase() === demoUsername.trim().toLowerCase() && password === demoPassword) {
    return { id: 'env-demo-couple', email: `${demoUsername}@wedding.local`, username: demoUsername, role: 'couple', wedding_id: null };
  }

  if (identifier?.trim().toLowerCase() === regularUsername.trim().toLowerCase() && password === regularPassword) {
    return { id: 'env-demo-user', email: `${regularUsername}@wedding.local`, username: regularUsername, role: 'user', wedding_id: null };
  }

  if (!isSupabaseConfigured()) {
    const localUsers = getLocalUsers();
    const candidate = localUsers.find((user) => {
      const emailMatches = String(user.email || '').trim().toLowerCase() === String(identifier || '').trim().toLowerCase();
      const usernameMatches = String(user.username || '').trim().toLowerCase() === String(identifier || '').trim().toLowerCase();
      return emailMatches || usernameMatches;
    });
    if (!candidate) return null;
    if (!candidate.password_hash) return null;
    return comparePassword(password, candidate.password_hash) ? candidate : null;
  }

  const byEmail = await getUserByEmail(identifier);
  const user = byEmail || await getUserByUsername(identifier);
  if (!user) return null;
  if (!user.password_hash) return null;
  return comparePassword(password, user.password_hash) ? user : null;
}

export function parseCookies(cookieHeader: string | null) {
  const out: any = {};
  if (!cookieHeader) return out;
  const parts = cookieHeader.split(';');
  for (const p of parts) {
    const [k, ...v] = p.split('=');
    if (!k) continue;
    out[k.trim()] = decodeURIComponent((v || []).join('=').trim());
  }
  return out;
}

export async function getUserFromRequest(request: Request) {
  const cookieHeader = request.headers.get('cookie');
  const cookies = parseCookies(cookieHeader);
  const serialized = cookies['session_user'] || cookies['session'];
  if (!serialized) return null;
  try {
    const payload = verifySessionToken(serialized);
    if (!payload?.sub) return null;
    const user = await getUserById(payload.sub);
    return user;
  } catch {
    return null;
  }
}

export async function listUsers() {
  if (!isSupabaseConfigured()) {
    return getLocalUsers().slice().sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
  }

  const { data, error } = await supabaseAdmin.from('users').select('*').order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function listWeddings() {
  if (!isSupabaseConfigured()) {
    return getLocalWeddings().slice().sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
  }

  const { data, error } = await supabaseAdmin.from('weddings').select('*').order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return data;
}

export async function getWeddingBySlug(slug: string) {
  if (!isSupabaseConfigured()) {
    return getLocalWeddings().find((wedding) => String(wedding.slug) === String(slug)) ?? null;
  }

  const { data, error } = await supabaseAdmin.from('weddings').select('*').eq('slug', slug).maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}

export async function getWeddingById(id: string) {
  if (!isSupabaseConfigured()) {
    return getLocalWeddings().find((wedding) => String(wedding.id) === String(id)) ?? null;
  }

  const { data, error } = await supabaseAdmin.from('weddings').select('*').eq('id', id).maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}

export async function updateWedding(slug: string, updates: any) {
  if (!isSupabaseConfigured()) {
    const weddings = getLocalWeddings();
    const index = weddings.findIndex((wedding) => String(wedding.slug) === String(slug));
    if (index < 0) return null;
    const next = { ...weddings[index], ...updates, updated_at: new Date().toISOString() };
    weddings[index] = next;
    setLocalWeddings(weddings);
    return next;
  }

  const { data, error } = await supabaseAdmin.from('weddings').update(updates).eq('slug', slug).select().maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}

export async function deleteWedding(slug: string) {
  if (!isSupabaseConfigured()) {
    const weddings = getLocalWeddings().filter((wedding) => String(wedding.slug) !== String(slug));
    setLocalWeddings(weddings);
    return { ok: true, slug };
  }

  const { error } = await supabaseAdmin.from('weddings').delete().eq('slug', slug);
  if (error) throw new Error(error.message);
  return { ok: true, slug };
}

export async function insertRsvp(payload: any) {
  if (!isSupabaseConfigured()) {
    const rsvps = getLocalRsvps();
    const row = { id: payload.id || `local-rsvp-${Date.now()}`, ...payload, created_at: new Date().toISOString() };
    rsvps.push(row);
    setLocalRsvps(rsvps);
    return row;
  }

  const { data, error } = await supabaseAdmin.from('rsvps').insert([payload]).select().single();
  if (error) throw new Error(error.message);
  return data;
}

export async function listRsvpsForWedding(weddingIdOrSlug: string) {
  if (!isSupabaseConfigured()) {
    return getLocalRsvps().filter((row) => String(row.wedding_id) === String(weddingIdOrSlug) || String(row.wedding_slug) === String(weddingIdOrSlug));
  }

  const { data, error } = await supabaseAdmin.from('rsvps').select('*').or(`wedding_id.eq.${weddingIdOrSlug},wedding_slug.eq.${weddingIdOrSlug}`);
  if (error) throw new Error(error.message);
  return data;
}

export default {
  createWedding,
  listWeddings,
  getWeddingBySlug,
  insertRsvp,
  listRsvpsForWedding
};
