import * as store from './data-store';

export async function getUserFromRequest(request: Request) {
  return await store.getUserFromRequest(request);
}

export function requireAdmin(user: any) {
  if (!user) throw new Error('Unauthorized');
  if (user.role !== 'super_admin') throw new Error('Forbidden');
}

export function requireOwnerOrAdmin(user: any, weddingSlugOwnerId: string | null, userWeddingId: string | null) {
  if (!user) throw new Error('Unauthorized');
  if (user.role === 'super_admin') return true;
  if (user.role === 'couple' && (user.wedding_id === userWeddingId || user.wedding_id === weddingSlugOwnerId)) return true;
  throw new Error('Forbidden');
}
