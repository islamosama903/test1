import path from 'path';
import { supabaseAdmin } from './supabase-admin';

function isSupabaseStorageConfigured() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim();
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();
  const supabaseKey = (process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)?.trim();
  return Boolean(supabaseUrl && serviceRoleKey && supabaseKey);
}

function sanitizePathSegment(input: string) {
  return String(input || '').toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/(^-|-$)/g, '') || 'upload';
}

function getStorageBucketName(bucket?: string) {
  if (!bucket || !bucket.trim()) {
    throw new Error('Storage bucket name is required for upload');
  }
  return bucket.trim().toLowerCase();
}

export class StorageNotConfiguredError extends Error {
  constructor(message = 'Storage is not configured. Please contact the administrator.') {
    super(message);
    this.name = 'StorageNotConfiguredError';
  }
}

export async function uploadBuffer({ slug, buffer, contentType, filename, folder, bucket }: { slug: string; buffer: Buffer; contentType: string; filename: string; folder?: string; bucket?: string }) {
  const safeSlug = sanitizePathSegment(slug);
  const safeFolder = folder ? sanitizePathSegment(folder) : '';
  const safeFilenameSegment = sanitizePathSegment(filename);
  const safeFilename = safeFilenameSegment.includes('.') ? safeFilenameSegment : `${safeFilenameSegment}${path.extname(filename) || '.bin'}`;
  const pathSegments = [safeSlug, safeFolder, safeFilename].filter(Boolean);
  const destPath = pathSegments.join('/');

  if (!isSupabaseStorageConfigured()) {
    throw new StorageNotConfiguredError('Supabase storage is not configured. Please set NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY or NEXT_PUBLIC_SUPABASE_ANON_KEY, and SUPABASE_SERVICE_ROLE_KEY.');
  }

  const bucketName = getStorageBucketName(bucket);
  const storage = supabaseAdmin.storage.from(bucketName);
  const { data: uploadData, error: uploadError } = await storage.upload(destPath, buffer, { contentType, upsert: true });
  if (uploadError) {
    throw new Error(uploadError.message || uploadError.details || 'Storage upload failed');
  }
  const { data: publicUrlData, error: publicUrlError } = await storage.getPublicUrl(destPath);
  if (publicUrlError) {
    throw new Error(publicUrlError.message || publicUrlError.details || 'Failed to generate public URL');
  }
  if (!publicUrlData?.publicUrl) {
    const { data: signedUrlData, error: signedUrlError } = await storage.createSignedUrl(destPath, 60 * 60);
    if (signedUrlError || !signedUrlData?.signedUrl) {
      throw new Error(signedUrlError?.message || 'Storage upload succeeded, but no accessible URL was generated.');
    }
    return signedUrlData.signedUrl;
  }
  return publicUrlData.publicUrl;
}

export async function uploadDataUrl(dataUrl: string | null, destPath: string, bucket?: string) {
  if (!dataUrl) return null;
  const m = dataUrl.match(/^data:(.+);base64,(.+)$/);
  if (!m) return null;
  const contentType = m[1];
  const base64 = m[2];
  const buffer = Buffer.from(base64, 'base64');
  return await uploadBuffer({
    slug: destPath.split('/')[0],
    buffer,
    contentType,
    filename: destPath.split('/').slice(1).join('/'),
    bucket
  });
}

export function isStorageConfigured() {
  return isSupabaseStorageConfigured();
}
