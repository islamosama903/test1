import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

let client: any = null;
if (supabaseUrl && supabaseKey) {
  client = createClient(supabaseUrl, supabaseKey, {
    auth: { persistSession: true, autoRefreshToken: true }
  });
} else {
  // lightweight mock to avoid runtime errors in client when Supabase not configured
  client = {
    auth: {
      signInWithPassword: async () => ({ data: null, error: new Error('Supabase not configured') })
    }
  };
}

export const supabase = client;
