import type { CSSProperties } from 'react';

export type WeddingThemeColors = {
  background: string;
  surface: string;
  primary: string;
  secondary: string;
  accent: string;
  text: string;
  muted: string;
  border: string;
};

export type WeddingThemeFonts = {
  body: string;
  heading: string;
};

export type WeddingThemeDecorations = {
  borderStyle: string;
  shadow: string;
  floralOpacity: number;
  radius: string;
};

export type WeddingThemeConfig = {
  id: string;
  name: string;
  description: string;
  colors: WeddingThemeColors;
  fonts: WeddingThemeFonts;
  decorations: WeddingThemeDecorations;
};

const defaultTheme: WeddingThemeConfig = {
  id: 'royal-emerald-garden',
  name: 'Royal Emerald Garden',
  description: 'دعوة فاخرة مستوحاة من الحدائق الملكية وألوان الخضرة الراقية.',
  colors: {
    background: '#F8F6F1',
    surface: '#FCFAF6',
    primary: '#4E6533',
    secondary: '#7B8E52',
    accent: '#C8A96A',
    text: '#2C2C2C',
    muted: '#6F675D',
    border: '#D9D3C4',
  },
  fonts: {
    body: 'Alexandria, "IBM Plex Sans Arabic", "Cairo", sans-serif',
    heading: 'Playfair Display, Cormorant Garamond, serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(78, 101, 51, 0.24)',
    shadow: '0 24px 70px rgba(0,0,0,0.08)',
    floralOpacity: 0.6,
    radius: '2.2rem',
  },
};

const luxuryOliveTheme: WeddingThemeConfig = {
  id: 'premium-luxury',
  name: 'Luxury Olive',
  description: 'ألوان زيتون وذهب هادئة وراقية تمنح إحساسًا فاخرًا ومريحًا.',
  colors: {
    background: '#F8F5F0',
    surface: '#FCFAF6',
    primary: '#556B2F',
    secondary: '#7D8A54',
    accent: '#C5A86A',
    text: '#2F2F2F',
    muted: '#6F6B63',
    border: '#D9D3C4',
  },
  fonts: {
    body: 'Cairo, Alexandria, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Cormorant Garamond, "Playfair Display", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(85, 107, 47, 0.22)',
    shadow: '0 24px 70px rgba(31, 41, 55, 0.10)',
    floralOpacity: 0.42,
    radius: '2rem',
  },
};

const midnightBloomTheme: WeddingThemeConfig = {
  id: 'midnight-bloom',
  name: 'Midnight Bloom',
  description: 'ثيم درامي ليلي مع لمسة ذهبية ودفء رومانسي عميق.',
  colors: {
    background: '#0F172A',
    surface: '#17233B',
    primary: '#C8A96A',
    secondary: '#E7C7A7',
    accent: '#7B8FA6',
    text: '#F6EDE0',
    muted: '#C0C8D7',
    border: '#31415B',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Cinzel, "Cormorant Garamond", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(200, 169, 106, 0.30)',
    shadow: '0 30px 90px rgba(2, 8, 23, 0.34)',
    floralOpacity: 0.55,
    radius: '2.6rem',
  },
};

const blushVelvetTheme: WeddingThemeConfig = {
  id: 'blush-velvet',
  name: 'Blush Velvet',
  description: 'أجواء رومانسية ناعمة بالوردي والكريمي مع لمسة فخمة ودافئة.',
  colors: {
    background: '#FFF7F3',
    surface: '#FFFDFB',
    primary: '#A65C7A',
    secondary: '#8D6D9A',
    accent: '#E1B37A',
    text: '#3F2A31',
    muted: '#7C625F',
    border: '#E8D6D1',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Playfair Display, "Cormorant Garamond", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(166, 92, 122, 0.24)',
    shadow: '0 24px 70px rgba(122, 74, 96, 0.12)',
    floralOpacity: 0.48,
    radius: '2.4rem',
  },
};

const blushRoseRomanceTheme: WeddingThemeConfig = {
  id: 'blush-rose-romance',
  name: 'Blush Rose Romance',
  description: 'ألوان وردية دافئة وذهبية وردية تضفي إحساسًا رومانسيًا خفيفًا.',
  colors: {
    background: '#FFF5F8',
    surface: '#FFFCFD',
    primary: '#C77A84',
    secondary: '#D8A7A0',
    accent: '#C89B4B',
    text: '#4A2F34',
    muted: '#7A5D61',
    border: '#EED6DB',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Cormorant Garamond, "Playfair Display", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(199, 122, 132, 0.26)',
    shadow: '0 24px 70px rgba(199, 122, 132, 0.12)',
    floralOpacity: 0.55,
    radius: '2.3rem',
  },
};

const royalBluePalaceTheme: WeddingThemeConfig = {
  id: 'royal-blue-palace',
  name: 'Royal Blue Palace',
  description: 'أزرق ملكي وذهبي مستوحى من أجواء القصور الفاخرة.',
  colors: {
    background: '#F5F7FB',
    surface: '#FCFDFF',
    primary: '#1F4E8C',
    secondary: '#4C7AB8',
    accent: '#C7A24A',
    text: '#1F2A3A',
    muted: '#5D6B82',
    border: '#D5DCE9',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Libre Baskerville, "Cormorant Garamond", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(31, 78, 140, 0.24)',
    shadow: '0 24px 70px rgba(31, 78, 140, 0.12)',
    floralOpacity: 0.4,
    radius: '2.4rem',
  },
};

const terracottaBohoTheme: WeddingThemeConfig = {
  id: 'terracotta-boho',
  name: 'Terracotta Boho',
  description: 'ألوان ترابية دافئة مع لمسة بوهيمية مريحة وهادئة.',
  colors: {
    background: '#F8EFE7',
    surface: '#FFF9F2',
    primary: '#A45C3B',
    secondary: '#C88B4F',
    accent: '#8E7A58',
    text: '#3E2C22',
    muted: '#7B6658',
    border: '#E4D5C1',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Alegreya, "Cormorant Garamond", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(164, 92, 59, 0.26)',
    shadow: '0 24px 70px rgba(164, 92, 59, 0.12)',
    floralOpacity: 0.5,
    radius: '2.2rem',
  },
};

const lavenderDreamTheme: WeddingThemeConfig = {
  id: 'lavender-dream',
  name: 'Lavender Dream',
  description: 'لافندر وبنفسجي فاتح يخلق أجواءً حلمية وهادئة.',
  colors: {
    background: '#F8F3FF',
    surface: '#FEFCFF',
    primary: '#8F7BBF',
    secondary: '#C7B5E8',
    accent: '#B47BC2',
    text: '#43355D',
    muted: '#75688E',
    border: '#E7DDF7',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Playfair Display, "Cormorant Garamond", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(143, 123, 191, 0.24)',
    shadow: '0 24px 70px rgba(143, 123, 191, 0.12)',
    floralOpacity: 0.45,
    radius: '2.3rem',
  },
};

const oceanPearlTheme: WeddingThemeConfig = {
  id: 'ocean-pearl',
  name: 'Ocean Pearl',
  description: 'أبيض وأزرق بحري يمنحان إحساسًا أنيقًا ومائيًا.',
  colors: {
    background: '#F4FBFD',
    surface: '#FCFEFF',
    primary: '#2E6F8A',
    secondary: '#5DA8C5',
    accent: '#D4B978',
    text: '#18343F',
    muted: '#5B7580',
    border: '#D9EAF0',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Libre Baskerville, "Cormorant Garamond", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(46, 111, 138, 0.22)',
    shadow: '0 24px 70px rgba(46, 111, 138, 0.11)',
    floralOpacity: 0.4,
    radius: '2.4rem',
  },
};

const classicWhiteMarbleTheme: WeddingThemeConfig = {
  id: 'classic-white-marble',
  name: 'Classic White Marble',
  description: 'رخام أبيض وذهبي بنظرة كلاسيكية وأنيقة.',
  colors: {
    background: '#FCF8F2',
    surface: '#FFFEFB',
    primary: '#B08C3A',
    secondary: '#D4BE88',
    accent: '#8E7B5A',
    text: '#2E2A24',
    muted: '#786D5F',
    border: '#E9DFCC',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Playfair Display, "Cormorant Garamond", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(176, 140, 58, 0.24)',
    shadow: '0 24px 70px rgba(46, 42, 36, 0.1)',
    floralOpacity: 0.32,
    radius: '2.5rem',
  },
};

const cherryBlossomSakuraTheme: WeddingThemeConfig = {
  id: 'cherry-blossom-sakura',
  name: 'Cherry Blossom Sakura',
  description: 'ثيم ياباني دقيق ومشرق بالزهور الوردية الناعمة.',
  colors: {
    background: '#FFF8FB',
    surface: '#FFFCFD',
    primary: '#C66B8F',
    secondary: '#E8A5BE',
    accent: '#9A7C5B',
    text: '#4A2F35',
    muted: '#7A5D64',
    border: '#EDD7E0',
  },
  fonts: {
    body: 'Tajawal, "IBM Plex Sans Arabic", sans-serif',
    heading: 'Noto Serif JP, "Cormorant Garamond", serif',
  },
  decorations: {
    borderStyle: '1px solid rgba(198, 107, 143, 0.24)',
    shadow: '0 24px 70px rgba(198, 107, 143, 0.12)',
    floralOpacity: 0.58,
    radius: '2.4rem',
  },
};

export const weddingThemes: WeddingThemeConfig[] = [
  defaultTheme,
  luxuryOliveTheme,
  midnightBloomTheme,
  blushVelvetTheme,
  blushRoseRomanceTheme,
  royalBluePalaceTheme,
  terracottaBohoTheme,
  lavenderDreamTheme,
  oceanPearlTheme,
  classicWhiteMarbleTheme,
  cherryBlossomSakuraTheme,
];

export function getThemePresetOptions() {
  return weddingThemes;
}

export function getThemePresetById(themeId?: string | null) {
  if (!themeId) return defaultTheme;
  return weddingThemes.find((theme) => theme.id === themeId) || defaultTheme;
}

export function resolveWeddingTheme(theme?: Partial<WeddingThemeConfig> | null | string): WeddingThemeConfig {
  if (typeof theme === 'string') {
    return getThemePresetById(theme);
  }

  if (!theme) return defaultTheme;

  return {
    ...defaultTheme,
    ...theme,
    colors: {
      ...defaultTheme.colors,
      ...(theme.colors || {}),
    },
    fonts: {
      ...defaultTheme.fonts,
      ...(theme.fonts || {}),
    },
    decorations: {
      ...defaultTheme.decorations,
      ...(theme.decorations || {}),
    },
  };
}

export function getThemeStyle(theme: WeddingThemeConfig): CSSProperties {
  return {
    background: theme.colors.background,
    color: theme.colors.text,
    fontFamily: theme.fonts.body,
    backgroundImage: theme.id === 'royal-emerald-garden'
      ? 'radial-gradient(circle at top left, rgba(200, 169, 106, 0.16), transparent 40%), linear-gradient(135deg, rgba(248, 246, 241, 0.96), rgba(255, 255, 255, 0.92))'
      : theme.id === 'midnight-bloom'
        ? 'radial-gradient(circle at top right, rgba(200, 169, 106, 0.16), transparent 36%), linear-gradient(135deg, rgba(15, 23, 42, 0.98), rgba(20, 35, 59, 0.96))'
        : theme.id === 'blush-velvet'
          ? 'radial-gradient(circle at top center, rgba(161, 92, 122, 0.14), transparent 42%), linear-gradient(135deg, rgba(255, 247, 243, 0.98), rgba(255, 253, 251, 0.94))'
          : undefined,
    '--theme-primary': theme.colors.primary,
    '--theme-secondary': theme.colors.secondary,
    '--theme-accent': theme.colors.accent,
    '--theme-background': theme.colors.background,
    '--theme-surface': theme.colors.surface,
    '--theme-text': theme.colors.text,
    '--theme-muted': theme.colors.muted,
    '--theme-border': theme.colors.border,
  } as CSSProperties;
}

export function getCardStyle(theme: WeddingThemeConfig): CSSProperties {
  return {
    backgroundColor: theme.colors.surface,
    borderColor: theme.colors.border,
    borderWidth: 1,
    borderStyle: 'solid',
    boxShadow: theme.decorations.shadow,
    borderRadius: theme.decorations.radius,
  };
}

export function getButtonStyle(theme: WeddingThemeConfig): CSSProperties {
  return {
    background: `linear-gradient(135deg, ${theme.colors.primary}, ${theme.colors.secondary})`,
    color: '#fff',
    borderRadius: '999px',
    boxShadow: `0 16px 35px ${theme.colors.primary}20`,
  };
}
