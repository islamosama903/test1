import fs from 'fs';
import path from 'path';

const isVercelRuntime = Boolean(process.env.VERCEL || process.env.NEXT_PUBLIC_VERCEL_ENV || process.env.NODE_ENV === 'production');
const settingsFile = path.join(process.cwd(), 'data', 'settings.json');
let memorySettings: Record<string, any> | null = null;

function getDefaultSettings() {
  return {
    enabled: true,
    name: 'Islam Osama',
    phone: '01050759399',
    whatsapp: 'https://wa.me/201050759399'
  };
}

function ensureSettingsFile() {
  if (isVercelRuntime) {
    if (memorySettings === null) memorySettings = getDefaultSettings();
    return;
  }

  const dir = path.dirname(settingsFile);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(settingsFile)) {
    fs.writeFileSync(settingsFile, JSON.stringify(getDefaultSettings(), null, 2), 'utf8');
  }
}

export function getContactSettings() {
  ensureSettingsFile();
  if (isVercelRuntime) return memorySettings ?? getDefaultSettings();

  try {
    return JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
  } catch {
    return getDefaultSettings();
  }
}

export function updateContactSettings(payload: any) {
  ensureSettingsFile();
  const current = getContactSettings();
  const next = {
    ...current,
    ...payload,
    enabled: payload.enabled ?? current.enabled ?? true,
    name: payload.name ?? current.name ?? 'Islam Osama',
    phone: payload.phone ?? current.phone ?? '01050759399',
    whatsapp: payload.whatsapp ?? current.whatsapp ?? 'https://wa.me/201050759399'
  };

  if (isVercelRuntime) {
    memorySettings = next;
    return next;
  }

  fs.writeFileSync(settingsFile, JSON.stringify(next, null, 2), 'utf8');
  return next;
}
