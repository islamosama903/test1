export const MAX_AUDIO_DURATION_SECONDS = 10 * 60;

export function getSupportedAudioMimeType(mediaRecorder: typeof MediaRecorder | undefined) {
  if (typeof mediaRecorder === 'undefined') return '';
  if (mediaRecorder.isTypeSupported?.('audio/webm;codecs=opus')) return 'audio/webm;codecs=opus';
  if (mediaRecorder.isTypeSupported?.('audio/webm')) return 'audio/webm';
  if (mediaRecorder.isTypeSupported?.('audio/ogg;codecs=opus')) return 'audio/ogg;codecs=opus';
  if (mediaRecorder.isTypeSupported?.('audio/ogg')) return 'audio/ogg';
  return '';
}

export function validateAudioDuration(durationInSeconds: number | null | undefined) {
  if (typeof durationInSeconds !== 'number' || Number.isNaN(durationInSeconds)) return 'تعذر قراءة مدة الملف الصوتي';
  if (durationInSeconds > MAX_AUDIO_DURATION_SECONDS) return 'الحد الأقصى لمدة الملف الصوتي هو 10 دقائق';
  return null;
}
