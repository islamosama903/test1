#!/usr/bin/env node
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRole = process.env.SUPABASE_SERVICE_ROLE_KEY;
const dbUrl = process.env.SUPABASE_DB_URL;

if (!supabaseUrl || !serviceRole) {
  console.error('NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required to run this script.');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceRole);

(async function main() {
  try {
    // Ensure required storage buckets exist
    const requiredBuckets = ['images', 'videos', 'music'];
    const { data: buckets } = await supabase.storage.listBuckets();
    const existingBuckets = (buckets || []).map((b) => b.name);
    for (const bucketName of requiredBuckets) {
      if (!existingBuckets.includes(bucketName)) {
        console.log(`Creating storage bucket: ${bucketName}`);
        const { error } = await supabase.storage.createBucket(bucketName, { public: true });
        if (error) console.error(`Failed to create bucket ${bucketName}:`, error.message || error);
        else console.log(`Bucket ${bucketName} created.`);
      } else {
        console.log(`Bucket ${bucketName} already exists.`);
      }
    }

    // Run SQL migrations if SUPABASE_DB_URL provided
    if (dbUrl) {
      console.log('Running SQL migrations from migrations/');
      const { Client } = require('pg');
      const client = new Client({ connectionString: dbUrl });
      await client.connect();
      const migrationsDir = path.join(process.cwd(), 'migrations');
      const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();
      for (const f of files) {
        const sql = fs.readFileSync(path.join(migrationsDir, f), 'utf8');
        console.log('Applying', f);
        await client.query(sql);
      }
      await client.end();
      console.log('Migrations applied.');
    } else {
      console.log('SUPABASE_DB_URL not set; skipping DB migrations. You can run migrations manually or provide SUPABASE_DB_URL.');
    }

    // Seed demo data via REST if possible
    try {
      const seedPath = path.join(process.cwd(), 'scripts', 'seed-mock.js');
      if (fs.existsSync(seedPath)) {
        console.log('Running seed-mock.js');
        require(seedPath);
      }
    } catch (e) {
      console.warn('Seed script failed or is not configured:', e.message || e);
    }

    console.log('Setup complete.');
  } catch (err) {
    console.error('Setup failed:', err.message || err);
    process.exit(1);
  }
})();
