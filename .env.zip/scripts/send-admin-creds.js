#!/usr/bin/env node
require('dotenv').config();
const nodemailer = require('nodemailer');
const argv = require('minimist')(process.argv.slice(2));

const adminEmail = process.env.ADMIN_EMAIL || 'dxbhfs@gmail.com';
const adminPassword = process.env.ADMIN_PASSWORD || 'admin';
const to = argv.to || argv.t || adminEmail;

async function main() {
  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT || 587;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    console.error('Please set SMTP_HOST, SMTP_USER, SMTP_PASS in .env.local to send email.');
    process.exit(1);
  }

  const transporter = nodemailer.createTransport({ host, port: Number(port), secure: Number(port) === 465, auth: { user, pass } });

  const info = await transporter.sendMail({
    from: process.env.SMTP_FROM || `No Reply <${user}>`,
    to,
    subject: 'بيانات دخول الأدمن - منصة دعوات الزفاف',
    text: `حساب الأدمن:\nالبريد: ${adminEmail}\nكلمة المرور: ${adminPassword}\n\nادخل إلى /admin/login لتسجيل الدخول.`,
    html: `<p>حساب الأدمن:</p><ul><li><strong>البريد:</strong> ${adminEmail}</li><li><strong>كلمة المرور:</strong> ${adminPassword}</li></ul><p>ادخل إلى <a href="/admin/login">صفحة تسجيل الدخول</a>.</p>`
  });

  console.log('Message sent:', info.messageId || info);
}

main().catch(err => { console.error('Failed to send:', err); process.exit(1); });
