#!/usr/bin/env node
require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    console.error('Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local to seed mock data.');
    process.exit(1);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey);

  (async () => {
  try {
    const slug = 'fhh-fhdhd';
    const payload = {
      slug,
      groom_name: 'محمود',
      bride_name: 'أمنية',
      wedding_date: '١٥ أغسطس ٢٠٢٦',
      wedding_time: '٧:٣٠ مساءً',
      venue_name: 'قاعة الورد',
      story: 'تم ربط الرابط بنجاح، وهو الآن جاهز لعرض صفحة الدعوة المعتمدة على slug خاص.',
    };

    const { data, error } = await supabase.from('weddings').insert([payload]).select();
    if (error) {
      console.error('Failed to insert mock wedding:', error.message || error);
    } else {
      console.log('Inserted mock wedding:', data);
    }

    // create super admin user if not exists
    const adminEmail = process.env.ADMIN_EMAIL || 'dxbhfs@gmail.com';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin';
    const bcrypt = require('bcryptjs');
    const hash = bcrypt.hashSync(adminPassword, 8);

    const { data: usersData, error: usersError } = await supabase.from('users').select('*').eq('email', adminEmail);
    if (usersError) {
      console.error('Failed to query users:', usersError.message || usersError);
    } else if (!usersData || usersData.length === 0) {
      const insertRes = await supabase.from('users').insert([{ email: adminEmail, password_hash: hash, role: 'super_admin' }]).select();
      if (insertRes.error) console.error('Failed to create super admin:', insertRes.error.message || insertRes.error);
      else console.log('Created super admin user:', insertRes.data);
    } else {
      console.log('Super admin already exists.');
    }

    process.exit(0);
  } catch (err) {
    console.error('Seeding failed:', err.message || err);
    process.exit(1);
  }
})();
