#!/usr/bin/env node
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

const databaseUrl = process.env.SUPABASE_DB_URL;
if (!databaseUrl) {
  console.error('SUPABASE_DB_URL is not set in environment. Set it in .env.local or environment variables.');
  process.exit(1);
}

const sqlPath = path.join(__dirname, '..', 'migrations', '001_init.sql');
const sql = fs.readFileSync(sqlPath, 'utf8');

(async () => {
  const client = new Client({ connectionString: databaseUrl });
  try {
    await client.connect();
    console.log('Connected to database, running migrations...');
    await client.query(sql);
    console.log('Migrations applied successfully.');
    await client.end();
    process.exit(0);
  } catch (err) {
    console.error('Migration failed:', err.message || err);
    process.exit(1);
  }
})();
