import { describe, it, expect } from 'vitest';
import { getCountdownParts, hasVisibleContent, getWeddingMedia } from '../lib/wedding-utils';

describe('wedding-utils', () => {
  it('getCountdownParts returns zero values for past events', () => {
    const now = new Date(2026, 0, 1, 12, 0, 0);
    const parts = getCountdownParts(new Date(2025, 11, 31, 10, 0, 0), now);
    expect(parts).toEqual({ days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true });
  });

  it('getCountdownParts calculates remaining time for future events', () => {
    const now = new Date(2026, 0, 1, 12, 0, 0);
    const parts = getCountdownParts(new Date(2026, 0, 2, 14, 30, 0), now);
    expect(parts).toEqual({ days: 1, hours: 2, minutes: 30, seconds: 0, isPast: false });
  });

  it('hasVisibleContent returns false for empty content and true for populated content', () => {
    expect(hasVisibleContent([])).toBe(false);
    expect(hasVisibleContent(['https://example.com/photo.jpg'])).toBe(true);
    expect(hasVisibleContent('   ')).toBe(false);
  });

  it('getWeddingMedia collects photos and videos from the wedding payload', () => {
    const wedding = {
      gallery_images: ['https://example.com/one.jpg', 'https://example.com/two.jpg'],
      videos: ['https://example.com/demo.mp4']
    };
    const media = getWeddingMedia(wedding as any);
    expect(media.photos).toEqual(['https://example.com/one.jpg', 'https://example.com/two.jpg']);
    expect(media.videos).toEqual(['https://example.com/demo.mp4']);
  });
});
