import { describe, it, expect } from 'vitest';
import { StorageNotConfiguredError, uploadBuffer, isStorageConfigured } from '../lib/storage-service';

describe('uploadBuffer', () => {
  it('throws StorageNotConfiguredError when Supabase storage is not configured', async () => {
    delete process.env.NEXT_PUBLIC_SUPABASE_URL;
    delete process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
    delete process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    delete process.env.SUPABASE_SERVICE_ROLE_KEY;

    await expect(uploadBuffer({
      slug: 'demo-wedding',
      buffer: Buffer.from('hello from local upload'),
      contentType: 'text/plain',
      filename: 'notes.txt',
      bucket: 'images'
    })).rejects.toThrow(StorageNotConfiguredError);
  });

  it('considers Supabase storage configured when publishable key is present', () => {
    process.env.NEXT_PUBLIC_SUPABASE_URL = 'https://example.supabase.co';
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_fake';
    process.env.SUPABASE_SERVICE_ROLE_KEY = 'sb_service_role_fake';

    expect(isStorageConfigured()).toBe(true);

    delete process.env.NEXT_PUBLIC_SUPABASE_URL;
    delete process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
    delete process.env.SUPABASE_SERVICE_ROLE_KEY;
  });
});
