import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as store from '../lib/data-store';
import { supabaseAdmin } from '../lib/supabase-admin';

describe('auth login flow', () => {
  const originalFrom = supabaseAdmin.from;

  beforeEach(() => {
    process.env.NEXT_PUBLIC_SUPABASE_URL = 'https://example.supabase.co';
    process.env.SUPABASE_SERVICE_ROLE_KEY = 'fake-service-role-key';
  });

  afterEach(() => {
    supabaseAdmin.from = originalFrom;
  });

  it('creates default env admin and demo accounts and verifies credentials', async () => {
    const admin = await store.verifyUserCredentials({ identifier: (process.env.ADMIN_EMAIL || 'dxbhfs@gmail.com'), password: (process.env.ADMIN_PASSWORD || 'admin') });
    expect(admin).toBeTruthy();
    expect(admin?.role).toBe('super_admin');

    const demo = await store.verifyUserCredentials({ identifier: (process.env.DEMO_COUPLE_USERNAME || 'ahmed-sara-account'), password: (process.env.DEMO_COUPLE_PASSWORD || 'wedding123') });
    expect(demo).toBeTruthy();
    expect(demo?.role).toBe('couple');
  });

  it('generates and verifies session tokens and respects expiration', () => {
    const user = { id: 'test-user', role: 'couple', wedding_id: null };
    const token = store.createSessionToken(user as any);
    const payload = store.verifySessionToken(token);
    expect(payload).toBeTruthy();
    expect(payload?.sub).toBe('test-user');

    // tamper with token signature -> invalid
    const parts = token.split('.');
    const tampered = parts[0] + '.deadbeef';
    expect(store.verifySessionToken(tampered)).toBeNull();
  });

  it('gracefully falls back when Supabase auth lookups fail', async () => {
    supabaseAdmin.from = () => ({
      select: () => ({
        eq: () => ({
          maybeSingle: async () => {
            throw new Error('db unavailable');
          }
        })
      })
    });

    await expect(store.getUserByEmail('someone@example.com')).resolves.toBeNull();
    await expect(store.getUserByUsername('someone')).resolves.toBeNull();
  });

  it('rejects expired tokens', () => {
    const user = { id: 'expired-user', role: 'couple', wedding_id: null };
    // create token with past exp claim
    const secret = (process.env.AUTH_SECRET || process.env.NEXTAUTH_SECRET || process.env.SUPABASE_SERVICE_ROLE_KEY || 'change-me-in-production');
    const jwt = require('jsonwebtoken');
    const expiredToken = jwt.sign({ sub: user.id, role: user.role, wedding_id: null, exp: Math.floor(Date.now() / 1000) - 10 }, secret);
    expect(store.verifySessionToken(expiredToken)).toBeNull();
  });
});
