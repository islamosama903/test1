import { describe, it, expect } from 'vitest';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { verifyUserCredentials } from '../lib/data-store';

function withTempWorkspace(fn: () => Promise<void>) {
  const originalDataDir = process.env.WEDDING_DATA_DIR;
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wedding-auth-'));
  process.env.WEDDING_DATA_DIR = tmpDir;
  return fn().finally(() => {
    if (originalDataDir === undefined) delete process.env.WEDDING_DATA_DIR;
    else process.env.WEDDING_DATA_DIR = originalDataDir;
  });
}

describe('auth-login (local fallback)', () => {
  it('creates a default admin account for local login', async () => {
    await withTempWorkspace(async () => {
      const user = await verifyUserCredentials({ identifier: 'dxbhfs@gmail.com', password: 'admin' });
      expect(user).toBeTruthy();
      expect(user?.role).toBe('super_admin');
      expect(user?.email).toBe('dxbhfs@gmail.com');
    });
  });

  it('creates a demo couple account for the demo wedding', async () => {
    await withTempWorkspace(async () => {
      fs.writeFileSync(path.join(process.env.WEDDING_DATA_DIR || process.cwd(), 'weddings.json'), JSON.stringify([
        { id: 'local-demo-1', slug: 'demo-wedding', groom_name: 'أحمد', bride_name: 'سارة' }
      ], null, 2));

      const user = await verifyUserCredentials({ identifier: 'ahmed-sara-account', password: 'wedding123' });
      expect(user).toBeTruthy();
      expect(user?.role).toBe('couple');
      expect(user?.username).toBe('ahmed-sara-account');
      expect(user?.wedding_id ?? null).toBeNull();
    });
  });
});
