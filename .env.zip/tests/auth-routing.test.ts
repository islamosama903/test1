import { describe, it, expect } from 'vitest';
import { getPostLoginTarget } from '../lib/auth-routing';

describe('getPostLoginTarget', () => {
  it('routes super_admin users to the admin dashboard', () => {
    expect(getPostLoginTarget('super_admin', 'demo-wedding')).toBe('/admin');
  });

  it('routes couple users to their dedicated dashboard', () => {
    expect(getPostLoginTarget('couple', 'demo-wedding')).toBe('/couple/demo-wedding');
  });

  it('falls back to the home page for couple accounts without a wedding slug', () => {
    expect(getPostLoginTarget('couple', null)).toBe('/');
  });
});
