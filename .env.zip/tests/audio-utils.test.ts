import { describe, it, expect } from 'vitest';
import { getSupportedAudioMimeType, validateAudioDuration } from '../lib/audio-utils';

describe('audio-utils', () => {
  it('returns the preferred WebM Opus mime type when available', () => {
    const mediaRecorder = { isTypeSupported: (type: string) => type === 'audio/webm;codecs=opus' };
    expect(getSupportedAudioMimeType(mediaRecorder as any)).toBe('audio/webm;codecs=opus');
  });

  it('falls back to the first browser-supported audio format', () => {
    const mediaRecorder = { isTypeSupported: (type: string) => type === 'audio/ogg' };
    expect(getSupportedAudioMimeType(mediaRecorder as any)).toBe('audio/ogg');
  });

  it('accepts audio files within the maximum allowed duration', () => {
    expect(validateAudioDuration(600)).toBeNull();
  });

  it('rejects audio files longer than the maximum allowed duration', () => {
    expect(validateAudioDuration(601)).toBe('الحد الأقصى لمدة الملف الصوتي هو 10 دقائق');
  });
});
