"use client";

import { useEffect, useMemo, useRef, useState, type MouseEvent } from 'react';
import { Pause, Play } from 'lucide-react';

type AudioPlayerProps = {
  src: string;
  label?: string;
  subtitle?: string;
};

export default function AudioPlayer({ src, label = 'تسجيل صوتي', subtitle }: AudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleLoadedMetadata = () => {
      setDuration(audio.duration || 0);
      setLoaded(true);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setPlaying(false);
    };

    const handleError = () => {
      setError('تعذر تحميل الصوت. حاول مرة أخرى.');
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [src]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.play().catch(() => {
        setPlaying(false);
        setError('تعذر تشغيل الملف الصوتي.');
      });
    } else {
      audio.pause();
    }
  }, [playing]);

  useEffect(() => {
    setPlaying(false);
    setCurrentTime(0);
    setDuration(0);
    setLoaded(false);
    setError('');

    const audio = audioRef.current;
    if (audio) {
      audio.load();
    }
  }, [src]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = useMemo(() => {
    if (!loaded || duration === 0) return 0;
    return Math.min(100, Math.max(0, (currentTime / duration) * 100));
  }, [currentTime, duration, loaded]);

  const handleSeek = (event: MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    if (!audio || !loaded || duration === 0) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const position = (event.clientX - rect.left) / rect.width;
    audio.currentTime = position * duration;
  };

  return (
    <div className="rounded-[2rem] border border-slate-200 bg-white/95 p-5 shadow-[0_20px_40px_rgba(15,23,42,0.08)]">
      <div className="flex items-start justify-between gap-4 text-right">
        <div>
          <p className="text-sm uppercase tracking-[0.25em] text-rose-500">{label}</p>
          {subtitle ? <p className="mt-1 text-base font-semibold text-slate-800">{subtitle}</p> : null}
        </div>
        <button
          type="button"
          onClick={() => setPlaying((state) => !state)}
          className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-emerald-600/15 text-emerald-700 transition hover:bg-emerald-600/25 focus:outline-none focus:ring-2 focus:ring-emerald-300"
          aria-label={playing ? 'إيقاف' : 'تشغيل'}
        >
          {playing ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
        </button>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-[auto_1fr] sm:items-center">
        <div className="rounded-full bg-slate-100 px-4 py-2 text-xs uppercase tracking-[0.2em] text-slate-500 shadow-sm">{formatTime(currentTime)} / {loaded ? formatTime(duration) : '0:00'}</div>
        <div className="w-full">
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200" onClick={handleSeek}>
            <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-rose-400 to-pink-500 transition-all" style={{ width: `${progress}%` }} />
          </div>
        </div>
      </div>

      {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
      <audio ref={audioRef} src={src} preload="metadata" className="hidden" controlsList="nodownload" />
    </div>
  );
}
