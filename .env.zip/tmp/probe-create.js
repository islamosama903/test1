const fetch = global.fetch;
(async () => {
  const loginRes = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'dxbhfs@gmail.com', password: 'admin' })
  });
  console.log('login-status', loginRes.status);
  const setCookie = loginRes.headers.get('set-cookie') || '';
  console.log('set-cookie', setCookie);

  const payload = {
    slug: 'qa-test',
    groom_name: 'QA',
    bride_name: 'Test',
    venue_name: 'Test Venue',
    address: 'Test Address',
    visible_sections: {},
    theme: 'royal-emerald-garden'
  };

  const createRes = await fetch('http://localhost:3000/api/weddings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', cookie: setCookie },
    body: JSON.stringify(payload)
  });
  console.log('create-status', createRes.status);
  const text = await createRes.text();
  console.log('create-body', text);
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
