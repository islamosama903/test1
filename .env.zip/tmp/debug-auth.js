const { POST } = require('./.next/server/app/api/auth/login/route.js');
(async () => {
  const req = new Request('http://localhost/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ identifier: 'dxbhfs@gmail.com', password: 'admin' })
  });
  const res = await POST(req);
  console.log('status', res.status);
  console.log('headers', [...res.headers.entries()].filter(([k]) => k.toLowerCase() === 'set-cookie'));
  console.log('body', await res.text());
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
