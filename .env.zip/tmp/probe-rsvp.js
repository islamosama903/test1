const fetch = global.fetch;
(async () => {
  const res = await fetch('http://localhost:3000/api/rsvps', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ wedding_id: 'local-wedding-1785328580947', wedding_slug: 'ahmed-sara', guest_name: 'Probe', status: 'attending' })
  });
  console.log('status', res.status);
  console.log(await res.text());
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
