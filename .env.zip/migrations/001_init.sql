-- 001_init.sql
-- Schema: weddings platform

-- users table (local admin + couple accounts)
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text,
  username text,
  password_hash text,
  role text NOT NULL DEFAULT 'couple', -- super_admin | couple
  wedding_id uuid NULL,
  created_at timestamptz DEFAULT now()
);

-- weddings table
CREATE TABLE IF NOT EXISTS weddings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  groom_name text,
  bride_name text,
  venue_name text,
  address text,
  google_maps_url text,
  wedding_date text,
  wedding_time text,
  story text,
  groom_image_url text,
  bride_image_url text,
  cover_image_url text,
  guest_message_audio text,
  mp3_url text,
  visible_sections jsonb DEFAULT '{}',
  theme text,
  is_active boolean DEFAULT true,
  is_published boolean DEFAULT false,
  allow_guest_uploads boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- rsvps table
CREATE TABLE IF NOT EXISTS rsvps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id uuid REFERENCES weddings(id) ON DELETE CASCADE,
  guest_name text,
  attending boolean,
  message text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS (policies are examples; adjust to your Supabase Auth mapping)
ALTER TABLE IF EXISTS users ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS weddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS rsvps ENABLE ROW LEVEL SECURITY;

-- Policy: allow super_admin full access (example: check users table role via session)
-- NOTE: This policy assumes you map Supabase auth UID to users.id or adapt accordingly.
CREATE POLICY IF NOT EXISTS "super_admin_access" ON users
  FOR ALL
  USING (exists (select 1 from users u where u.role = 'super_admin' /* adapt check */));

-- Policy: couples can select/update their own wedding (example placeholder)
CREATE POLICY IF NOT EXISTS "couple_own_wedding" ON weddings
  FOR ALL
  USING (true); -- Replace with proper auth check when using Supabase Auth

-- Policy: RSVPs are public insert/select; owners can view all for their wedding
CREATE POLICY IF NOT_EXISTS "rsvp_public_insert" ON rsvps
  FOR INSERT
  USING (true);

-- Seeds (super admin placeholder)
-- INSERT INTO users (email, password_hash, role) VALUES ('dxbhfs@gmail.com', 'PLACEHOLDER_HASH', 'super_admin');

-- End of migration
-- Create extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Weddings table
CREATE TABLE IF NOT EXISTS weddings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  groom_name text,
  bride_name text,
  groom_image_url text,
  bride_image_url text,
  cover_image_url text,
  guest_message_audio text,
  mp3_url text,
  wedding_date text,
  wedding_time text,
  venue_name text,
  story text,
  created_at timestamptz DEFAULT now()
);

-- RSVPs table
CREATE TABLE IF NOT EXISTS rsvps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id uuid REFERENCES weddings(id) ON DELETE CASCADE,
  name text,
  attending boolean,
  guests int,
  message text,
  created_at timestamptz DEFAULT now()
);

-- Users table for Super Admin and couple accounts
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  username text UNIQUE,
  password_hash text,
  role text NOT NULL DEFAULT 'couple', -- 'super_admin' or 'couple'
  wedding_id uuid REFERENCES weddings(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS and sensible policies
ALTER TABLE weddings ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "public_select_weddings" ON weddings FOR SELECT USING (true);
CREATE POLICY IF NOT EXISTS "insert_by_service_role" ON weddings FOR INSERT USING (auth.role() = 'service_role') WITH CHECK (auth.role() = 'service_role');

ALTER TABLE rsvps ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "public_insert_rsvps" ON rsvps FOR INSERT USING (true) WITH CHECK (true);
CREATE POLICY IF NOT EXISTS "public_select_rsvps" ON rsvps FOR SELECT USING (true);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "admin_manage_users" ON users FOR SELECT USING (auth.role() = 'service_role') ;

